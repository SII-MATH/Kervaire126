/-
  KIPBase.StableHomotopy.TensorTriangulatedCategory
  Closed symmetric tensor triangulated category structure.

  Blueprint: prerequisites.tex, Definition prereq:def:closed-symmetric-tensor-triangulated
  Reference: Hovey–Palmieri–Strickland, Definition A.2.1
-/
import Mathlib

namespace KIPBase.StableHomotopy

open CategoryTheory CategoryTheory.Limits
open MonoidalCategory Pretriangulated

universe u v

/-! ## Functorial Cofiber

General classes for a pretriangulated category with a canonical cofiber construction.
These are parameterized by an arbitrary category C (no SH dependency). -/

section FunctorialCofiber

variable (C : Type u) [Category.{v} C] [Preadditive C] [HasShift C ℤ]
  [∀ (n : ℤ), (shiftFunctor C n).Additive] [Limits.HasZeroObject C]
  [Pretriangulated C]

/-- A pretriangulated category has **functorial cofiber** when there is a canonical
    choice of cofiber for every morphism, together with canonical structure maps
    and functoriality from commutative squares.

    Blueprint: prerequisites.tex (functorial cofiber construction). -/
class HasFunctorialCofiber where
  /-- Canonical cofiber object for a morphism f : X ⟶ Y. -/
  cofib : {X Y : C} → (X ⟶ Y) → C
  /-- Canonical inclusion Y ⟶ cofib f. -/
  cofibι : {X Y : C} → (f : X ⟶ Y) → Y ⟶ cofib f
  /-- Canonical connecting map cofib f ⟶ X⟦1⟧. -/
  cofibδ : {X Y : C} → (f : X ⟶ Y) → cofib f ⟶ (shiftFunctor C (1 : ℤ)).obj X
  /-- The cofiber triangle X →[f] Y →[ι] cofib f →[δ] X⟦1⟧ is distinguished. -/
  cofib_distinguished : ∀ {X Y : C} (f : X ⟶ Y),
    Triangle.mk f (cofibι f) (cofibδ f) ∈ distTriang C
  /-- Functoriality: a commutative square α ≫ f₂ = f₁ ≫ β induces a map
      (cofib f₁ ⟶ cofib f₂) on cofibers. -/
  cofibMap : ∀ {X₁ Y₁ X₂ Y₂ : C} (f₁ : X₁ ⟶ Y₁) (f₂ : X₂ ⟶ Y₂)
    (α : X₁ ⟶ X₂) (β : Y₁ ⟶ Y₂), α ≫ f₂ = f₁ ≫ β →
    (cofib f₁ ⟶ cofib f₂)
  /-- cofibMap is compatible with the inclusion maps ι:
      β ≫ cofibι f₂ = cofibι f₁ ≫ cofibMap f₁ f₂ α β h. -/
  cofibMap_ι : ∀ {X₁ Y₁ X₂ Y₂ : C} (f₁ : X₁ ⟶ Y₁) (f₂ : X₂ ⟶ Y₂)
    (α : X₁ ⟶ X₂) (β : Y₁ ⟶ Y₂) (h : α ≫ f₂ = f₁ ≫ β),
    β ≫ cofibι f₂ = cofibι f₁ ≫ cofibMap f₁ f₂ α β h
  /-- cofibMap is compatible with the connecting maps δ:
      cofibMap f₁ f₂ α β h ≫ cofibδ f₂ = cofibδ f₁ ≫ (shiftFunctor C 1).map α. -/
  cofibMap_δ : ∀ {X₁ Y₁ X₂ Y₂ : C} (f₁ : X₁ ⟶ Y₁) (f₂ : X₂ ⟶ Y₂)
    (α : X₁ ⟶ X₂) (β : Y₁ ⟶ Y₂) (h : α ≫ f₂ = f₁ ≫ β),
    cofibMap f₁ f₂ α β h ≫ cofibδ f₂ = cofibδ f₁ ≫ (shiftFunctor C (1 : ℤ)).map α

end FunctorialCofiber

section TensorFunctorialCofiber

variable (C : Type u) [Category.{v} C] [Preadditive C] [HasShift C ℤ]
  [∀ (n : ℤ), (shiftFunctor C n).Additive] [Limits.HasZeroObject C]
  [MonoidalCategory C] [Pretriangulated C]

/-- A tensor triangulated category with functorial cofiber extends `HasFunctorialCofiber`
    with the compatibility isomorphism: cofib(f ▷ W) ≅ cofib(f) ⊗ W.

    Blueprint: prerequisites.tex (tensor–cofiber compatibility). -/
class TensorTriangulatedCatWithFunctorialCofiber extends HasFunctorialCofiber C where
  /-- Tensor with W commutes with functorial cofiber:
      cofib(f ▷ W) ≅ cofib(f) ⊗ W. -/
  tensorCofibIso : ∀ {X Y : C} (f : X ⟶ Y) (W : C),
    cofib (f ▷ W) ≅ cofib f ⊗ W

end TensorFunctorialCofiber

/-! ## Closed Symmetric Tensor Triangulated Category -/

/-- A closed symmetric tensor triangulated category
    (prereq:def:closed-symmetric-tensor-triangulated).
    A triangulated category with a closed symmetric monoidal structure
    compatible with the triangulation, following HPS Def A.2.1. -/
class ClosedSymmetricTensorTriangulated (C : Type u)
    [Category.{v} C] [Preadditive C] [HasShift C ℤ]
    [∀ (n : ℤ), (shiftFunctor C n).Additive] [Limits.HasZeroObject C]
    [MonoidalCategory C] [Pretriangulated C] where
  /-- The monoidal structure is symmetric. -/
  symmetricCategory : SymmetricCategory C
  /-- The symmetric monoidal structure is closed (internal hom exists). -/
  monoidalClosed : MonoidalClosed C
  /-- (1) Smash preserves suspensions: `Σ X ∧ Y ≃ Σ(X ∧ Y)`, compatible with
      unit and associativity isomorphisms. -/
  smashSuspIso : ∀ (X Y : C),
    (shiftFunctor C (1 : ℤ)).obj X ⊗ Y ≅ (shiftFunctor C (1 : ℤ)).obj (X ⊗ Y)
  /-- (2) Smash is exact: if `X → Y → Z → Σ X` is distinguished,
      then `X ∧ W → Y ∧ W → Z ∧ W → Σ(X ∧ W)` is distinguished. -/
  smashExact : ∀ (W : C) [_inst : (tensorRight W).CommShift ℤ]
    (T : Triangle C), T ∈ distTriang C →
    (tensorRight W).mapTriangle.obj T ∈ distTriang C
  /-- (3) The internal hom `F(W, -)` is exact in the second variable. -/
  ihomExact : ∀ (W : C),
    letI : MonoidalClosed C := monoidalClosed
    [_inst : (ihom W).CommShift ℤ] →
    (T : Triangle C) → T ∈ distTriang C →
    (ihom W).mapTriangle.obj T ∈ distTriang C

attribute [instance] ClosedSymmetricTensorTriangulated.symmetricCategory
attribute [instance] ClosedSymmetricTensorTriangulated.monoidalClosed

/-! ## May's TC3 smash-product lifting lemma

The axioms for a closed symmetric tensor triangulated category state that
smashing a distinguished triangle is exact.  The Generalized Mahowald Trick
needs the stronger TC3 compatibility for *two* triangles: a compatible pair of
classes in the middle of the resulting `3 × 3` diagram has a lift in the
opposite corner.  This is the content of May's Lemma 4.6.

It is deliberately a separate class.  It does not follow from the smaller
`smashExact` field above without choosing and comparing a TC3 diagram.
-/

section MayTC3Smash

variable (C : Type u) [Category.{v} C] [Preadditive C] [HasShift C ℤ]
  [∀ (n : ℤ), (shiftFunctor C n).Additive] [Limits.HasZeroObject C]
  [MonoidalCategory C] [Pretriangulated C] [ClosedSymmetricTensorTriangulated C]

/-- Boundary from `X ⊗ Z'` to `Σ(X ⊗ X')`, obtained from the connecting map
of the second triangle.  The braiding makes the available suspension--smash
isomorphism apply to the left factor. -/
noncomputable def smashRightBoundary (T T' : Triangle C) :
    T.obj₁ ⊗ T'.obj₃ ⟶ (shiftFunctor C (1 : ℤ)).obj (T.obj₁ ⊗ T'.obj₁) :=
  (T.obj₁ ◁ T'.mor₃) ≫
    (β_ T.obj₁ ((shiftFunctor C (1 : ℤ)).obj T'.obj₁)).hom ≫
    (ClosedSymmetricTensorTriangulated.smashSuspIso T'.obj₁ T.obj₁).hom ≫
    (shiftFunctor C (1 : ℤ)).map (β_ T'.obj₁ T.obj₁).hom

/-- Boundary from `Z ⊗ X'` to `Σ(X ⊗ X')`, obtained from the connecting map
of the first triangle. -/
noncomputable def smashLeftBoundary (T T' : Triangle C) :
    T.obj₃ ⊗ T'.obj₁ ⟶ (shiftFunctor C (1 : ℤ)).obj (T.obj₁ ⊗ T'.obj₁) :=
  (T.mor₃ ▷ T'.obj₁) ≫
    (ClosedSymmetricTensorTriangulated.smashSuspIso T.obj₁ T'.obj₁).hom

/-- May's TC3 lifting property for smash products of distinguished triangles.

For maps `a : W → X ⊗ Z'` and `b : W → Y ⊗ Y'` which agree in
`Y ⊗ Z'`, it supplies `c : W → Z ⊗ X'`.  The first conclusion identifies
`b` and `c` in `Z ⊗ Y'`; the second identifies their two boundary images in
`Σ(X ⊗ X')`.  Taking `W` to be a sphere recovers exactly the homotopy-group
form used in the Generalized Mahowald Trick. -/
class HasMayTC3SmashLift where
  lift : ∀ {T T' : Triangle C}, T ∈ distTriang C → T' ∈ distTriang C →
    ∀ {W : C} (a : W ⟶ T.obj₁ ⊗ T'.obj₃) (b : W ⟶ T.obj₂ ⊗ T'.obj₂),
      a ≫ (T.mor₁ ▷ T'.obj₃) = b ≫ (T.obj₂ ◁ T'.mor₂) →
      ∃ c : W ⟶ T.obj₃ ⊗ T'.obj₁,
        b ≫ (T.mor₂ ▷ T'.obj₂) = c ≫ (T.obj₃ ◁ T'.mor₁) ∧
        a ≫ smashRightBoundary C T T' = c ≫ smashLeftBoundary C T T'

/-- Eliminate the TC3 interface without exposing its implementation details. -/
theorem mayTC3_smash_lift [HasMayTC3SmashLift C]
    {T T' : Triangle C} (hT : T ∈ distTriang C) (hT' : T' ∈ distTriang C)
    {W : C} (a : W ⟶ T.obj₁ ⊗ T'.obj₃) (b : W ⟶ T.obj₂ ⊗ T'.obj₂)
    (hab : a ≫ (T.mor₁ ▷ T'.obj₃) = b ≫ (T.obj₂ ◁ T'.mor₂)) :
    ∃ c : W ⟶ T.obj₃ ⊗ T'.obj₁,
      b ≫ (T.mor₂ ▷ T'.obj₂) = c ≫ (T.obj₃ ◁ T'.mor₁) ∧
      a ≫ smashRightBoundary C T T' = c ≫ smashLeftBoundary C T T' :=
  HasMayTC3SmashLift.lift hT hT' a b hab

end MayTC3Smash

end KIPBase.StableHomotopy
