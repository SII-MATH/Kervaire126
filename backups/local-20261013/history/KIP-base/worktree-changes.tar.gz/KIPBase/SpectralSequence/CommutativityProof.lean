import KIPBase.SpectralSequence.Commutativity

namespace KIPBase.SpectralSequence

noncomputable section
set_option maxHeartbeats 6400000

open CategoryTheory CategoryTheory.Limits

universe u v w

variable {C : Type u} [Category.{v} C] [Abelian C]

section VertexTerms

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
variable {A₁ A₂ A₃ A₄ : ω' → C}
variable {F₁ : Filtration A₁} {F₂ : Filtration A₂}
variable {F₃ : Filtration A₃} {F₄ : Filtration A₄}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}

example (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') (s : ℤ) :
    (sq.extf.complex t).assocGraded s 1 =
      (sq.extp.complex t).assocGraded s 1 := by
  rfl

example (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') (s : ℤ) :
    (sq.extf.complex t).assocGraded s 0 =
      (sq.extq.complex t).assocGraded s 1 := by
  rfl

example (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') (s : ℤ) :
    (sq.extp.complex t).assocGraded s 0 =
      (sq.extg.complex t).assocGraded s 1 := by
  rfl

example (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') (s : ℤ) :
    (sq.extg.complex t).assocGraded s 0 =
      (sq.extq.complex t).assocGraded s 0 := by
  rfl

end VertexTerms

section Corollary218

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
variable {A₁ A₂ A₃ A₄ : ω' → C}
variable {F₁ : Filtration A₁} {F₂ : Filtration A₂}
variable {F₃ : Filtration A₃} {F₄ : Filtration A₄}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}

example (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (t : ω') (r : ℤ)
    (_p_stable : ESSPageStabilizes sq.extp t r)
    (_g_stable : ESSPageStabilizes sq.extg t r) :
    Nonempty (SpectralSequenceMorphism (sq.extf.ess t) (sq.extg.ess t)) := by
  let X : BoundedFilteredComplex C := ⟨sq.extf.complex t, sq.extf.bounded t⟩
  let Y : BoundedFilteredComplex C := ⟨sq.extg.complex t, sq.extg.bounded t⟩
  let φ : X ⟶ Y := extensionSquareMap sq t
  exact ⟨FilteredComplexMorphism.toSpectralSequenceMorphism φ⟩

end Corollary218

section TriangleTransport

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ E₃ : SpectralSequence C ω}
variable {A₁ A₂ A₃ : ω' → C}
variable {F₁ : Filtration A₁} {F₂ : Filtration A₂} {F₃ : Filtration A₃}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {conv₃ : Convergence E₃ A₃ F₃}

example {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₃}
    {t : ω'} {n m s : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityNoCrossingInput (T := T) sq t n m 0 s)
    (h15 : ESSCommutativityNoCrossingConclusion h)
    (hwz : HEq h.w h.z) :
    ESSRelationAt sq.extq t (m - n) (s + n) 1 h.y
      (by
        have hdeg : s + n + (m - n) = s + m := by omega
        rw [hdeg]
        let hz : T ⟶ (sq.extq.complex t).assocGraded (s + m) 0 := h.z
        exact Eq.mpr
          (congrArg (fun q => T ⟶ (sq.extq.complex t).assocGraded q 0)
            (by omega)) hz) := by
  sorry

end TriangleTransport

section CompositionTransport

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₃ E₄ : SpectralSequence C ω}
variable {A₁ A₃ A₄ : ω' → C}
variable {F₁ : Filtration A₁} {F₃ : Filtration A₃} {F₄ : Filtration A₄}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₃ : Convergence E₃ A₃ F₃}
variable {conv₄ : Convergence E₄ A₄ F₄}

example {sq : HomotopyCommSquare conv₁ conv₁ conv₃ conv₄}
    {t : ω'} {m l s : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityNoCrossingInput (T := T) sq t 0 m l s)
    (h15 : ESSCommutativityNoCrossingConclusion h)
    (hyx : HEq h.y h.x) :
    ESSRelationAt sq.extq t (m + l) s 1 h.x
      (by
        have hdeg : s + (m + l) = s + m + l := by omega
        rw [hdeg]
        exact h.w) := by
  sorry

end CompositionTransport

section RelationLifts

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ : SpectralSequence C ω}
variable {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {cm : ConvergenceMorphism conv₁ conv₂}
variable {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}

/-- Every concrete ESS relation has filtered lifts realizing its defining
differential equation.  This is Proposition 2.5's lift direction. -/
noncomputable def relationLiftOfESSRelation
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C} [Projective T]
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (hr : 0 ≤ r) (h : ESSRelationAt ext t r s k x y) :
    ESSRelationLiftData ext t r s k x y := by
  exact ESSRelationLiftData.ofESSRelation hr h

end RelationLifts

section InducedMap

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
variable {A₁ A₂ A₃ A₄ : ω' → C}
variable {F₁ : Filtration A₁} {F₂ : Filtration A₂}
variable {F₃ : Filtration A₃} {F₄ : Filtration A₄}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}

noncomputable def extensionSquareSSMorphismProof
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') :
    SpectralSequenceMorphism (sq.extf.ess t) (sq.extg.ess t) := by
  exact extensionSquareSSMorphism sq t

structure InducedESSMapProof (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (t : ω') where
  hom : SpectralSequenceMorphism (sq.extf.ess t) (sq.extg.ess t)
  is_induced : hom = extensionSquareSSMorphismProof sq t

example (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') :
    InducedESSMapProof sq t :=
  ⟨extensionSquareSSMorphismProof sq t, rfl⟩

end InducedMap

section MainTheoremLifts

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
variable {A₁ A₂ A₃ A₄ : ω' → C}
variable {F₁ : Filtration A₁} {F₂ : Filtration A₂}
variable {F₃ : Filtration A₃} {F₄ : Filtration A₄}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}

noncomputable def commutativityInputLifts
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    ESSRelationLiftData sq.extf t n s 1 h.x h.y ×
      ESSRelationLiftData sq.extp t m s 1 h.x h.z ×
        ESSRelationLiftData sq.extg t l (s + m) 1 h.z h.w :=
  ⟨relationLiftOfESSRelation h.n_nonneg h.f_rel,
    relationLiftOfESSRelation h.m_nonneg h.p_rel,
    relationLiftOfESSRelation h.l_nonneg h.g_rel⟩

/-- The f- and p-lifts of the common source differ only in the next
filtration.  This is the concrete starting point for the no-crossing
comparison in Proposition 2.10. -/
theorem commutativityInput_sourceLiftDifference
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    Subobject.Factors ((sq.extf.complex t).fil (s + 1) 1)
      (((show T ⟶ Subobject.underlying.obj ((sq.extf.complex t).fil s 1) from
          h.lifts.1.sourceLift) -
        (show T ⟶ Subobject.underlying.obj ((sq.extf.complex t).fil s 1) from
          h.lifts.2.1.sourceLift)) ≫
        ((sq.extf.complex t).fil s 1).arrow) := by
  exact ESSCommutativityInput.sourceLiftDifference h

theorem commutativityInput_oneRelationNoCrossing
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    (¬ RelationCrossedBy (sq.extf.ess t) (fun b => b.1) n ⟨s, 1⟩ h.x h.y h.f_rel) ∨
      (¬ RelationCrossedBy (sq.extp.ess t) (fun b => b.1) m ⟨s, 1⟩ h.x h.z h.p_rel) := by
  rcases h.f_or_p_noCrossing with hf | hp
  · exact Or.inl (h.f_datum.noRelationCrossing hf h.f_rel)
  · exact Or.inr (h.p_datum.noRelationCrossing hp h.p_rel)

end MainTheoremLifts

section NoCrossingBridge

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable {E₁ E₂ : SpectralSequence C ω}
variable {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
variable {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
variable {cm : ConvergenceMorphism conv₁ conv₂}
variable {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}

theorem noRelationCrossingOfESSNoCrossing
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    (dd : ESSDifferentialDatum ext t r s k)
    (hnc : dd.NoCrossing)
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (h : ESSRelationAt ext t r s k x y) :
    ¬ RelationCrossedBy (ext.ess t) (fun b => b.1) r ⟨s, k⟩ x y h := by
  exact ESSDifferentialDatum.noRelationCrossing dd hnc h

theorem noESSCrossingInRange
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k p : ℤ}
    (dd : ESSDifferentialDatum ext t r s k)
    (hnc : NoCrossingRange dd.datum p)
    (a m : ℤ) (ha : 0 < a) (k' : ℤ × ℤ)
    (hsource : k'.1 = s + a)
    (hessential : IsEssentialAt (ext.ess t) m k')
    (hlower : p ≤ k'.1 + m)
    (hupper : k'.1 + m ≤ s + r) : False := by
  exact ESSDifferentialDatum.noCrossingInRange dd hnc a m ha k' hsource hessential hlower hupper


end NoCrossingBridge

end

end KIPBase.SpectralSequence
