/-
  KIPBase.SpectralSequence.FilteredComplexNaturality

  The genuine naturality data required to pass a filtered-complex morphism to
  a spectral-sequence morphism.  This separates the kernel/image/intersection
  argument from the weak `SpectralSequenceMorphism.comm_d` interface, whose
  existential page maps alone do not determine maps induced by `φ`.
-/
import KIPBase.SpectralSequence.BoundedExtension

namespace KIPBase.SpectralSequence

open CategoryTheory CategoryTheory.Limits

universe u v

variable {C : Type u} [Category.{v} C] [Abelian C]

/-- Naturality of `Abelian.monoLift`: compatible maps into two monomorphisms
induce compatible lifts through their domains.  This is the first internal
comparison needed for naturality of `PageDifferentialData.onCycles`. -/
theorem Abelian.monoLift_naturality
    {T₁ T₂ A₁ B₁ A₂ B₂ : C}
    {m₁ : A₁ ⟶ B₁} {m₂ : A₂ ⟶ B₂}
    [Mono m₁] [Mono m₂]
    {h₁ : T₁ ⟶ B₁} {h₂ : T₂ ⟶ B₂}
    (hz₁ : h₁ ≫ cokernel.π m₁ = 0) (hz₂ : h₂ ≫ cokernel.π m₂ = 0)
    {u : T₁ ⟶ T₂} {v : A₁ ⟶ A₂} {w : B₁ ⟶ B₂}
    (hm : v ≫ m₂ = m₁ ≫ w) (hh : u ≫ h₂ = h₁ ≫ w) :
    u ≫ Abelian.monoLift m₂ h₂ hz₂ = Abelian.monoLift m₁ h₁ hz₁ ≫ v := by
  apply (cancel_mono m₂).mp
  rw [Category.assoc, Abelian.monoLift_comp, hh]
  rw [Category.assoc, hm, ← Category.assoc, Abelian.monoLift_comp]

/-- Naturality of `Abelian.epiDesc`: compatible maps out of two epi
presentations descend compatibly to their quotients. -/
theorem Abelian.epiDesc_naturality
    {A₁ B₁ D₁ A₂ B₂ D₂ : C}
    {p₁ : A₁ ⟶ B₁} {p₂ : A₂ ⟶ B₂} [Epi p₁] [Epi p₂]
    {h₁ : A₁ ⟶ D₁} {h₂ : A₂ ⟶ D₂}
    {hp₁ : kernel.ι p₁ ≫ h₁ = 0} {hp₂ : kernel.ι p₂ ≫ h₂ = 0}
    {a : A₁ ⟶ A₂} {b : B₁ ⟶ B₂} {d : D₁ ⟶ D₂}
    (hp : p₁ ≫ b = a ≫ p₂) (hh : a ≫ h₂ = h₁ ≫ d) :
    b ≫ Abelian.epiDesc p₂ h₂ hp₂ = Abelian.epiDesc p₁ h₁ hp₁ ≫ d := by
  apply (cancel_epi p₁).mp
  calc
    _ = (p₁ ≫ b) ≫ Abelian.epiDesc p₂ h₂ hp₂ := (Category.assoc _ _ _).symm
    _ = (a ≫ p₂) ≫ Abelian.epiDesc p₂ h₂ hp₂ := by rw [hp]
    _ = a ≫ (p₂ ≫ Abelian.epiDesc p₂ h₂ hp₂) := Category.assoc _ _ _
    _ = a ≫ h₂ := by rw [Abelian.comp_epiDesc]
    _ = h₁ ≫ d := hh
    _ = (p₁ ≫ Abelian.epiDesc p₁ h₁ hp₁) ≫ d := by rw [Abelian.comp_epiDesc]
    _ = _ := Category.assoc _ _ _

/-- Naturality of the canonical factor through a kernel subobject. -/
theorem factorThruKernelSubobject_naturality
    {X₁ Y₁ X₂ Y₂ T₁ T₂ : C}
    {f₁ : X₁ ⟶ Y₁} {f₂ : X₂ ⟶ Y₂}
    (sq : Arrow.mk f₁ ⟶ Arrow.mk f₂)
    {h₁ : T₁ ⟶ X₁} {h₂ : T₂ ⟶ X₂}
    (hz₁ : h₁ ≫ f₁ = 0) (hz₂ : h₂ ≫ f₂ = 0)
    {a : T₁ ⟶ T₂} (ha : a ≫ h₂ = h₁ ≫ sq.left) :
    a ≫ factorThruKernelSubobject f₂ h₂ hz₂ =
      factorThruKernelSubobject f₁ h₁ hz₁ ≫ kernelSubobjectMap sq := by
  apply (cancel_mono (kernelSubobject f₂).arrow).mp
  calc
    _ = a ≫ (factorThruKernelSubobject f₂ h₂ hz₂ ≫
          (kernelSubobject f₂).arrow) := Category.assoc _ _ _
    _ = a ≫ h₂ := by rw [factorThruKernelSubobject_comp_arrow]
    _ = h₁ ≫ sq.left := ha
    _ = (factorThruKernelSubobject f₁ h₁ hz₁ ≫
          (kernelSubobject f₁).arrow) ≫ sq.left := by
          rw [factorThruKernelSubobject_comp_arrow]
    _ = factorThruKernelSubobject f₁ h₁ hz₁ ≫
          ((kernelSubobject f₁).arrow ≫ sq.left) := Category.assoc _ _ _
    _ = factorThruKernelSubobject f₁ h₁ hz₁ ≫
          (kernelSubobjectMap sq ≫ (kernelSubobject f₂).arrow) := by
          rw [kernelSubobjectMap_arrow]
    _ = _ := (Category.assoc _ _ _).symm

/-- A commuting square between two kernel conditions, together with a
compatible square after quotienting, induces a map on the corresponding
cycle-image subobjects.  This is the categorical kernel/image step used in
the construction of `Z_r` naturality. -/
noncomputable def kernelCokernelImageMap
    {X₁ Y₁ X₂ Y₂ V₁ V₂ : C}
    {f₁ : X₁ ⟶ Y₁} {f₂ : X₂ ⟶ Y₂}
    {left : X₁ ⟶ X₂} {right : Y₁ ⟶ Y₂}
    (sq_ker : left ≫ f₂ = f₁ ≫ right)
    {πV₁ : X₁ ⟶ V₁} {πV₂ : X₂ ⟶ V₂}
    {φ : V₁ ⟶ V₂}
    (h_πV : left ≫ πV₂ = πV₁ ≫ φ) :
    Subobject.underlying.obj (imageSubobject ((kernelSubobject f₁).arrow ≫ πV₁)) ⟶
      Subobject.underlying.obj (imageSubobject ((kernelSubobject f₂).arrow ≫ πV₂)) := by
  let sq := Arrow.homMk (f := Arrow.mk f₁) (g := Arrow.mk f₂) left right sq_ker
  let kerLift := kernelSubobjectMap sq
  have hker := kernelSubobjectMap_arrow sq
  have hsq_left : sq.left = left := rfl
  have himage : kerLift ≫ ((kernelSubobject f₂).arrow ≫ πV₂) =
      ((kernelSubobject f₁).arrow ≫ πV₁) ≫ φ := by
    rw [Category.assoc, ← h_πV, ← Category.assoc, hker, hsq_left, Category.assoc]
  let imageSq := Arrow.homMk
    (f := Arrow.mk ((kernelSubobject f₁).arrow ≫ πV₁))
    (g := Arrow.mk ((kernelSubobject f₂).arrow ≫ πV₂))
    kerLift φ himage
  exact imageSubobjectMap imageSq

/-- Specification of `kernelCokernelImageMap`. -/
theorem kernelCokernelImageMap_spec
    {X₁ Y₁ X₂ Y₂ V₁ V₂ : C}
    {f₁ : X₁ ⟶ Y₁} {f₂ : X₂ ⟶ Y₂}
    {left : X₁ ⟶ X₂} {right : Y₁ ⟶ Y₂}
    (sq_ker : left ≫ f₂ = f₁ ≫ right)
    {πV₁ : X₁ ⟶ V₁} {πV₂ : X₂ ⟶ V₂}
    {φ : V₁ ⟶ V₂}
    (h_πV : left ≫ πV₂ = πV₁ ≫ φ) :
    kernelCokernelImageMap sq_ker h_πV ≫
        (imageSubobject ((kernelSubobject f₂).arrow ≫ πV₂)).arrow =
      (imageSubobject ((kernelSubobject f₁).arrow ≫ πV₁)).arrow ≫ φ := by
  unfold kernelCokernelImageMap
  dsimp only
  exact imageSubobjectMap_arrow _

/-- The universal property of an intersection of subobjects, in the form
needed for boundary naturality. -/
theorem Subobject.factors_inf_of_factors
    {X Y : C} {P Q : Subobject Y} (f : X ⟶ Y)
    (hP : P.Factors f) (hQ : Q.Factors f) :
    (P ⊓ Q).Factors f := by
  rw [Subobject.inf_factors]
  exact ⟨hP, hQ⟩

/-- The canonical factorization of a map through an intersection, with its
defining arrow equation. -/
noncomputable def Subobject.factorThruInf
    {X Y : C} {P Q : Subobject Y} (f : X ⟶ Y)
    (hP : P.Factors f) (hQ : Q.Factors f) :
    X ⟶ Subobject.underlying.obj (P ⊓ Q) :=
  (P ⊓ Q).factorThru f (Subobject.factors_inf_of_factors f hP hQ)

@[reassoc]
theorem Subobject.factorThruInf_arrow
    {X Y : C} {P Q : Subobject Y} (f : X ⟶ Y)
    (hP : P.Factors f) (hQ : Q.Factors f) :
    Subobject.factorThruInf f hP hQ ≫ (P ⊓ Q).arrow = f :=
  Subobject.factorThru_arrow _ _ _

/-- Projecting the intersection factorization to its right constituent still
recovers the original map after the constituent inclusion. -/
@[reassoc]
theorem Subobject.factorThruInf_comp_right
    {X Y : C} {P Q : Subobject Y} (f : X ⟶ Y)
    (hP : P.Factors f) (hQ : Q.Factors f) :
    Subobject.factorThruInf f hP hQ ≫
        Subobject.ofLE (P ⊓ Q) Q inf_le_right ≫ Q.arrow = f := by
  calc
    _ = Subobject.factorThruInf f hP hQ ≫
          (Subobject.ofLE (P ⊓ Q) Q inf_le_right ≫ Q.arrow) := rfl
    _ = Subobject.factorThruInf f hP hQ ≫ (P ⊓ Q).arrow := by
      rw [Subobject.ofLE_arrow]
    _ = f := Subobject.factorThruInf_arrow f hP hQ

/-- The map between canonical image subobjects associated to a commutative
square, with its source and target objects fixed explicitly. -/
noncomputable def imageSubobjectUnderlyingMap
    {W X Y Z : C} {f : W ⟶ X} {g : Y ⟶ Z}
    (sq : Arrow.mk f ⟶ Arrow.mk g) [HasImageMap sq] :
    Subobject.underlying.obj (imageSubobject f) ⟶
      Subobject.underlying.obj (imageSubobject g) :=
  imageSubobjectMap sq

theorem imageSubobjectUnderlyingMap_spec
    {W X Y Z : C} {f : W ⟶ X} {g : Y ⟶ Z}
    (sq : Arrow.mk f ⟶ Arrow.mk g) [HasImageMap sq] :
    imageSubobjectUnderlyingMap sq ≫ (imageSubobject g).arrow =
      (imageSubobject f).arrow ≫ sq.right :=
  imageSubobjectMap_arrow sq

/-- The canonical factor through an image is natural for a commuting arrow
square.  This is the image-factor comparison used inside `onCycles`. -/
theorem factorThruImageSubobject_naturality
    {W X Y Z : C} {f : W ⟶ X} {g : Y ⟶ Z}
    (sq : Arrow.mk f ⟶ Arrow.mk g) [HasImageMap sq] :
    factorThruImageSubobject f ≫ imageSubobjectUnderlyingMap sq =
      sq.left ≫ factorThruImageSubobject g := by
  apply (cancel_mono (imageSubobject g).arrow).mp
  rw [Category.assoc, imageSubobjectUnderlyingMap_spec]
  rw [← Category.assoc, imageSubobject_arrow_comp]
  rw [Category.assoc, imageSubobject_arrow_comp]
  simpa using sq.w.symm

/-- Before passing to the image subobject, `kernelCokernelImageMap` agrees
with the canonical kernel lift.  This exposes the factorization square hidden
in its construction. -/
theorem factorThruImageSubobject_kernelCokernelImageMap
    {X₁ Y₁ X₂ Y₂ V₁ V₂ : C}
    {f₁ : X₁ ⟶ Y₁} {f₂ : X₂ ⟶ Y₂}
    {left : X₁ ⟶ X₂} {right : Y₁ ⟶ Y₂}
    (sq_ker : left ≫ f₂ = f₁ ≫ right)
    {πV₁ : X₁ ⟶ V₁} {πV₂ : X₂ ⟶ V₂}
    {φ : V₁ ⟶ V₂}
    (h_πV : left ≫ πV₂ = πV₁ ≫ φ) :
    factorThruImageSubobject ((kernelSubobject f₁).arrow ≫ πV₁) ≫
        kernelCokernelImageMap sq_ker h_πV =
      kernelSubobjectMap
        (Arrow.homMk (f := Arrow.mk f₁) (g := Arrow.mk f₂) left right sq_ker) ≫
        factorThruImageSubobject ((kernelSubobject f₂).arrow ≫ πV₂) := by
  unfold kernelCokernelImageMap
  dsimp only
  apply factorThruImageSubobject_naturality

/-- Convert an inclusion of the image of `f` into a factorization of `f`.
This avoids exposing a chosen representative of the target subobject. -/
theorem Subobject.factors_of_image_le
    {A B : C} (f : A ⟶ B) {P : Subobject B}
    (h : imageSubobject f ≤ P) : P.Factors f := by
  apply Subobject.factors_of_le f h
  simpa using (imageSubobject_factors_comp_self (f := f) (𝟙 A))

/-- A map of differential images together with a filtration lift induces a
map on the intersections `image(d) ⊓ F`. -/
noncomputable def boundaryIntersectionMap
    {S₁ A₁ S₂ A₂ : C} {d₁ : S₁ ⟶ A₁} {d₂ : S₂ ⟶ A₂}
    {sourceMap : S₁ ⟶ S₂} {ambientMap : A₁ ⟶ A₂}
    (hd : sourceMap ≫ d₂ = d₁ ≫ ambientMap)
    {F₁ : Subobject A₁} {F₂ : Subobject A₂}
    (filtrationLift : Subobject.underlying.obj F₁ ⟶ Subobject.underlying.obj F₂)
    (hfiltration : filtrationLift ≫ F₂.arrow = F₁.arrow ≫ ambientMap) :
    Subobject.underlying.obj (imageSubobject d₁ ⊓ F₁) ⟶
      Subobject.underlying.obj (imageSubobject d₂ ⊓ F₂) := by
  let h : Subobject.underlying.obj (imageSubobject d₁ ⊓ F₁) ⟶ A₂ :=
    (imageSubobject d₁ ⊓ F₁).arrow ≫ ambientMap
  let imageMap := imageSubobjectUnderlyingMap (Arrow.homMk' sourceMap ambientMap hd)
  have himage : imageMap ≫ (imageSubobject d₂).arrow =
      (imageSubobject d₁).arrow ≫ ambientMap :=
    imageSubobjectUnderlyingMap_spec _
  have hImageLe : imageSubobject h ≤ imageSubobject d₂ := by
    apply imageSubobject_le h
      (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) (imageSubobject d₁)
        inf_le_left ≫ imageMap)
    dsimp [h]
    rw [Category.assoc, himage, ← Category.assoc, Subobject.ofLE_arrow]
  have hFiltrationLe : imageSubobject h ≤ F₂ := by
    apply imageSubobject_le h
      (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫ filtrationLift)
    dsimp [h]
    rw [Category.assoc, hfiltration, ← Category.assoc, Subobject.ofLE_arrow]
  exact Subobject.factorThruInf (P := imageSubobject d₂) (Q := F₂) h
    (Subobject.factors_of_image_le h hImageLe)
    (Subobject.factors_of_image_le h hFiltrationLe)

theorem boundaryIntersectionMap_spec
    {S₁ A₁ S₂ A₂ : C} {d₁ : S₁ ⟶ A₁} {d₂ : S₂ ⟶ A₂}
    {sourceMap : S₁ ⟶ S₂} {ambientMap : A₁ ⟶ A₂}
    (hd : sourceMap ≫ d₂ = d₁ ≫ ambientMap)
    {F₁ : Subobject A₁} {F₂ : Subobject A₂}
    (filtrationLift : Subobject.underlying.obj F₁ ⟶ Subobject.underlying.obj F₂)
    (hfiltration : filtrationLift ≫ F₂.arrow = F₁.arrow ≫ ambientMap) :
    boundaryIntersectionMap hd filtrationLift hfiltration ≫
        (imageSubobject d₂ ⊓ F₂).arrow =
      (imageSubobject d₁ ⊓ F₁).arrow ≫ ambientMap :=
  by
    unfold boundaryIntersectionMap
    dsimp only
    apply Subobject.factorThruInf_arrow

/-- The intersection map agrees with the specified filtration lift after
projection to the filtration constituent. -/
theorem boundaryIntersectionMap_comp_filtration
    {S₁ A₁ S₂ A₂ : C} {d₁ : S₁ ⟶ A₁} {d₂ : S₂ ⟶ A₂}
    {sourceMap : S₁ ⟶ S₂} {ambientMap : A₁ ⟶ A₂}
    (hd : sourceMap ≫ d₂ = d₁ ≫ ambientMap)
    {F₁ : Subobject A₁} {F₂ : Subobject A₂}
    (filtrationLift : Subobject.underlying.obj F₁ ⟶ Subobject.underlying.obj F₂)
    (hfiltration : filtrationLift ≫ F₂.arrow = F₁.arrow ≫ ambientMap) :
    boundaryIntersectionMap hd filtrationLift hfiltration ≫
        Subobject.ofLE (imageSubobject d₂ ⊓ F₂) F₂ inf_le_right =
      Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫ filtrationLift := by
  apply (cancel_mono F₂.arrow).mp
  rw [Category.assoc, Subobject.ofLE_arrow,
    boundaryIntersectionMap_spec hd filtrationLift hfiltration]
  rw [Category.assoc, hfiltration, ← Category.assoc, Subobject.ofLE_arrow]

/-- Passing boundary intersections to associated-graded quotients preserves
the induced map.  This is the image step in boundary naturality. -/
noncomputable def boundaryQuotientMap
    {S₁ A₁ S₂ A₂ : C} {d₁ : S₁ ⟶ A₁} {d₂ : S₂ ⟶ A₂}
    {sourceMap : S₁ ⟶ S₂} {ambientMap : A₁ ⟶ A₂}
    (hd : sourceMap ≫ d₂ = d₁ ≫ ambientMap)
    {F₁ : Subobject A₁} {F₂ : Subobject A₂}
    (filtrationLift : Subobject.underlying.obj F₁ ⟶ Subobject.underlying.obj F₂)
    (hfiltration : filtrationLift ≫ F₂.arrow = F₁.arrow ≫ ambientMap)
    {V₁ V₂ : C} {π₁ : Subobject.underlying.obj F₁ ⟶ V₁}
    {π₂ : Subobject.underlying.obj F₂ ⟶ V₂} {φ : V₁ ⟶ V₂}
    (hπ : filtrationLift ≫ π₂ = π₁ ≫ φ) :
    Subobject.underlying.obj
        (imageSubobject (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫ π₁)) ⟶
      Subobject.underlying.obj
        (imageSubobject (Subobject.ofLE (imageSubobject d₂ ⊓ F₂) F₂ inf_le_right ≫ π₂)) := by
  let q := boundaryIntersectionMap hd filtrationLift hfiltration
  let sq : Arrow.mk
      (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫ π₁) ⟶
      Arrow.mk (Subobject.ofLE (imageSubobject d₂ ⊓ F₂) F₂ inf_le_right ≫ π₂) :=
    Arrow.homMk' q φ (by
      calc
        q ≫ (Subobject.ofLE (imageSubobject d₂ ⊓ F₂) F₂ inf_le_right ≫ π₂) =
            (q ≫ Subobject.ofLE (imageSubobject d₂ ⊓ F₂) F₂ inf_le_right) ≫ π₂ :=
              (Category.assoc _ _ _).symm
        _ = (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫
              filtrationLift) ≫ π₂ := by
              rw [boundaryIntersectionMap_comp_filtration hd filtrationLift hfiltration]
        _ = Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫
              (filtrationLift ≫ π₂) := Category.assoc _ _ _
        _ = Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫
              (π₁ ≫ φ) := by rw [hπ]
        _ = (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫ π₁) ≫ φ :=
              (Category.assoc _ _ _).symm)
  exact imageSubobjectUnderlyingMap sq

/-- Defining square for `boundaryQuotientMap`. -/
theorem boundaryQuotientMap_spec
    {S₁ A₁ S₂ A₂ : C} {d₁ : S₁ ⟶ A₁} {d₂ : S₂ ⟶ A₂}
    {sourceMap : S₁ ⟶ S₂} {ambientMap : A₁ ⟶ A₂}
    (hd : sourceMap ≫ d₂ = d₁ ≫ ambientMap)
    {F₁ : Subobject A₁} {F₂ : Subobject A₂}
    (filtrationLift : Subobject.underlying.obj F₁ ⟶ Subobject.underlying.obj F₂)
    (hfiltration : filtrationLift ≫ F₂.arrow = F₁.arrow ≫ ambientMap)
    {V₁ V₂ : C} {π₁ : Subobject.underlying.obj F₁ ⟶ V₁}
    {π₂ : Subobject.underlying.obj F₂ ⟶ V₂} {φ : V₁ ⟶ V₂}
    (hπ : filtrationLift ≫ π₂ = π₁ ≫ φ) :
    boundaryQuotientMap hd filtrationLift hfiltration hπ ≫
        (imageSubobject
          (Subobject.ofLE (imageSubobject d₂ ⊓ F₂) F₂ inf_le_right ≫ π₂)).arrow =
      (imageSubobject
        (Subobject.ofLE (imageSubobject d₁ ⊓ F₁) F₁ inf_le_right ≫ π₁)).arrow ≫ φ := by
  unfold boundaryQuotientMap
  dsimp only
  exact imageSubobjectUnderlyingMap_spec _

/-- A filtration-preserving chain map induces a map on the quotients by one
chosen filtration layer.  This is the target-side quotient map in the finite
cycle condition. -/
noncomputable def FilteredComplexMorphism.filtrationQuotientMap
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    cokernel ((FC₁.fil s k).arrow) ⟶ cokernel ((FC₂.fil s k).arrow) :=
  cokernel.map (FC₁.fil s k).arrow (FC₂.fil s k).arrow
    (g.filt_compat s k).choose (g.f k)
    (g.filt_compat s k).choose_spec.symm

/-- Defining projection formula for `filtrationQuotientMap`. -/
theorem FilteredComplexMorphism.filtrationQuotientMap_spec
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    cokernel.π ((FC₁.fil s k).arrow) ≫ g.filtrationQuotientMap s k =
      g.f k ≫ cokernel.π ((FC₂.fil s k).arrow) := by
  unfold FilteredComplexMorphism.filtrationQuotientMap
  exact cokernel.π_desc _ _ _

/-- The chosen filtration lift commutes with passage to the associated
graded quotient. -/
theorem FilteredComplexMorphism.filtLift_assocGradedMap
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    (g.filt_compat s k).choose ≫
        cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
          (FC₂.fil_anti s k)) =
      cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
        (FC₁.fil_anti s k)) ≫ g.assocGradedMap s k := by
  unfold FilteredComplexMorphism.assocGradedMap
  exact (cokernel.π_desc _ _ _).symm

/-- A filtration-preserving chain map commutes with the differentials induced
on associated gradeds.  This is the chain-level square underlying pagewise
differential naturality. -/
theorem FilteredComplexMorphism.assocGradedMap_comm_assocGradedDiff
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    g.assocGradedMap s k ≫ FC₂.assocGradedDiff s k =
      FC₁.assocGradedDiff s k ≫ g.assocGradedMap s (k - 1) := by
  have hfil : (g.filt_compat s k).choose ≫ FC₂.filDiff s k =
      FC₁.filDiff s k ≫ (g.filt_compat s (k - 1)).choose := by
    apply (cancel_mono (FC₂.fil s (k - 1)).arrow).mp
    calc
      ((g.filt_compat s k).choose ≫ FC₂.filDiff s k) ≫
          (FC₂.fil s (k - 1)).arrow =
          (g.filt_compat s k).choose ≫
            (FC₂.filDiff s k ≫ (FC₂.fil s (k - 1)).arrow) := Category.assoc _ _ _
      _ = (g.filt_compat s k).choose ≫
            ((FC₂.fil s k).arrow ≫ FC₂.d k) := by
            rw [show FC₂.filDiff s k = (FC₂.d_preserves_fil s k).choose from rfl,
              (FC₂.d_preserves_fil s k).choose_spec]
      _ = ((g.filt_compat s k).choose ≫ (FC₂.fil s k).arrow) ≫ FC₂.d k :=
            (Category.assoc _ _ _).symm
      _ = ((FC₁.fil s k).arrow ≫ g.f k) ≫ FC₂.d k := by
            rw [(g.filt_compat s k).choose_spec]
      _ = (FC₁.fil s k).arrow ≫ (g.f k ≫ FC₂.d k) := Category.assoc _ _ _
      _ = (FC₁.fil s k).arrow ≫ (FC₁.d k ≫ g.f (k - 1)) := by rw [g.comm_d]
      _ = ((FC₁.fil s k).arrow ≫ FC₁.d k) ≫ g.f (k - 1) :=
            (Category.assoc _ _ _).symm
      _ = (FC₁.filDiff s k ≫ (FC₁.fil s (k - 1)).arrow) ≫ g.f (k - 1) := by
            rw [show FC₁.filDiff s k = (FC₁.d_preserves_fil s k).choose from rfl,
              (FC₁.d_preserves_fil s k).choose_spec]
      _ = FC₁.filDiff s k ≫
            ((FC₁.fil s (k - 1)).arrow ≫ g.f (k - 1)) := Category.assoc _ _ _
      _ = FC₁.filDiff s k ≫
            ((g.filt_compat s (k - 1)).choose ≫ (FC₂.fil s (k - 1)).arrow) := by
            rw [(g.filt_compat s (k - 1)).choose_spec]
      _ = (FC₁.filDiff s k ≫ (g.filt_compat s (k - 1)).choose) ≫
            (FC₂.fil s (k - 1)).arrow := (Category.assoc _ _ _).symm
  have hdiff₁ :
      cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
        (FC₁.fil_anti s k)) ≫ FC₁.assocGradedDiff s k =
      FC₁.filDiff s k ≫
        cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) (k - 1))
          (FC₁.fil s (k - 1)) (FC₁.fil_anti s (k - 1))) := by
    simpa only [FilteredComplex.filToAssocGraded] using
      FC₁.assocGradedDiff_compat s k
  have hdiff₂ :
      cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
        (FC₂.fil_anti s k)) ≫ FC₂.assocGradedDiff s k =
      FC₂.filDiff s k ≫
        cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) (k - 1))
          (FC₂.fil s (k - 1)) (FC₂.fil_anti s (k - 1))) := by
    simpa only [FilteredComplex.filToAssocGraded] using
      FC₂.assocGradedDiff_compat s k
  apply (cancel_epi (cokernel.π
    (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
      (FC₁.fil_anti s k)))).mp
  calc
    _ = (cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
          (FC₁.fil_anti s k)) ≫ g.assocGradedMap s k) ≫
          FC₂.assocGradedDiff s k := (Category.assoc _ _ _).symm
    _ = ((g.filt_compat s k).choose ≫
          cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
            (FC₂.fil_anti s k))) ≫ FC₂.assocGradedDiff s k := by
          rw [← g.filtLift_assocGradedMap]
    _ = (g.filt_compat s k).choose ≫
          (cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
            (FC₂.fil_anti s k)) ≫ FC₂.assocGradedDiff s k) := Category.assoc _ _ _
    _ = (g.filt_compat s k).choose ≫
          (FC₂.filDiff s k ≫
            cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) (k - 1))
              (FC₂.fil s (k - 1)) (FC₂.fil_anti s (k - 1)))) := by rw [hdiff₂]
    _ = ((g.filt_compat s k).choose ≫ FC₂.filDiff s k) ≫
          cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) (k - 1))
            (FC₂.fil s (k - 1)) (FC₂.fil_anti s (k - 1))) :=
          (Category.assoc _ _ _).symm
    _ = (FC₁.filDiff s k ≫ (g.filt_compat s (k - 1)).choose) ≫
          cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) (k - 1))
            (FC₂.fil s (k - 1)) (FC₂.fil_anti s (k - 1))) := by rw [hfil]
    _ = FC₁.filDiff s k ≫ ((g.filt_compat s (k - 1)).choose ≫
          cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) (k - 1))
            (FC₂.fil s (k - 1)) (FC₂.fil_anti s (k - 1)))) := Category.assoc _ _ _
    _ = FC₁.filDiff s k ≫
          (cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) (k - 1))
            (FC₁.fil s (k - 1)) (FC₁.fil_anti s (k - 1))) ≫
            g.assocGradedMap s (k - 1)) := by
          rw [g.filtLift_assocGradedMap]
    _ = (FC₁.filDiff s k ≫
          cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) (k - 1))
            (FC₁.fil s (k - 1)) (FC₁.fil_anti s (k - 1)))) ≫
          g.assocGradedMap s (k - 1) := (Category.assoc _ _ _).symm
    _ = (cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
          (FC₁.fil_anti s k)) ≫ FC₁.assocGradedDiff s k) ≫
          g.assocGradedMap s (k - 1) := by rw [hdiff₁]
    _ = _ := Category.assoc _ _ _

/-- The finite-page cycle defining maps form a commuting square under a
filtered-complex morphism.  Its kernel map is the input to
`kernelCokernelImageMap`. -/
theorem FilteredComplexMorphism.finiteCycleSquare
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) (n : ℕ) :
    (g.filt_compat s k).choose ≫
        ((FC₂.fil s k).arrow ≫ FC₂.d k ≫
          cokernel.π ((FC₂.fil (s + ↑n) (k - 1)).arrow)) =
      ((FC₁.fil s k).arrow ≫ FC₁.d k ≫
        cokernel.π ((FC₁.fil (s + ↑n) (k - 1)).arrow)) ≫
          g.filtrationQuotientMap (s + ↑n) (k - 1) := by
  calc
    _ = ((g.filt_compat s k).choose ≫ (FC₂.fil s k).arrow) ≫ FC₂.d k ≫
          cokernel.π ((FC₂.fil (s + ↑n) (k - 1)).arrow) := by
          simp only [Category.assoc]
    _ = ((FC₁.fil s k).arrow ≫ g.f k) ≫ FC₂.d k ≫
          cokernel.π ((FC₂.fil (s + ↑n) (k - 1)).arrow) := by
          rw [(g.filt_compat s k).choose_spec]
    _ = (FC₁.fil s k).arrow ≫ (g.f k ≫ FC₂.d k) ≫
          cokernel.π ((FC₂.fil (s + ↑n) (k - 1)).arrow) := by
          simp only [Category.assoc]
    _ = (FC₁.fil s k).arrow ≫ (FC₁.d k ≫ g.f (k - 1)) ≫
          cokernel.π ((FC₂.fil (s + ↑n) (k - 1)).arrow) := by
          rw [g.comm_d]
    _ = (FC₁.fil s k).arrow ≫ FC₁.d k ≫
          (g.f (k - 1) ≫
            cokernel.π ((FC₂.fil (s + ↑n) (k - 1)).arrow)) := by
          simp only [Category.assoc]
    _ = (FC₁.fil s k).arrow ≫ FC₁.d k ≫
          (cokernel.π ((FC₁.fil (s + ↑n) (k - 1)).arrow) ≫
            g.filtrationQuotientMap (s + ↑n) (k - 1)) := by
          rw [g.filtrationQuotientMap_spec]
    _ = _ := by simp only [Category.assoc]

/-- The source-cycle kernel map commutes with the representative-level lift of
the differential into the target filtration piece. -/
theorem FilteredComplexMorphism.finiteCycleKernel_filtrationLift
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) (n : ℕ) :
    kernelSubobjectMap
        (Arrow.homMk
          (f := Arrow.mk (FC₁.pageCycleCondition s k n))
          (g := Arrow.mk (FC₂.pageCycleCondition s k n))
          (g.filt_compat s k).choose
          (g.filtrationQuotientMap (s + ↑n) (k - 1))
          (g.finiteCycleSquare s k n)) ≫
        FC₂.pageDifferentialFiltrationLift s k n =
      FC₁.pageDifferentialFiltrationLift s k n ≫
        (g.filt_compat (s + ↑n) (k - 1)).choose := by
  refine Abelian.monoLift_naturality
    (m₁ := (FC₁.fil (s + ↑n) (k - 1)).arrow)
    (m₂ := (FC₂.fil (s + ↑n) (k - 1)).arrow)
    (h₁ := (kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
      (FC₁.fil s k).arrow ≫ FC₁.d k)
    (h₂ := (kernelSubobject (FC₂.pageCycleCondition s k n)).arrow ≫
      (FC₂.fil s k).arrow ≫ FC₂.d k)
    (u := kernelSubobjectMap
      (Arrow.homMk
        (f := Arrow.mk (FC₁.pageCycleCondition s k n))
        (g := Arrow.mk (FC₂.pageCycleCondition s k n))
        (g.filt_compat s k).choose
        (g.filtrationQuotientMap (s + ↑n) (k - 1))
        (g.finiteCycleSquare s k n)))
    (v := (g.filt_compat (s + ↑n) (k - 1)).choose)
    (w := g.f (k - 1))
    (hz₁ := by
      simpa only [FilteredComplex.pageCycleCondition, Category.assoc] using
        (kernelSubobject_arrow_comp (FC₁.pageCycleCondition s k n)))
    (hz₂ := by
      simpa only [FilteredComplex.pageCycleCondition, Category.assoc] using
        (kernelSubobject_arrow_comp (FC₂.pageCycleCondition s k n)))
    ?_ ?_
  · exact (g.filt_compat (s + ↑n) (k - 1)).choose_spec
  · let sq := Arrow.homMk
      (f := Arrow.mk (FC₁.pageCycleCondition s k n))
      (g := Arrow.mk (FC₂.pageCycleCondition s k n))
      (g.filt_compat s k).choose
      (g.filtrationQuotientMap (s + ↑n) (k - 1))
      (g.finiteCycleSquare s k n)
    calc
      _ = (kernelSubobjectMap sq ≫
            (kernelSubobject (FC₂.pageCycleCondition s k n)).arrow) ≫
            (FC₂.fil s k).arrow ≫ FC₂.d k := by
              dsimp [sq]
              exact (Category.assoc _ _ _).symm
      _ = ((kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
            (g.filt_compat s k).choose) ≫ (FC₂.fil s k).arrow ≫ FC₂.d k := by
              rw [kernelSubobjectMap_arrow]
              dsimp [sq]
      _ = (kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
            ((g.filt_compat s k).choose ≫ (FC₂.fil s k).arrow) ≫ FC₂.d k := by
              simp only [Category.assoc]
      _ = (kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
            ((FC₁.fil s k).arrow ≫ g.f k) ≫ FC₂.d k := by
              rw [(g.filt_compat s k).choose_spec]
      _ = (kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
            (FC₁.fil s k).arrow ≫ (g.f k ≫ FC₂.d k) := by
              simp only [Category.assoc]
      _ = (kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
            (FC₁.fil s k).arrow ≫ (FC₁.d k ≫ g.f (k - 1)) := by
              rw [g.comm_d]
      _ = ((kernelSubobject (FC₁.pageCycleCondition s k n)).arrow ≫
            (FC₁.fil s k).arrow ≫ FC₁.d k) ≫ g.f (k - 1) := by
              simp only [Category.assoc]

/-- The representative-level differential map is natural after factoring
through the target cycle kernel. -/
theorem FilteredComplexMorphism.finiteCycleKernel_targetKernelFactor
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) (n : ℕ) :
    kernelSubobjectMap
        (Arrow.homMk
          (f := Arrow.mk (FC₁.pageCycleCondition s k n))
          (g := Arrow.mk (FC₂.pageCycleCondition s k n))
          (g.filt_compat s k).choose
          (g.filtrationQuotientMap (s + ↑n) (k - 1))
          (g.finiteCycleSquare s k n)) ≫
        FC₂.pageDifferentialTargetKernelFactor s k n =
      FC₁.pageDifferentialTargetKernelFactor s k n ≫
        kernelSubobjectMap
          (Arrow.homMk
            (f := Arrow.mk (FC₁.pageCycleCondition (s + ↑n) (k - 1) n))
            (g := Arrow.mk (FC₂.pageCycleCondition (s + ↑n) (k - 1) n))
            (g.filt_compat (s + ↑n) (k - 1)).choose
            (g.filtrationQuotientMap (s + ↑n + ↑n) (k - 1 - 1))
            (g.finiteCycleSquare (s + ↑n) (k - 1) n)) := by
  unfold FilteredComplex.pageDifferentialTargetKernelFactor
  refine factorThruKernelSubobject_naturality
    (Arrow.homMk
      (f := Arrow.mk (FC₁.pageCycleCondition (s + ↑n) (k - 1) n))
      (g := Arrow.mk (FC₂.pageCycleCondition (s + ↑n) (k - 1) n))
      (g.filt_compat (s + ↑n) (k - 1)).choose
      (g.filtrationQuotientMap (s + ↑n + ↑n) (k - 1 - 1))
      (g.finiteCycleSquare (s + ↑n) (k - 1) n))
    (FC₁.pageDifferentialFiltrationLift_targetCycle s k n)
    (FC₂.pageDifferentialFiltrationLift_targetCycle s k n) ?_
  exact g.finiteCycleKernel_filtrationLift s k n

/-- The `r = ∞` cycle defining maps form the analogous commuting square. -/
theorem FilteredComplexMorphism.infiniteCycleSquare
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    (g.filt_compat s k).choose ≫ ((FC₂.fil s k).arrow ≫ FC₂.d k) =
      ((FC₁.fil s k).arrow ≫ FC₁.d k) ≫ g.f (k - 1) := by
  calc
    _ = ((g.filt_compat s k).choose ≫ (FC₂.fil s k).arrow) ≫ FC₂.d k := by
      simp only [Category.assoc]
    _ = ((FC₁.fil s k).arrow ≫ g.f k) ≫ FC₂.d k := by
      rw [(g.filt_compat s k).choose_spec]
    _ = (FC₁.fil s k).arrow ≫ (g.f k ≫ FC₂.d k) := by
      simp only [Category.assoc]
    _ = _ := by
      rw [g.comm_d]
      simp only [Category.assoc]

/-- Naturality of the transported differential used in boundary subobjects. -/
theorem FilteredComplexMorphism.dToK_naturality
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (k : ℤ) :
    g.f (k + 1) ≫ FC₂.dToK k = FC₁.dToK k ≫ g.f k := by
  unfold FilteredComplex.dToK
  simpa using
    congrArg (fun h => h ≫ eqToHom (congr_arg FC₂.A (show (k + 1) - 1 = k by omega)))
      (g.comm_d (k + 1))

/-- The source maps used in finite-page boundary subobjects form a
commuting square under a filtered-complex morphism. -/
theorem FilteredComplexMorphism.filteredDToKSquare
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (a k : ℤ) :
    (g.filt_compat a (k + 1)).choose ≫
        ((FC₂.fil a (k + 1)).arrow ≫ FC₂.dToK k) =
      ((FC₁.fil a (k + 1)).arrow ≫ FC₁.dToK k) ≫ g.f k := by
  calc
    _ = ((g.filt_compat a (k + 1)).choose ≫
          (FC₂.fil a (k + 1)).arrow) ≫ FC₂.dToK k := by
          simp only [Category.assoc]
    _ = ((FC₁.fil a (k + 1)).arrow ≫ g.f (k + 1)) ≫ FC₂.dToK k := by
          rw [(g.filt_compat a (k + 1)).choose_spec]
    _ = (FC₁.fil a (k + 1)).arrow ≫
          (g.f (k + 1) ≫ FC₂.dToK k) := by
          simp only [Category.assoc]
    _ = _ := by
          rw [g.dToK_naturality]
          simp only [Category.assoc]

/-- The fully expanded finite-page boundary map before identifying its source
and target with `boundarySubobject`.  Isolating this term keeps the
kernel/image construction independent of the reducibility behaviour of the
large spectral-sequence data structure. -/
noncomputable def FilteredComplexMorphism.finiteBoundaryCore
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) (n : ℕ) :
    Subobject.underlying.obj (imageSubobject
      (Subobject.ofLE
        (imageSubobject ((FC₁.fil (s - ↑n + 1) (k + 1)).arrow ≫ FC₁.dToK k) ⊓
          FC₁.fil s k)
        (FC₁.fil s k) inf_le_right ≫
        cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
          (FC₁.fil_anti s k)))) ⟶
      Subobject.underlying.obj (imageSubobject
        (Subobject.ofLE
          (imageSubobject ((FC₂.fil (s - ↑n + 1) (k + 1)).arrow ≫ FC₂.dToK k) ⊓
            FC₂.fil s k)
          (FC₂.fil s k) inf_le_right ≫
          cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
            (FC₂.fil_anti s k)))) := by
  have hd := g.filteredDToKSquare (s - ↑n + 1) k
  exact boundaryQuotientMap
    (d₁ := (FC₁.fil (s - ↑n + 1) (k + 1)).arrow ≫ FC₁.dToK k)
    (d₂ := (FC₂.fil (s - ↑n + 1) (k + 1)).arrow ≫ FC₂.dToK k)
    (sourceMap := (g.filt_compat (s - ↑n + 1) (k + 1)).choose)
    (ambientMap := g.f k) (F₁ := FC₁.fil s k) (F₂ := FC₂.fil s k)
    (π₁ := cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
      (FC₁.fil_anti s k)))
    (π₂ := cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
      (FC₂.fil_anti s k)))
    (φ := g.assocGradedMap s k)
    hd (g.filt_compat s k).choose (g.filt_compat s k).choose_spec
    (g.filtLift_assocGradedMap s k)

/-- The finite-page core, identified with the boundary subobjects used by the
spectral-sequence construction. -/
noncomputable def FilteredComplexMorphism.finiteBoundaryLift
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) (n : ℕ) :
    Subobject.underlying.obj (FC₁.boundarySubobject s k ↑n) ⟶
      Subobject.underlying.obj (FC₂.boundarySubobject s k ↑n) := by
  simpa only [FilteredComplex.boundarySubobject] using g.finiteBoundaryCore s k n

/-- Compatibility of the finite-page boundary lift with the map on associated
gradeds.  The generic specification is instantiated before the boundary
definition is unfolded, avoiding dependent-type reduction at the call site. -/
theorem FilteredComplexMorphism.finiteBoundaryLift_spec
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) (n : ℕ) :
    g.finiteBoundaryLift s k n ≫ (FC₂.boundarySubobject s k ↑n).arrow =
      (FC₁.boundarySubobject s k ↑n).arrow ≫ g.assocGradedMap s k := by
  have hd := g.filteredDToKSquare (s - ↑n + 1) k
  have h := boundaryQuotientMap_spec
    (d₁ := (FC₁.fil (s - ↑n + 1) (k + 1)).arrow ≫ FC₁.dToK k)
    (d₂ := (FC₂.fil (s - ↑n + 1) (k + 1)).arrow ≫ FC₂.dToK k)
    (sourceMap := (g.filt_compat (s - ↑n + 1) (k + 1)).choose)
    (ambientMap := g.f k) (F₁ := FC₁.fil s k) (F₂ := FC₂.fil s k)
    (π₁ := cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
      (FC₁.fil_anti s k)))
    (π₂ := cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
      (FC₂.fil_anti s k)))
    (φ := g.assocGradedMap s k)
    hd (g.filt_compat s k).choose (g.filt_compat s k).choose_spec
    (g.filtLift_assocGradedMap s k)
  simpa only [FilteredComplexMorphism.finiteBoundaryLift,
    FilteredComplexMorphism.finiteBoundaryCore,
    FilteredComplex.boundarySubobject] using h

/-- Fully expanded boundary map at the limiting page. -/
noncomputable def FilteredComplexMorphism.infiniteBoundaryCore
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    Subobject.underlying.obj (imageSubobject
      (Subobject.ofLE (imageSubobject (FC₁.dToK k) ⊓ FC₁.fil s k)
        (FC₁.fil s k) inf_le_right ≫
        cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
          (FC₁.fil_anti s k)))) ⟶
      Subobject.underlying.obj (imageSubobject
        (Subobject.ofLE (imageSubobject (FC₂.dToK k) ⊓ FC₂.fil s k)
          (FC₂.fil s k) inf_le_right ≫
          cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
            (FC₂.fil_anti s k)))) := by
  have hd := g.dToK_naturality k
  exact boundaryQuotientMap
    (d₁ := FC₁.dToK k) (d₂ := FC₂.dToK k)
    (sourceMap := g.f (k + 1)) (ambientMap := g.f k)
    (F₁ := FC₁.fil s k) (F₂ := FC₂.fil s k)
    (π₁ := cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
      (FC₁.fil_anti s k)))
    (π₂ := cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
      (FC₂.fil_anti s k)))
    (φ := g.assocGradedMap s k)
    hd (g.filt_compat s k).choose (g.filt_compat s k).choose_spec
    (g.filtLift_assocGradedMap s k)

/-- The limiting-page core, identified with the boundary subobjects in the
spectral-sequence data. -/
noncomputable def FilteredComplexMorphism.infiniteBoundaryLift
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    Subobject.underlying.obj (FC₁.boundarySubobject s k ⊤) ⟶
      Subobject.underlying.obj (FC₂.boundarySubobject s k ⊤) := by
  simpa only [FilteredComplex.boundarySubobject] using g.infiniteBoundaryCore s k

/-- Compatibility of the limiting-page boundary lift with associated gradeds. -/
theorem FilteredComplexMorphism.infiniteBoundaryLift_spec
    {FC₁ FC₂ : FilteredComplex C} (g : FilteredComplexMorphism FC₁ FC₂)
    (s k : ℤ) :
    g.infiniteBoundaryLift s k ≫ (FC₂.boundarySubobject s k ⊤).arrow =
      (FC₁.boundarySubobject s k ⊤).arrow ≫ g.assocGradedMap s k := by
  have hd := g.dToK_naturality k
  have h := boundaryQuotientMap_spec
    (d₁ := FC₁.dToK k) (d₂ := FC₂.dToK k)
    (sourceMap := g.f (k + 1)) (ambientMap := g.f k)
    (F₁ := FC₁.fil s k) (F₂ := FC₂.fil s k)
    (π₁ := cokernel.π (Subobject.ofLE (FC₁.fil (s + 1) k) (FC₁.fil s k)
      (FC₁.fil_anti s k)))
    (π₂ := cokernel.π (Subobject.ofLE (FC₂.fil (s + 1) k) (FC₂.fil s k)
      (FC₂.fil_anti s k)))
    (φ := g.assocGradedMap s k)
    hd (g.filt_compat s k).choose (g.filt_compat s k).choose_spec
    (g.filtLift_assocGradedMap s k)
  simpa only [FilteredComplexMorphism.infiniteBoundaryLift,
    FilteredComplexMorphism.infiniteBoundaryCore,
    FilteredComplex.boundarySubobject] using h

/-- Boundary lifts for all finite and limiting pages. -/
noncomputable def FilteredComplexMorphism.boundaryLift
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (r : WithTop ℕ) :
    Subobject.underlying.obj ((X.FC.toSSData X.bnd s k).B r) ⟶
      Subobject.underlying.obj ((Y.FC.toSSData Y.bnd s k).B r) := by
  cases r with
  | top => exact (g : FilteredComplexMorphism X.FC Y.FC).infiniteBoundaryLift s k
  | coe n => exact (g : FilteredComplexMorphism X.FC Y.FC).finiteBoundaryLift s k n

/-- The all-page boundary lift respects the associated-graded map. -/
theorem FilteredComplexMorphism.boundaryLift_spec
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (r : WithTop ℕ) :
    g.boundaryLift s k r ≫ ((Y.FC.toSSData Y.bnd s k).B r).arrow =
      ((X.FC.toSSData X.bnd s k).B r).arrow ≫
        FilteredComplexMorphism.assocGradedMap
          (g : FilteredComplexMorphism X.FC Y.FC) s k := by
  cases r with
  | top =>
    exact (g : FilteredComplexMorphism X.FC Y.FC).infiniteBoundaryLift_spec s k
  | coe n =>
    exact (g : FilteredComplexMorphism X.FC Y.FC).finiteBoundaryLift_spec s k n

/-- The canonical lift of cycle subobjects induced by a filtered-complex
morphism.  The finite and infinite page cases use the two kernel squares
proved above. -/
noncomputable def FilteredComplexMorphism.cycleLift
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (r : WithTop ℕ) :
    Subobject.underlying.obj ((X.FC.toSSData X.bnd s k).Z r) ⟶
      Subobject.underlying.obj ((Y.FC.toSSData Y.bnd s k).Z r) := by
  cases r with
  | top =>
    exact kernelCokernelImageMap
      ((g : FilteredComplexMorphism X.FC Y.FC).infiniteCycleSquare s k)
      ((g : FilteredComplexMorphism X.FC Y.FC).filtLift_assocGradedMap s k)
  | coe n =>
    exact kernelCokernelImageMap
      ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)
      ((g : FilteredComplexMorphism X.FC Y.FC).filtLift_assocGradedMap s k)

/-- The canonical cycle lift is compatible with the associated-graded map. -/
theorem FilteredComplexMorphism.cycleLift_spec
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (r : WithTop ℕ) :
    g.cycleLift s k r ≫ ((Y.FC.toSSData Y.bnd s k).Z r).arrow =
      ((X.FC.toSSData X.bnd s k).Z r).arrow ≫
        FilteredComplexMorphism.assocGradedMap
          (g : FilteredComplexMorphism X.FC Y.FC) s k := by
  cases r with
  | top =>
    exact kernelCokernelImageMap_spec
      ((g : FilteredComplexMorphism X.FC Y.FC).infiniteCycleSquare s k)
      ((g : FilteredComplexMorphism X.FC Y.FC).filtLift_assocGradedMap s k)
  | coe n =>
    exact kernelCokernelImageMap_spec
      ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)
      ((g : FilteredComplexMorphism X.FC Y.FC).filtLift_assocGradedMap s k)

/-- On a finite page, the canonical map from the cycle-defining kernel to the
cycle subobject is natural.  This is the representative-level form of cycle
naturality used to compare the constructed page differentials. -/
theorem FilteredComplexMorphism.finiteCycleKernelToCycles_cycleLift
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (n : ℕ) :
    X.FC.finiteCycleKernelToCycles s k n ≫ g.cycleLift s k (↑n : WithTop ℕ) =
      kernelSubobjectMap
        (Arrow.homMk
          (f := Arrow.mk (X.FC.pageCycleCondition s k n))
          (g := Arrow.mk (Y.FC.pageCycleCondition s k n))
          ((g : FilteredComplexMorphism X.FC Y.FC).filt_compat s k).choose
          ((g : FilteredComplexMorphism X.FC Y.FC).filtrationQuotientMap
            (s + ↑n) (k - 1))
          ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)) ≫
        Y.FC.finiteCycleKernelToCycles s k n := by
  exact factorThruImageSubobject_kernelCokernelImageMap
    ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)
    ((g : FilteredComplexMorphism X.FC Y.FC).filtLift_assocGradedMap s k)

/-- Explicit naturality data on the cycle and boundary subobjects of the
spectral sequences associated to two bounded filtered complexes.

The intended construction uses the chain-map equation and the filtration
lifts of `g`, then the universal properties of the defining kernels, images,
intersections and cokernels.  Keeping these lifts explicit prevents a page
map from being confused with an arbitrary morphism between page objects. -/
structure FilteredComplexMorphism.ZBNaturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y) where
  liftZ : ∀ (s k : ℤ) (r : WithTop ℕ),
    Subobject.underlying.obj ((X.FC.toSSData X.bnd s k).Z r) ⟶
      Subobject.underlying.obj ((Y.FC.toSSData Y.bnd s k).Z r)
  liftZ_spec : ∀ (s k : ℤ) (r : WithTop ℕ),
    liftZ s k r ≫ ((Y.FC.toSSData Y.bnd s k).Z r).arrow =
      ((X.FC.toSSData X.bnd s k).Z r).arrow ≫
        FilteredComplexMorphism.assocGradedMap
          (g : FilteredComplexMorphism X.FC Y.FC) s k
  liftB : ∀ (s k : ℤ) (r : WithTop ℕ),
    Subobject.underlying.obj ((X.FC.toSSData X.bnd s k).B r) ⟶
      Subobject.underlying.obj ((Y.FC.toSSData Y.bnd s k).B r)
  liftB_spec : ∀ (s k : ℤ) (r : WithTop ℕ),
    liftB s k r ≫ ((Y.FC.toSSData Y.bnd s k).B r).arrow =
      ((X.FC.toSSData X.bnd s k).B r).arrow ≫
        FilteredComplexMorphism.assocGradedMap
          (g : FilteredComplexMorphism X.FC Y.FC) s k

/-- Cycle naturality is canonical.  Thus a compatible family of boundary
lifts is precisely the remaining input needed to assemble `Z/B` naturality. -/
noncomputable def FilteredComplexMorphism.ZBNaturality.ofBoundaryLifts
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (liftB : ∀ (s k : ℤ) (r : WithTop ℕ),
      Subobject.underlying.obj ((X.FC.toSSData X.bnd s k).B r) ⟶
        Subobject.underlying.obj ((Y.FC.toSSData Y.bnd s k).B r))
    (liftB_spec : ∀ (s k : ℤ) (r : WithTop ℕ),
      liftB s k r ≫ ((Y.FC.toSSData Y.bnd s k).B r).arrow =
        ((X.FC.toSSData X.bnd s k).B r).arrow ≫
          FilteredComplexMorphism.assocGradedMap
            (g : FilteredComplexMorphism X.FC Y.FC) s k) :
    FilteredComplexMorphism.ZBNaturality g where
  liftZ := g.cycleLift
  liftZ_spec := g.cycleLift_spec
  liftB := liftB
  liftB_spec := liftB_spec

/-- Canonical `Z/B` naturality for every morphism of bounded filtered
complexes.  Both lifts are now constructed from the chain-map and
filtration-preservation equations. -/
noncomputable def FilteredComplexMorphism.canonicalZBNaturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y) :
    FilteredComplexMorphism.ZBNaturality g :=
  FilteredComplexMorphism.ZBNaturality.ofBoundaryLifts g
    (fun s k r => g.boundaryLift s k r)
    (fun s k r => g.boundaryLift_spec s k r)

/-- The map on the `r`-th page at `(s,k)` forced by `Z/B` naturality. -/
noncomputable def FilteredComplexMorphism.ZBNaturality.pageMap
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.ZBNaturality g)
    (s k : ℤ) (r : WithTop ℕ) :
    ((X.FC.toSSData X.bnd s k).page r) ⟶
      ((Y.FC.toSSData Y.bnd s k).page r) :=
  cokernel.map
    (Subobject.ofLE ((X.FC.toSSData X.bnd s k).B r)
      ((X.FC.toSSData X.bnd s k).Z r)
      ((X.FC.toSSData X.bnd s k).B_le_Z r))
    (Subobject.ofLE ((Y.FC.toSSData Y.bnd s k).B r)
      ((Y.FC.toSSData Y.bnd s k).Z r)
      ((Y.FC.toSSData Y.bnd s k).B_le_Z r))
    (N.liftB s k r) (N.liftZ s k r) (by
      apply (cancel_mono ((Y.FC.toSSData Y.bnd s k).Z r).arrow).mp
      calc
        _ = (Subobject.ofLE ((X.FC.toSSData X.bnd s k).B r)
              ((X.FC.toSSData X.bnd s k).Z r)
              ((X.FC.toSSData X.bnd s k).B_le_Z r) ≫
            (N.liftZ s k r ≫ ((Y.FC.toSSData Y.bnd s k).Z r).arrow)) :=
              Category.assoc _ _ _
        _ = (Subobject.ofLE ((X.FC.toSSData X.bnd s k).B r)
              ((X.FC.toSSData X.bnd s k).Z r)
              ((X.FC.toSSData X.bnd s k).B_le_Z r) ≫
            (((X.FC.toSSData X.bnd s k).Z r).arrow ≫
              FilteredComplexMorphism.assocGradedMap
                (g : FilteredComplexMorphism X.FC Y.FC) s k)) := by
              rw [N.liftZ_spec]
        _ = (((X.FC.toSSData X.bnd s k).B r).arrow ≫
              FilteredComplexMorphism.assocGradedMap
                (g : FilteredComplexMorphism X.FC Y.FC) s k) := by
              rw [← Category.assoc, Subobject.ofLE_arrow]
        _ = (N.liftB s k r ≫ ((Y.FC.toSSData Y.bnd s k).B r).arrow) :=
              (N.liftB_spec s k r).symm
        _ = (N.liftB s k r ≫
              (Subobject.ofLE ((Y.FC.toSSData Y.bnd s k).B r)
                ((Y.FC.toSSData Y.bnd s k).Z r)
                ((Y.FC.toSSData Y.bnd s k).B_le_Z r) ≫
                ((Y.FC.toSSData Y.bnd s k).Z r).arrow)) := by
              rw [Subobject.ofLE_arrow]
        _ = _ := (Category.assoc _ _ _).symm)

/-- The induced page map is the canonical descent of the cycle lift through
the source page quotient. -/
theorem FilteredComplexMorphism.ZBNaturality.pageπ_pageMap
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.ZBNaturality g)
    (s k : ℤ) (r : WithTop ℕ) :
    ((X.FC.toSSData X.bnd s k).pageπ r) ≫ N.pageMap s k r =
      N.liftZ s k r ≫ ((Y.FC.toSSData Y.bnd s k).pageπ r) := by
  unfold FilteredComplexMorphism.ZBNaturality.pageMap SSData.pageπ
  exact cokernel.π_desc _ _ _

/-- After the target cycle kernel is projected to its finite-page cycles and
then to the target page, the representative-level differential is natural for
the canonical page maps. -/
theorem FilteredComplexMorphism.targetKernelFactor_to_page_naturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (n : ℕ) :
    kernelSubobjectMap
        (Arrow.homMk
          (f := Arrow.mk (X.FC.pageCycleCondition s k n))
          (g := Arrow.mk (Y.FC.pageCycleCondition s k n))
          ((g : FilteredComplexMorphism X.FC Y.FC).filt_compat s k).choose
          ((g : FilteredComplexMorphism X.FC Y.FC).filtrationQuotientMap
            (s + ↑n) (k - 1))
          ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)) ≫
        Y.FC.pageDifferentialTargetKernelFactor s k n ≫
          Y.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
            (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n =
      X.FC.pageDifferentialTargetKernelFactor s k n ≫
        X.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
          (X.FC.toSSData X.bnd (s + ↑n) (k - 1)).pageπ ↑n ≫
            (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
              (↑n : WithTop ℕ) := by
  let g' : FilteredComplexMorphism X.FC Y.FC := g
  let srcSq := Arrow.homMk
    (f := Arrow.mk (X.FC.pageCycleCondition s k n))
    (g := Arrow.mk (Y.FC.pageCycleCondition s k n))
    (g'.filt_compat s k).choose
    (g'.filtrationQuotientMap (s + ↑n) (k - 1))
    (g'.finiteCycleSquare s k n)
  let tgtSq := Arrow.homMk
    (f := Arrow.mk (X.FC.pageCycleCondition (s + ↑n) (k - 1) n))
    (g := Arrow.mk (Y.FC.pageCycleCondition (s + ↑n) (k - 1) n))
    (g'.filt_compat (s + ↑n) (k - 1)).choose
    (g'.filtrationQuotientMap (s + ↑n + ↑n) (k - 1 - 1))
    (g'.finiteCycleSquare (s + ↑n) (k - 1) n)
  have hfactor : kernelSubobjectMap srcSq ≫
      Y.FC.pageDifferentialTargetKernelFactor s k n =
      X.FC.pageDifferentialTargetKernelFactor s k n ≫ kernelSubobjectMap tgtSq := by
    simpa only [srcSq, tgtSq, g'] using g'.finiteCycleKernel_targetKernelFactor s k n
  have hcycles : X.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
      g.cycleLift (s + ↑n) (k - 1) (↑n : WithTop ℕ) =
      kernelSubobjectMap tgtSq ≫
        Y.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n := by
    simpa only [tgtSq, g'] using
      g.finiteCycleKernelToCycles_cycleLift (s + ↑n) (k - 1) n
  have hpage := (g.canonicalZBNaturality).pageπ_pageMap
    (s + ↑n) (k - 1) (↑n : WithTop ℕ)
  change kernelSubobjectMap srcSq ≫
      Y.FC.pageDifferentialTargetKernelFactor s k n ≫
        Y.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
          (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n =
      X.FC.pageDifferentialTargetKernelFactor s k n ≫
        X.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
          (X.FC.toSSData X.bnd (s + ↑n) (k - 1)).pageπ ↑n ≫
            (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
              (↑n : WithTop ℕ)
  calc
    _ = (kernelSubobjectMap srcSq ≫
          Y.FC.pageDifferentialTargetKernelFactor s k n) ≫
          Y.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
            (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n := by
            simp only [Category.assoc]
    _ = (X.FC.pageDifferentialTargetKernelFactor s k n ≫ kernelSubobjectMap tgtSq) ≫
          Y.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
            (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n := by rw [hfactor]
    _ = X.FC.pageDifferentialTargetKernelFactor s k n ≫
          (kernelSubobjectMap tgtSq ≫
            Y.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n) ≫
            (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n := by
            simp only [Category.assoc]
    _ = X.FC.pageDifferentialTargetKernelFactor s k n ≫
          (X.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
            g.cycleLift (s + ↑n) (k - 1) (↑n : WithTop ℕ)) ≫
            (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n := by
            rw [hcycles]
    _ = X.FC.pageDifferentialTargetKernelFactor s k n ≫
          X.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
          (g.cycleLift (s + ↑n) (k - 1) (↑n : WithTop ℕ) ≫
            (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n) := by
            simp only [Category.assoc]
    _ = X.FC.pageDifferentialTargetKernelFactor s k n ≫
          X.FC.finiteCycleKernelToCycles (s + ↑n) (k - 1) n ≫
          ((X.FC.toSSData X.bnd (s + ↑n) (k - 1)).pageπ ↑n ≫
            (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
              (↑n : WithTop ℕ)) := by
            rw [show g.cycleLift (s + ↑n) (k - 1) (↑n : WithTop ℕ) ≫
                (Y.FC.toSSData Y.bnd (s + ↑n) (k - 1)).pageπ ↑n =
              (X.FC.toSSData X.bnd (s + ↑n) (k - 1)).pageπ ↑n ≫
                (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
                  (↑n : WithTop ℕ) by
              simpa only [FilteredComplexMorphism.canonicalZBNaturality,
                FilteredComplexMorphism.ZBNaturality.ofBoundaryLifts] using hpage.symm]
    _ = _ := by simp only [Category.assoc]

/-- The source-kernel representative used by the constructed finite-page
differential is natural for the canonical page maps. -/
theorem FilteredComplexMorphism.canonical_fromSourceKernel_naturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (n : ℕ) :
    kernelSubobjectMap
        (Arrow.homMk
          (f := Arrow.mk (X.FC.pageCycleCondition s k n))
          (g := Arrow.mk (Y.FC.pageCycleCondition s k n))
          ((g : FilteredComplexMorphism X.FC Y.FC).filt_compat s k).choose
          ((g : FilteredComplexMorphism X.FC Y.FC).filtrationQuotientMap
            (s + ↑n) (k - 1))
          ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)) ≫
        (Y.FC.pageDifferentialData Y.bnd s k n).fromSourceKernel =
      (X.FC.pageDifferentialData X.bnd s k n).fromSourceKernel ≫
        (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
          (↑n : WithTop ℕ) := by
  rw [Y.FC.pageDifferentialData_fromSourceKernel]
  rw [X.FC.pageDifferentialData_fromSourceKernel]
  simpa only [Category.assoc] using g.targetKernelFactor_to_page_naturality s k n

/-- Reduction of finite-page differential naturality to the corresponding
square on cycle representatives.  The source page projection is epi, so the
two quotient maps agree exactly when their cycle-level representatives do. -/
theorem FilteredComplexMorphism.ZBNaturality.pageDifferential_comm_of_onCycles
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.ZBNaturality g)
    (s k : ℤ) (n : ℕ)
    (h_onCycles :
      N.liftZ s k (↑n : WithTop ℕ) ≫
          (Y.FC.pageDifferentialData Y.bnd s k n).onCycles =
        (X.FC.pageDifferentialData X.bnd s k n).onCycles ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ)) :
    N.pageMap s k (↑n : WithTop ℕ) ≫ Y.FC.pageDifferential Y.bnd s k n =
      X.FC.pageDifferential X.bnd s k n ≫
        N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := by
  have hπ : cokernel.π
        (Subobject.ofLE (X.FC.boundarySubobject s k ↑n)
          (X.FC.cycleSubobject s k ↑n) (X.FC.B_le_Z_aux s k ↑n)) ≫
        N.pageMap s k (↑n : WithTop ℕ) =
      N.liftZ s k (↑n : WithTop ℕ) ≫ cokernel.π
        (Subobject.ofLE (Y.FC.boundarySubobject s k ↑n)
          (Y.FC.cycleSubobject s k ↑n) (Y.FC.B_le_Z_aux s k ↑n)) := by
    simpa only [SSData.pageπ] using N.pageπ_pageMap s k (↑n : WithTop ℕ)
  have hdX : cokernel.π
        (Subobject.ofLE (X.FC.boundarySubobject s k ↑n)
          (X.FC.cycleSubobject s k ↑n) (X.FC.B_le_Z_aux s k ↑n)) ≫
        X.FC.pageDifferential X.bnd s k n =
      (X.FC.pageDifferentialData X.bnd s k n).onCycles := by
    simpa only [SSData.pageπ] using X.FC.pageπ_pageDifferential X.bnd s k n
  have hdY : cokernel.π
        (Subobject.ofLE (Y.FC.boundarySubobject s k ↑n)
          (Y.FC.cycleSubobject s k ↑n) (Y.FC.B_le_Z_aux s k ↑n)) ≫
        Y.FC.pageDifferential Y.bnd s k n =
      (Y.FC.pageDifferentialData Y.bnd s k n).onCycles := by
    simpa only [SSData.pageπ] using Y.FC.pageπ_pageDifferential Y.bnd s k n
  apply (cancel_epi (cokernel.π
    (Subobject.ofLE (X.FC.boundarySubobject s k ↑n)
      (X.FC.cycleSubobject s k ↑n) (X.FC.B_le_Z_aux s k ↑n)))).mp
  calc
    _ = (cokernel.π
          (Subobject.ofLE (X.FC.boundarySubobject s k ↑n)
            (X.FC.cycleSubobject s k ↑n) (X.FC.B_le_Z_aux s k ↑n)) ≫
          N.pageMap s k (↑n : WithTop ℕ)) ≫ Y.FC.pageDifferential Y.bnd s k n :=
            (Category.assoc _ _ _).symm
    _ = (N.liftZ s k (↑n : WithTop ℕ) ≫ cokernel.π
          (Subobject.ofLE (Y.FC.boundarySubobject s k ↑n)
            (Y.FC.cycleSubobject s k ↑n) (Y.FC.B_le_Z_aux s k ↑n))) ≫
          Y.FC.pageDifferential Y.bnd s k n := by rw [hπ]
    _ = N.liftZ s k (↑n : WithTop ℕ) ≫ (cokernel.π
          (Subobject.ofLE (Y.FC.boundarySubobject s k ↑n)
            (Y.FC.cycleSubobject s k ↑n) (Y.FC.B_le_Z_aux s k ↑n)) ≫
          Y.FC.pageDifferential Y.bnd s k n) := Category.assoc _ _ _
    _ = N.liftZ s k (↑n : WithTop ℕ) ≫
          (Y.FC.pageDifferentialData Y.bnd s k n).onCycles := by rw [hdY]
    _ = (X.FC.pageDifferentialData X.bnd s k n).onCycles ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := h_onCycles
    _ = (cokernel.π
          (Subobject.ofLE (X.FC.boundarySubobject s k ↑n)
            (X.FC.cycleSubobject s k ↑n) (X.FC.B_le_Z_aux s k ↑n)) ≫
          X.FC.pageDifferential X.bnd s k n) ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := by rw [hdX]
    _ = _ := Category.assoc _ _ _

/-- The `onCycles` naturality square may be checked after the canonical epi
from the source cycle kernel.  This exposes precisely the kernel-level map
constructed from the differential. -/
theorem FilteredComplexMorphism.ZBNaturality.onCycles_naturality_of_sourceKernel
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.ZBNaturality g)
    (s k : ℤ) (n : ℕ)
    (h_kernel :
      (X.FC.pageDifferentialData X.bnd s k n).sourceKernelToCycles ≫
          N.liftZ s k (↑n : WithTop ℕ) ≫
          (Y.FC.pageDifferentialData Y.bnd s k n).onCycles =
        (X.FC.pageDifferentialData X.bnd s k n).fromSourceKernel ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ)) :
    N.liftZ s k (↑n : WithTop ℕ) ≫
        (Y.FC.pageDifferentialData Y.bnd s k n).onCycles =
      (X.FC.pageDifferentialData X.bnd s k n).onCycles ≫
        N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := by
  let p := (X.FC.pageDifferentialData X.bnd s k n).sourceKernelToCycles
  haveI : Epi p := by
    dsimp [p, FilteredComplex.pageDifferentialData]
    infer_instance
  apply (cancel_epi p).mp
  change p ≫ N.liftZ s k (↑n : WithTop ℕ) ≫
      (Y.FC.pageDifferentialData Y.bnd s k n).onCycles = _
  calc
    _ = (X.FC.pageDifferentialData X.bnd s k n).fromSourceKernel ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := h_kernel
    _ = (p ≫ (X.FC.pageDifferentialData X.bnd s k n).onCycles) ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := by
          rw [(X.FC.pageDifferentialData X.bnd s k n).sourceKernelToCycles_onCycles]
    _ = _ := Category.assoc _ _ _

/-- After identifying finite-cycle representatives with their defining
kernels, `onCycles` naturality reduces to naturality of the map constructed
from that source kernel.  The remaining comparison therefore no longer
contains the source image quotient. -/
theorem FilteredComplexMorphism.ZBNaturality.onCycles_naturality_of_kernelMap
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.ZBNaturality g)
    (s k : ℤ) (n : ℕ)
    (h_liftZ : N.liftZ s k (↑n : WithTop ℕ) = g.cycleLift s k (↑n : WithTop ℕ))
    (h_kernel :
      kernelSubobjectMap
          (Arrow.homMk
            (f := Arrow.mk (X.FC.pageCycleCondition s k n))
            (g := Arrow.mk (Y.FC.pageCycleCondition s k n))
            ((g : FilteredComplexMorphism X.FC Y.FC).filt_compat s k).choose
            ((g : FilteredComplexMorphism X.FC Y.FC).filtrationQuotientMap
              (s + ↑n) (k - 1))
            ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)) ≫
          (Y.FC.pageDifferentialData Y.bnd s k n).fromSourceKernel =
        (X.FC.pageDifferentialData X.bnd s k n).fromSourceKernel ≫
          N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ)) :
    N.liftZ s k (↑n : WithTop ℕ) ≫
        (Y.FC.pageDifferentialData Y.bnd s k n).onCycles =
      (X.FC.pageDifferentialData X.bnd s k n).onCycles ≫
        N.pageMap (s + ↑n) (k - 1) (↑n : WithTop ℕ) := by
  apply N.onCycles_naturality_of_sourceKernel s k n
  change X.FC.finiteCycleKernelToCycles s k n ≫
      N.liftZ s k (↑n : WithTop ℕ) ≫
        (Y.FC.pageDifferentialData Y.bnd s k n).onCycles = _
  rw [h_liftZ]
  rw [← Category.assoc]
  rw [FilteredComplexMorphism.finiteCycleKernelToCycles_cycleLift]
  rw [Category.assoc]
  rw [(Y.FC.pageDifferentialData Y.bnd s k n).sourceKernelToCycles_onCycles]
  exact h_kernel

/-- For the canonical `Z/B` lifts, finite-page differential naturality follows
from the single explicit square on the kernels defining the source cycles. -/
theorem FilteredComplexMorphism.canonical_pageDifferential_comm_of_kernelMap
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (n : ℕ)
    (h_kernel :
      kernelSubobjectMap
          (Arrow.homMk
            (f := Arrow.mk (X.FC.pageCycleCondition s k n))
            (g := Arrow.mk (Y.FC.pageCycleCondition s k n))
            ((g : FilteredComplexMorphism X.FC Y.FC).filt_compat s k).choose
            ((g : FilteredComplexMorphism X.FC Y.FC).filtrationQuotientMap
              (s + ↑n) (k - 1))
            ((g : FilteredComplexMorphism X.FC Y.FC).finiteCycleSquare s k n)) ≫
          (Y.FC.pageDifferentialData Y.bnd s k n).fromSourceKernel =
        (X.FC.pageDifferentialData X.bnd s k n).fromSourceKernel ≫
          (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
            (↑n : WithTop ℕ)) :
    (g.canonicalZBNaturality).pageMap s k (↑n : WithTop ℕ) ≫
        Y.FC.pageDifferential Y.bnd s k n =
      X.FC.pageDifferential X.bnd s k n ≫
        (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
          (↑n : WithTop ℕ) := by
  apply (g.canonicalZBNaturality).pageDifferential_comm_of_onCycles s k n
  apply (g.canonicalZBNaturality).onCycles_naturality_of_kernelMap s k n rfl
  exact h_kernel

/-- Finite-page differentials of bounded filtered complexes are natural for
the canonical maps induced by every filtered-complex morphism. -/
theorem FilteredComplexMorphism.canonical_pageDifferential_comm
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    (s k : ℤ) (n : ℕ) :
    (g.canonicalZBNaturality).pageMap s k (↑n : WithTop ℕ) ≫
        Y.FC.pageDifferential Y.bnd s k n =
      X.FC.pageDifferential X.bnd s k n ≫
        (g.canonicalZBNaturality).pageMap (s + ↑n) (k - 1)
          (↑n : WithTop ℕ) :=
  g.canonical_pageDifferential_comm_of_kernelMap s k n
    (g.canonical_fromSourceKernel_naturality s k n)

/-- Full page-level naturality.  The equation says that the maps forced by
`Z/B` naturality, rather than arbitrary zero maps, commute with differentials.
-/
structure FilteredComplexMorphism.PageNaturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y)
    extends FilteredComplexMorphism.ZBNaturality g where
  comm_d : ∀ (r s k : ℤ),
    FilteredComplexMorphism.ZBNaturality.pageMap toZBNaturality s k
      (↑((r - (X.FC.toSpectralSequence X.bnd).r₀).toNat) : WithTop ℕ) ≫
        (Y.FC.toSpectralSequence Y.bnd).d r ⟨s, k⟩ =
      (X.FC.toSpectralSequence X.bnd).d r ⟨s, k⟩ ≫
        FilteredComplexMorphism.ZBNaturality.pageMap toZBNaturality (s + r) (k - 1)
          (↑((r - (X.FC.toSpectralSequence X.bnd).r₀).toNat) : WithTop ℕ)

/-- The only additional datum required after canonical `Z/B` naturality is
the actual differential equation on the induced quotient maps. -/
structure FilteredComplexMorphism.CanonicalPageNaturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y) where
  comm_d : ∀ (r s k : ℤ),
    FilteredComplexMorphism.ZBNaturality.pageMap (g.canonicalZBNaturality) s k
      (↑((r - (X.FC.toSpectralSequence X.bnd).r₀).toNat) : WithTop ℕ) ≫
        (Y.FC.toSpectralSequence Y.bnd).d r ⟨s, k⟩ =
      (X.FC.toSpectralSequence X.bnd).d r ⟨s, k⟩ ≫
        FilteredComplexMorphism.ZBNaturality.pageMap (g.canonicalZBNaturality)
          (s + r) (k - 1)
          (↑((r - (X.FC.toSpectralSequence X.bnd).r₀).toNat) : WithTop ℕ)

/-- Every morphism of bounded filtered complexes induces canonical page maps
commuting with all differentials of the associated spectral sequences. -/
noncomputable def FilteredComplexMorphism.canonicalPageNaturality
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y) :
    FilteredComplexMorphism.CanonicalPageNaturality g where
  comm_d := by
    intro r s k
    dsimp only [FilteredComplex.toSpectralSequence, SpectralSequence.ofPreSS,
      FilteredComplex.toPreSS]
    by_cases hr : 0 ≤ r
    · obtain ⟨n, rfl⟩ := Int.eq_ofNat_of_zero_le hr
      simp only [Int.toNat_natCast, dif_pos (Int.natCast_nonneg n),
        eqToHom_refl, Category.id_comp, Category.comp_id]
      exact g.canonical_pageDifferential_comm s k n
    · simp only [dif_neg hr, zero_comp, comp_zero]

/-- Convert the canonical formulation into the general page-naturality
structure. -/
noncomputable def FilteredComplexMorphism.CanonicalPageNaturality.toPageNaturality
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.CanonicalPageNaturality g) :
    FilteredComplexMorphism.PageNaturality g where
  toZBNaturality := g.canonicalZBNaturality
  comm_d := N.comm_d

/-- A genuine page-natural filtered-complex morphism gives an ordinary
spectral-sequence morphism.  Unlike the older direct construction, its
`comm_d` witnesses are the quotient maps induced by the same `Z/B` lifts. -/
noncomputable def FilteredComplexMorphism.PageNaturality.toSpectralSequenceMorphism
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.PageNaturality g) :
    X.FC.toSpectralSequence X.bnd ⟶ Y.FC.toSpectralSequence Y.bnd where
  φ := fun ⟨s, k⟩ =>
    FilteredComplexMorphism.assocGradedMap
      (g : FilteredComplexMorphism X.FC Y.FC) s k
  preserves_Z := fun ⟨s, k⟩ r => ⟨N.liftZ s k r, N.liftZ_spec s k r⟩
  preserves_B := fun ⟨s, k⟩ r => ⟨N.liftB s k r, N.liftB_spec s k r⟩
  comm_d := by
    intro r ⟨s, k⟩
    let n : WithTop ℕ := ↑((r - (X.FC.toSpectralSequence X.bnd).r₀).toNat)
    refine ⟨N.toZBNaturality.pageMap s k n,
      N.toZBNaturality.pageMap (s + r) (k - 1) n, ?_⟩
    exact N.comm_d r s k

/-- A canonical page-natural morphism yields a spectral-sequence morphism
whose `Z` and `B` witnesses are the canonical lifts constructed above. -/
noncomputable def FilteredComplexMorphism.CanonicalPageNaturality.toSpectralSequenceMorphism
    {X Y : BoundedFilteredComplex C} {g : X ⟶ Y}
    (N : FilteredComplexMorphism.CanonicalPageNaturality g) :
    X.FC.toSpectralSequence X.bnd ⟶ Y.FC.toSpectralSequence Y.bnd :=
  N.toPageNaturality.toSpectralSequenceMorphism

/-- The canonical spectral-sequence morphism induced by a morphism of bounded
filtered complexes.  Its page maps are the maps forced by the natural cycle
and boundary lifts. -/
noncomputable def FilteredComplexMorphism.canonicalToSpectralSequenceMorphism
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y) :
    X.FC.toSpectralSequence X.bnd ⟶ Y.FC.toSpectralSequence Y.bnd :=
  g.canonicalPageNaturality.toSpectralSequenceMorphism

/-- The historical associated-graded component used by `toSS` agrees with the
canonical spectral-sequence morphism constructed above. -/
theorem FilteredComplexMorphism.toSpectralSequenceMorphism_eq_canonical
    {X Y : BoundedFilteredComplex C} (g : X ⟶ Y) :
    FilteredComplexMorphism.toSpectralSequenceMorphism g =
      g.canonicalToSpectralSequenceMorphism := by
  apply SpectralSequenceMorphism.ext
  rfl

end KIPBase.SpectralSequence
