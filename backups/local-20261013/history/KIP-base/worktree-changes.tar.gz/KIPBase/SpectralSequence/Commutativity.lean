/-
  KIPBase.SpectralSequence.Commutativity
  §2.12–2.19 Commutativity of ESS differentials

  Blueprint: §2.12–2.19 from arXiv:2412.10879 (KIP)
  Informal: informal/commutativity_ss.md

  Defines the homotopy commutative square of converging spectral
  sequences, and axiomatizes Theorem 2.12 (commutativity), its
  corollaries (2.15–2.19), and the induced map on ESS pages.
-/
import Mathlib
import KIPBase.SpectralSequence.Basic
import KIPBase.SpectralSequence.Convergence
import KIPBase.SpectralSequence.Crossing
import KIPBase.SpectralSequence.BoundedExtension
import KIPBase.SpectralSequence.FilteredComplexNaturality

namespace KIPBase.SpectralSequence

open CategoryTheory CategoryTheory.Limits

universe u v w

set_option linter.dupNamespace false

variable {C : Type u} [Category.{v} C] [Abelian C]

/-- ESS 的 `ssData` 在双次数 `⟨s, k⟩` 处的 `V` 就是两项复形的关联分次
    `assocGraded s k`（`toPreSS`/`ofPreSS` 的 `ssData` 字段与
    `toSSData` 的 `V` 字段都是直接定义，`rfl` 可判等）。
    作为独立的 `rfl` 引理封装，供陈述中以 `Eq.mpr` 搬运元素，
    避免在大型类型表达式里反复触发 `whnf` 超时。 -/
theorem ess_ssData_V {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (t : ω') (s k : ℤ) :
    (((ext.complex t).toSpectralSequence (ext.bounded t)).ssData ⟨s, k⟩).V =
      (ext.complex t).assocGraded s k :=
  rfl

/-- ESS 的微分次数：`diffDeg r = (r, -1)`（`toPreSS` 的 `diffDeg` 字段定义）。 -/
theorem ess_diffDeg {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (t : ω') (r : ℤ) :
    ((ext.complex t).toSpectralSequence (ext.bounded t)).diffDeg r = (r, -1) :=
  rfl

/-! ### Homotopy commutative square in the category of converging spectral sequences -/

/-- **收敛谱序列范畴中的交换方块**（新定义，范畴化形式）：
    四个收敛谱序列对象 `V₁ V₂ V₃ V₄` 与四个范畴态射
    ```
    V₁ --f--> V₂
    |p        |q
    v         v
    V₃ --g--> V₄
    ```
    满足范畴复合交换律 `f ≫ q = p ≫ g`
    （`≫` 为 `ConvergingSS` 范畴中的复合，自动含 E∞ 页与极限对象
    两个层面的交换性，由范畴公理保证）。 -/
structure ConvergingSSSquare {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} where
  /-- 左上对象 -/
  V₁ : ConvergingSS C ω ω'
  /-- 右上对象 -/
  V₂ : ConvergingSS C ω ω'
  /-- 左下对象 -/
  V₃ : ConvergingSS C ω ω'
  /-- 右下对象 -/
  V₄ : ConvergingSS C ω ω'
  /-- 上边态射 f : V₁ ⟶ V₂ -/
  f : V₁ ⟶ V₂
  /-- 左边态射 p : V₁ ⟶ V₃ -/
  p : V₁ ⟶ V₃
  /-- 右边态射 q : V₂ ⟶ V₄ -/
  q : V₂ ⟶ V₄
  /-- 下边态射 g : V₃ ⟶ V₄ -/
  g : V₃ ⟶ V₄
  /-- 方块交换：`f ≫ q = p ≫ g`（范畴中的复合交换）。 -/
  comm : f ≫ q = p ≫ g

/-- A homotopy commutative square of converging spectral sequences:
    ```
    V₁ --f--> V₂
    |p        |q
    v         v
    V₃ --g--> V₄
    ```
    Together with ESS data for each morphism and a commutativity condition
    expressing that `q ∘ f = g ∘ p` at the abutment level. -/
structure HomotopyCommSquare {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    (conv₁ : Convergence E₁ A₁ F₁) (conv₂ : Convergence E₂ A₂ F₂)
    (conv₃ : Convergence E₃ A₃ F₃) (conv₄ : Convergence E₄ A₄ F₄) where
  /-- Top morphism: V₁ → V₂ -/
  cmf : ConvergenceMorphism conv₁ conv₂
  /-- Left morphism: V₁ → V₃ -/
  cmp : ConvergenceMorphism conv₁ conv₃
  /-- Right morphism: V₂ → V₄ -/
  cmq : ConvergenceMorphism conv₂ conv₄
  /-- Bottom morphism: V₃ → V₄ -/
  cmg : ConvergenceMorphism conv₃ conv₄
  /-- Boundedness of the F₁-filtration. -/
  bnd₁ : F₁.IsBounded
  /-- Boundedness of the F₂-filtration. -/
  bnd₂ : F₂.IsBounded
  /-- Boundedness of the F₃-filtration. -/
  bnd₃ : F₃.IsBounded
  /-- Boundedness of the F₄-filtration. -/
  bnd₄ : F₄.IsBounded
  /-- Bounded ESS data for the top morphism f -/
  extf : BoundedExtensionSS conv₁ conv₂ cmf bnd₁ bnd₂
  /-- Bounded ESS data for the left morphism p -/
  extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃
  /-- Bounded ESS data for the right morphism q -/
  extq : BoundedExtensionSS conv₂ conv₄ cmq bnd₂ bnd₄
  /-- Bounded ESS data for the bottom morphism g -/
  extg : BoundedExtensionSS conv₃ conv₄ cmg bnd₃ bnd₄
  /-- Commutativity at the abutment level: q ∘ f = g ∘ p on target objects -/
  abutment_comm : ∀ (k' : ω'),
    cmf.aMap k' ≫ cmq.aMap k' = cmp.aMap k' ≫ cmg.aMap k'
  /-- Commutativity at the E∞-page level: q ∘ f = g ∘ p on E∞ classes -/
  eInfty_comm : ∀ (k : ω),
    cmf.eMap k ≫ cmq.eMap k = cmp.eMap k ≫ cmg.eMap k

/-- 从旧定义 `HomotopyCommSquare` 提取范畴方块：对象与态射逐字继承，
    交换性由 eMap/aMap 两个分量等式经 `ConvergenceMorphism.ext` 合并。 -/
def HomotopyCommSquare.toSquare {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) :
    ConvergingSSSquare (C := C) (ω := ω) (ω' := ω') where
  V₁ := ⟨E₁, A₁, F₁, conv₁⟩
  V₂ := ⟨E₂, A₂, F₂, conv₂⟩
  V₃ := ⟨E₃, A₃, F₃, conv₃⟩
  V₄ := ⟨E₄, A₄, F₄, conv₄⟩
  f := sq.cmf
  p := sq.cmp
  q := sq.cmq
  g := sq.cmg
  comm := ConvergenceMorphism.ext
    (funext fun k => sq.eInfty_comm k) (funext fun k' => sq.abutment_comm k')

/-- **新旧方块定义的等价性**（定理形式）：
    旧定义 `HomotopyCommSquare` 给出的范畴方块 `sq.toSquare`，
    其范畴复合交换律 `comm` 成立，当且仅当旧定义的两个分量
    交换条件 `eInfty_comm` 与 `abutment_comm` 同时成立。
    （`toSquare` 的 `comm` 字段正是由这两个条件构造，故此即
    构造的往返刻画。） -/
theorem HomotopyCommSquare.toSquare_comm {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) :
    sq.toSquare.comm = ConvergenceMorphism.ext
    (funext fun k => sq.eInfty_comm k) (funext fun k' => sq.abutment_comm k') :=
  rfl

/-- The vertical maps of a commutative square form a filtered chain map from
the f-extension complex to the g-extension complex. -/
noncomputable def extensionSquareMap {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') :
    FilteredComplexMorphism (sq.extf.complex t) (sq.extg.complex t) where
  f k := by
    by_cases h1 : k = 1
    · subst k
      exact sq.cmp.aMap t
    · by_cases h0 : k = 0
      · subst k
        exact sq.cmq.aMap t
      · exact 0
  comm_d := by
    intro k
    by_cases h1 : k = 1
    · subst k
      simpa [BoundedExtensionSS.complex, underlyingComplex, twoTermDiff, twoTermObj]
        using (sq.abutment_comm t).symm
    · by_cases h0 : k = 0
      · subst k
        simp [BoundedExtensionSS.complex, underlyingComplex, twoTermDiff, h1]
      · simp [BoundedExtensionSS.complex, underlyingComplex, twoTermDiff, h1, h0]
  filt_compat := by
    intro s k
    by_cases h1 : k = 1
    · subst k
      simpa [BoundedExtensionSS.complex, underlyingComplex, twoTermFil] using
        sq.cmp.filtration_compat s t
    · by_cases h0 : k = 0
      · subst k
        simpa [BoundedExtensionSS.complex, underlyingComplex, twoTermFil, h1] using
          sq.cmq.filtration_compat s t
      · refine ⟨0, ?_⟩
        simp [BoundedExtensionSS.complex, underlyingComplex, twoTermFil, h1, h0]

/-- The spectral-sequence morphism induced by the vertical pair `(p,q)` of a
commutative square, viewed as a map from the f-extension SS to the g-extension
SS. -/
noncomputable def extensionSquareSSMorphism {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') :
    SpectralSequenceMorphism (sq.extf.ess t) (sq.extg.ess t) := by
  exact FilteredComplexMorphism.canonicalToSpectralSequenceMorphism
    (X := ⟨sq.extf.complex t, sq.extf.bounded t⟩)
    (Y := ⟨sq.extg.complex t, sq.extg.bounded t⟩)
    (extensionSquareMap sq t)

/-- Component formula for the map of extension spectral sequences induced by
a commutative square.  This exposes the actual associated-graded map needed
when comparing representatives or E∞ classes. -/
theorem extensionSquareSSMorphism_φ {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') (s k : ℤ) :
    (extensionSquareSSMorphism sq t).φ ⟨s, k⟩ =
      FilteredComplexMorphism.assocGradedMap (extensionSquareMap sq t) s k :=
  rfl

/-- The extension-square map uses the canonical filtered-complex naturality
construction.  In particular, its page maps are the kernel/image lifts
constructed in `FilteredComplexNaturality`, rather than merely arbitrary
witnesses for `SpectralSequenceMorphism.comm_d`. -/
theorem extensionSquareSSMorphism_eq_canonical
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') :
    extensionSquareSSMorphism sq t =
      FilteredComplexMorphism.canonicalToSpectralSequenceMorphism
        (X := ⟨sq.extf.complex t, sq.extf.bounded t⟩)
        (Y := ⟨sq.extg.complex t, sq.extg.bounded t⟩)
        (extensionSquareMap sq t) := by
  rfl

/-- A map of extension spectral sequences together with the assertion that it
is precisely the map induced by the vertical pair `(p,q)`. -/
structure InducedESSMap {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄) (t : ω') where
  hom : SpectralSequenceMorphism (sq.extf.ess t) (sq.extg.ess t)
  is_induced : hom = extensionSquareSSMorphism sq t

/-! ### ESS differential relation predicate -/

/-- The ESS differential `d_n` sends the class at bidegree `k₁` to the class
    at bidegree `k₂`: expressed as the ESS differential object being nontrivial
    and witnessing the relation. This is a Prop-level predicate abstracting the
    ESS differential relation from Proposition 2.5. -/
def ESSRelation {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (n : ℤ) (k₁ k₂ : ω) : Prop :=
  ¬IsZero (ext.essDiff n k₁ k₂)

/-- The ESS differential `d_n` sends the class at `k₁` to zero at `k₂`. -/
def ESSVanishes {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (n : ℤ) (k₁ k₂ : ω) : Prop :=
  IsZero (ext.essDiff n k₁ k₂)

/-- Concrete pagewise vanishing form for an ESS differential relation.

The target of `DifferentialRelation` is an ambient representative, hence a
zero differential means that this target is a boundary on the relevant page;
it must not be required to be literally the zero morphism. -/
def ESSVanishesAt {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (t : ω') (r s k : ℤ) {T : C}
    (x : T ⟶ (ext.complex t).assocGraded s k) : Prop :=
  ∀ y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1),
    ESSRelationAt ext t r s k x y →
      Subobject.Factors
        (((ext.ess t).ssData (⟨s, k⟩ + (ext.ess t).diffDeg r)).B
          (↑(r - (ext.ess t).r₀).toNat : WithTop ℕ))
        (by
          have hdeg : (⟨s, k⟩ + (ext.ess t).diffDeg r : ℤ × ℤ) =
              ⟨s + r, k - 1⟩ := by
            rfl
          exact cast (congrArg (fun q : ℤ × ℤ =>
            T ⟶ ((ext.ess t).ssData q).V) hdeg.symm) y)

/-- No-crossing condition for an ESS differential datum, bundled with the
    convergence data. Takes the differential datum as a parameter
    (following Extension.lean patterns). -/
def ESSNoCrossing {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {_conv₁ : Convergence E₁ A₁ F₁} {_conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism _conv₁ _conv₂}
    {_bnd₁ : F₁.IsBounded} {_bnd₂ : F₂.IsBounded}
    (_ext : BoundedExtensionSS _conv₁ _conv₂ cm _bnd₁ _bnd₂)
    (dd : DifferentialDatum C ω) : Prop :=
  NoCrossing dd

/-- No-crossing-range condition for an ESS differential datum. -/
def ESSNoCrossingRange {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {_conv₁ : Convergence E₁ A₁ F₁} {_conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism _conv₁ _conv₂}
    {_bnd₁ : F₁.IsBounded} {_bnd₂ : F₂.IsBounded}
    (_ext : BoundedExtensionSS _conv₁ _conv₂ cm _bnd₁ _bnd₂)
    (dd : DifferentialDatum C ω) (p : ℤ) : Prop :=
  NoCrossingRange dd p

/-- A crossing datum tied to a concrete extension spectral sequence.

Unlike a bare `DifferentialDatum`, this records that the datum belongs to the
ESS produced by `ext.complex t`, uses the requested page and source bidegree,
and measures filtration by the first ESS coordinate.  These equalities are
needed before a `NoCrossing` hypothesis can rule out a relation constructed
inside that ESS. -/
structure ESSDifferentialDatum {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (t : ω') (r s k : ℤ) where
  datum : DifferentialDatum C (ℤ × ℤ)
  spectralSequence_eq : datum.E = ext.ess t
  page_eq : datum.r = r
  source_eq : datum.k = ⟨s, k⟩
  filtDeg_eq : datum.filtDeg = fun b => b.1

/-- The no-crossing predicate for an ESS-tied datum. -/
abbrev ESSDifferentialDatum.NoCrossing
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t r s k} (dd : ESSDifferentialDatum ext t r s k) : Prop :=
  KIPBase.SpectralSequence.NoCrossing dd.datum

/-- A no-crossing hypothesis on an ESS datum rules out crossings of every
concrete relation at that same page and source bidegree. -/
theorem ESSDifferentialDatum.noRelationCrossing
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    (dd : ESSDifferentialDatum ext t r s k)
    (hnc : dd.NoCrossing)
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (h : ESSRelationAt ext t r s k x y) :
    ¬ RelationCrossedBy (ext.ess t) (fun b => b.1) r ⟨s, k⟩ x y h := by
  intro hcross
  rcases hcross with ⟨a, ha, m, k', x', y', hsource, hessential, hlower, hupper⟩
  apply hnc
  refine ⟨a, ha, m, k', ?_, ?_, ?_, ?_⟩
  · rw [dd.filtDeg_eq, dd.source_eq]
    exact hsource
  · rw [dd.spectralSequence_eq]
    exact hessential.isEssentialAt
  · rw [dd.filtDeg_eq, dd.source_eq]
    change s + 1 ≤ s + a + m
    change s + 1 ≤ k'.1 + m at hlower
    simpa [hsource] using hlower
  · rw [dd.filtDeg_eq, dd.source_eq, dd.page_eq]
    change s + a + m ≤ s + r
    change k'.1 + m ≤ s + r at hupper
    simpa [hsource] using hupper

/-- Eliminate a prospective essential crossing whose target lies in the range
forbidden by an ESS `NoCrossingRange` hypothesis. -/
theorem ESSDifferentialDatum.noCrossingInRange
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k p : ℤ}
    (dd : ESSDifferentialDatum ext t r s k)
    (hnc : NoCrossingRange dd.datum p)
    (a m : ℤ) (ha : 0 < a) (k' : ℤ × ℤ)
    (hsource : k'.1 = s + a)
    (hessential : IsEssentialAt (ext.ess t) m k')
    (hlower : p ≤ k'.1 + m)
    (hupper : k'.1 + m ≤ s + r) : False := by
  apply hnc
  refine ⟨a, ha, m, k', ?_, ?_, ?_, ?_⟩
  · rw [dd.filtDeg_eq, dd.source_eq]
    exact hsource
  · rw [dd.spectralSequence_eq]
    exact hessential
  · rw [dd.filtDeg_eq, dd.source_eq]
    simpa [hsource] using hlower
  · rw [dd.filtDeg_eq, dd.source_eq, dd.page_eq]
    simpa [hsource] using hupper

/-- A completely no-crossing ESS differential has no crossing in every
higher target-filtration range.  This is the form needed when specializing
the range hypothesis of Theorem 2.12 to Corollary 2.15. -/
theorem ESSDifferentialDatum.noCrossingInRange_of_noCrossing
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k p : ℤ}
    (dd : ESSDifferentialDatum ext t r s k)
    (hnc : dd.NoCrossing) (hp : s + 1 ≤ p)
    (a m : ℤ) (ha : 0 < a) (k' : ℤ × ℤ)
    (hsource : k'.1 = s + a)
    (hessential : IsEssentialAt (ext.ess t) m k')
    (hlower : p ≤ k'.1 + m)
    (hupper : k'.1 + m ≤ s + r) : False := by
  apply dd.noCrossingInRange (NoCrossing.toRange dd.datum hnc ?_)
    a m ha k' hsource hessential hlower hupper
  rw [dd.filtDeg_eq, dd.source_eq]
  exact hp

/-- Concrete filtered-complex data realizing a relation in an extension
    spectral sequence.  This is the missing bridge between a statement about
    a commutative square and a `DifferentialRelation` in `ext.ess t`. -/
structure ESSRelationLiftData {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂)
    (t : ω') (r s k : ℤ) {T : C}
    (x : T ⟶ (ext.complex t).assocGraded s k)
    (y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)) where
  nonneg : 0 ≤ r
  sourceLift : T ⟶ Subobject.underlying.obj ((ext.complex t).fil s k)
  targetLift : T ⟶ Subobject.underlying.obj ((ext.complex t).fil (s + r) (k - 1))
  source_lift : (ext.complex t).IsLift s k sourceLift x
  target_lift : (ext.complex t).IsLift (s + r) (k - 1) targetLift y
  differential_eq : sourceLift ≫ (ext.complex t).filDiff s k =
    targetLift ≫ Subobject.ofLE ((ext.complex t).fil (s + r) (k - 1))
      ((ext.complex t).fil s (k - 1))
      ((ext.complex t).fil_anti_of_le (k - 1) (by omega))

/-- Every concrete ESS relation has filtered lifts realizing its defining
differential equation.  This is the lift direction needed from Proposition
2.5 before the four relations of Theorem 2.12 can be compared. -/
noncomputable def ESSRelationLiftData.ofESSRelation
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C} [Projective T]
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (hr : 0 ≤ r) (h : ESSRelationAt ext t r s k x y) :
    ESSRelationLiftData ext t r s k x y := by
  let hLift := FilteredComplex.lift_of_differentialRelation
    (ext.complex t) (ext.bounded t) r hr s k h
  exact
    { nonneg := hr
      sourceLift := hLift.choose
      targetLift := hLift.choose_spec.choose
      source_lift := hLift.choose_spec.choose_spec.1
      target_lift := hLift.choose_spec.choose_spec.2.1
      differential_eq := hLift.choose_spec.choose_spec.2.2 }

/-- A concrete filtered lift datum gives the associated ESS differential
    relation. -/
theorem ESSRelationLiftData.relation {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C} {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (h : ESSRelationLiftData ext t r s k x y) :
    DifferentialRelation (ext.ess t) r ⟨s, k⟩ x y :=
  FilteredComplex.differentialRelation_of_lift (ext.complex t) (ext.bounded t)
    r h.nonneg s k h.source_lift h.target_lift h.differential_eq

/-- A no-crossing datum selects the intended target representative once a
failed candidate lift is known to yield an actual crossing witness.  This is
the representative-selection step used in the Mahowald argument, stated with
the witness that makes it logically sound. -/
theorem ESSRelationLiftData.selectTargetLift
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (L : ESSRelationLiftData ext t r s k x y)
    (dd : ESSDifferentialDatum ext t r s k) (hnc : dd.NoCrossing)
    (hr : 0 ≤ r)
    {candidate : T ⟶ Subobject.underlying.obj ((ext.complex t).fil (s + r) (k - 1))}
    (hcandidate : L.sourceLift ≫ (ext.complex t).filDiff s k =
      candidate ≫ Subobject.ofLE ((ext.complex t).fil (s + r) (k - 1))
        ((ext.complex t).fil s (k - 1))
        ((ext.complex t).fil_anti_of_le (k - 1) (by omega)))
    (producesCrossing :
      ¬ (ext.complex t).IsLift (s + r) (k - 1) candidate y →
        CrossingWitnessData (ext.ess t) (fun p => p.1) r ⟨s, k⟩ x y L.relation) :
    (ext.complex t).IsLift (s + r) (k - 1) candidate y := by
  exact BoundedExtensionSS.rel_eq_of_not_crossed_of_witness ext t r hr s k
    L.relation (ESSDifferentialDatum.noRelationCrossing dd hnc L.relation)
    L.source_lift hcandidate producesCrossing

/-- Input for selecting a specified target representative under no crossing.
The leading-term argument is isolated in `failureCrosses`: if the proposed
target failed to represent `y`, it must exhibit an actual essential crossing.
This is the only non-formal ingredient; the selection itself is derived by
the theorem below. -/
structure ESSNoCrossingSelectionInput
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (L : ESSRelationLiftData ext t r s k x y)
    (dd : ESSDifferentialDatum ext t r s k) where
  noCrossing : dd.NoCrossing
  candidate : T ⟶ Subobject.underlying.obj ((ext.complex t).fil (s + r) (k - 1))
  differential_eq : L.sourceLift ≫ (ext.complex t).filDiff s k =
    candidate ≫ Subobject.ofLE ((ext.complex t).fil (s + r) (k - 1))
      ((ext.complex t).fil s (k - 1))
      ((ext.complex t).fil_anti_of_le (k - 1) (by
        have hr : 0 ≤ r := L.nonneg
        omega))
  failureCrosses :
    ¬ (ext.complex t).IsLift (s + r) (k - 1) candidate y →
      CrossingWitnessData (ext.ess t) (fun p => p.1) r ⟨s, k⟩ x y L.relation

/-- A no-crossing selection input proves that its candidate is the intended
target lift. -/
theorem ESSNoCrossingSelectionInput.target_lift
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    {L : ESSRelationLiftData ext t r s k x y}
    {dd : ESSDifferentialDatum ext t r s k}
    (H : ESSNoCrossingSelectionInput L dd) :
    (ext.complex t).IsLift (s + r) (k - 1) H.candidate y :=
  L.selectTargetLift dd H.noCrossing L.nonneg H.differential_eq H.failureCrosses

/-- The selected target has the correct page class.  This is the stable
conclusion to use when later source-lift comparisons can alter an ambient
target by a page boundary. -/
theorem ESSRelationLiftData.target_congruent_of_differential_eq
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    (L : ESSRelationLiftData ext t r s k x y)
    {candidate : T ⟶ Subobject.underlying.obj ((ext.complex t).fil (s + r) (k - 1))}
    (hd : L.sourceLift ≫ (ext.complex t).filDiff s k =
      candidate ≫ Subobject.ofLE ((ext.complex t).fil (s + r) (k - 1))
        ((ext.complex t).fil s (k - 1))
        ((ext.complex t).fil_anti_of_le (k - 1) (by omega))) :
    ESSCongruentTargetsAt ext t r s k
      (candidate ≫ (ext.complex t).filToAssocGraded (s + r) (k - 1)) y := by
  have hCandidateRelation : ESSRelationAt ext t r s k x
      (candidate ≫ (ext.complex t).filToAssocGraded (s + r) (k - 1)) := by
    exact FilteredComplex.differentialRelation_of_lift
      (ext.complex t) (ext.bounded t) r L.nonneg s k
      L.source_lift (by rfl) hd
  exact ESSRelationAt.targets_congruent hCandidateRelation L.relation

/-- The selected target has the correct page class.  This is the stable
conclusion to use when later source-lift comparisons can alter an ambient
target by a page boundary. -/
theorem ESSNoCrossingSelectionInput.target_congruent
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    {ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂}
    {t : ω'} {r s k : ℤ} {T : C}
    {x : T ⟶ (ext.complex t).assocGraded s k}
    {y : T ⟶ (ext.complex t).assocGraded (s + r) (k - 1)}
    {L : ESSRelationLiftData ext t r s k x y}
    {dd : ESSDifferentialDatum ext t r s k}
    (H : ESSNoCrossingSelectionInput L dd) :
    ESSCongruentTargetsAt ext t r s k
      (H.candidate ≫ (ext.complex t).filToAssocGraded (s + r) (k - 1)) y := by
  exact L.target_congruent_of_differential_eq H.differential_eq

/-! ### Theorem 2.12 — Commutativity (main theorem) -/

section ESSCommutativityLemmas

variable {ω : Type w} [AddCommGroup ω] [DecidableEq ω] {ω' : Type w}
variable (sq : ConvergingSSSquare (C := C) (ω := ω) (ω' := ω'))
variable (bnd₁ : sq.V₁.F.IsBounded) (bnd₂ : sq.V₂.F.IsBounded)
variable (bnd₃ : sq.V₃.F.IsBounded) (bnd₄ : sq.V₄.F.IsBounded)
variable (extf : BoundedExtensionSS sq.V₁.conv sq.V₂.conv sq.f bnd₁ bnd₂)
variable (extp : BoundedExtensionSS sq.V₁.conv sq.V₃.conv sq.p bnd₁ bnd₃)
variable (extq : BoundedExtensionSS sq.V₂.conv sq.V₄.conv sq.q bnd₂ bnd₄)
variable (extg : BoundedExtensionSS sq.V₃.conv sq.V₄.conv sq.g bnd₃ bnd₄)
variable (n m l sfx : ℤ) (t : ω') {T : C}
variable (x : T ⟶ (extf.complex t).assocGraded sfx 1)
variable (y : T ⟶ (extf.complex t).assocGraded (sfx + n) 0)
variable (z : T ⟶ (extp.complex t).assocGraded (sfx + m) 0)
variable (w : T ⟶ (extg.complex t).assocGraded (sfx + m + l) 0)

/-- `w` 同时作为 ESS(g) 的目标与 ESS(q) 的目标出现：两者对象均为
    `F₄` 层在过滤 `sfx+m+l`、次数 `0` 的关联分次，定义性相等（`rfl`）。 -/
lemma ess_g_q_assocGraded :
    (extg.complex t).assocGraded (sfx + m + l) 0 =
      (extq.complex t).assocGraded (sfx + m + l) 0 := rfl

/-- **引理 A1**（相邻过滤层的消失）：若 `m+l ≥ n`，则 `yl` 的过滤微分
    与 `wl` 都经 `F^{s+n} ↪ F^{s+n-1}` 分解；所以二者之差在
    `gr^{s+n-1}` 中为零。
    数学注记：q 复形中 `y` 的 lift `yl` 是 `A₂(t)` 的元素
    （类型为 `F^{s+n}A₂⁰` 的底层对象），微分后落在 `F^{s+n}A₄⁰`；
    `wl` 是 `A₄(t)` 的元素（`F^{s+m+l}A₄⁰`），两者相减在 `A₄(t)` 中进行。 -/
theorem essComm_auxA1
    (yl : T ⟶ Subobject.underlying.obj ((extq.complex t).fil (sfx + n) 1))
    (hy_lift : (extq.complex t).IsLift (sfx + n) 1 yl
      (Eq.mpr (congrArg (fun X : C => T ⟶ X) (ess_ssData_V extq t (sfx + n) 1).symm) y))
    (wl : T ⟶ Subobject.underlying.obj ((extq.complex t).fil (sfx + m + l) 0))
    (hw_lift : (extq.complex t).IsLift (sfx + m + l) 0 wl
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (ess_g_q_assocGraded sq bnd₂ bnd₃ bnd₄ extq extg m l sfx t).symm) w))
    (hmln : 0 ≤ m + l - n) :
    (yl ≫ (extq.complex t).filDiff (sfx + n) 1 ≫
      Subobject.ofLE ((extq.complex t).fil (sfx + n) 0)
        ((extq.complex t).fil (sfx + n - 1) 0)
        ((extq.complex t).fil_anti_of_le 0 (by omega)) -
      wl ≫ Subobject.ofLE ((extq.complex t).fil (sfx + m + l) 0)
        ((extq.complex t).fil (sfx + n - 1) 0)
        ((extq.complex t).fil_anti_of_le 0 (by omega))) ≫
        (extq.complex t).filToAssocGraded (sfx + n - 1) 0 = 0 := by
  let FC := extq.complex t
  let i : Subobject.underlying.obj (FC.fil (sfx + n) 0) ⟶
      Subobject.underlying.obj (FC.fil (sfx + n - 1) 0) :=
    Subobject.ofLE (FC.fil (sfx + n) 0) (FC.fil (sfx + n - 1) 0)
      (FC.fil_anti_of_le 0 (by omega))
  let j : Subobject.underlying.obj (FC.fil (sfx + n - 1 + 1) 0) ⟶
      Subobject.underlying.obj (FC.fil (sfx + n - 1) 0) :=
    Subobject.ofLE (FC.fil (sfx + n - 1 + 1) 0) (FC.fil (sfx + n - 1) 0)
      (FC.fil_anti (sfx + n - 1) 0)
  let e : Subobject.underlying.obj (FC.fil (sfx + n) 0) ⟶
      Subobject.underlying.obj (FC.fil (sfx + n - 1 + 1) 0) :=
    eqToHom (by congr 2 <;> omega)
  have he : e ≫ (FC.fil (sfx + n - 1 + 1) 0).arrow =
      (FC.fil (sfx + n) 0).arrow := by
    dsimp [e]
    exact Subobject.arrow_congr _ _ (by congr 1 <;> omega)
  have hi_factor : i = e ≫ j := by
    apply (inferInstance : Mono (FC.fil (sfx + n - 1) 0).arrow).right_cancellation
    dsimp [i, j]
    simp only [Category.assoc, Subobject.ofLE_arrow]
    rw [he]
  have hi : i ≫ FC.filToAssocGraded (sfx + n - 1) 0 = 0 := by
    rw [hi_factor, Category.assoc]
    change e ≫ j ≫ cokernel.π j = 0
    rw [cokernel.condition, comp_zero]
  have hyl : yl ≫ FC.filDiff (sfx + n) 1 ≫ i ≫
      FC.filToAssocGraded (sfx + n - 1) 0 = 0 := by
    simp only [Category.assoc, hi, comp_zero]
  have hle : FC.fil (sfx + m + l) 0 ≤ FC.fil (sfx + n) 0 :=
    FC.fil_anti_of_le 0 (by omega)
  have hwl_factor :
      Subobject.ofLE (FC.fil (sfx + m + l) 0) (FC.fil (sfx + n - 1) 0)
          (FC.fil_anti_of_le 0 (by omega)) =
        Subobject.ofLE (FC.fil (sfx + m + l) 0) (FC.fil (sfx + n) 0) hle ≫ i := by
    apply (inferInstance : Mono (FC.fil (sfx + n - 1) 0).arrow).right_cancellation
    dsimp [i]
    simp only [Category.assoc, Subobject.ofLE_arrow]
  change (yl ≫ FC.filDiff (sfx + n) 1 ≫ i -
      wl ≫ Subobject.ofLE (FC.fil (sfx + m + l) 0) (FC.fil (sfx + n - 1) 0) _) ≫
      FC.filToAssocGraded (sfx + n - 1) 0 = 0
  rw [Preadditive.sub_comp, hwl_factor]
  simp only [Category.assoc, hyl, hi, comp_zero, sub_zero]

/-- **引理 B1**（filtered lift 给出候选关系）：候选页数必须显式给出。
    仅有两个任意 lift 不可能构造一个严格小于 `m+l-n` 的自然数页；所需的
    filtered differential equation 则正是 `DifferentialRelation` 的复形实现。 -/
theorem essComm_auxB1
    (r' : ℤ) (hr' : 0 ≤ r') (_hr'_lt : r' < m + l - n)
    (yq : T ⟶ (extq.complex t).assocGraded (sfx + n) 1)
    (yl : T ⟶ Subobject.underlying.obj ((extq.complex t).fil (sfx + n) 1))
    (hy_lift : (extq.complex t).IsLift (sfx + n) 1 yl yq)
    (y₀ : T ⟶ (extq.complex t).assocGraded (sfx + n + r') 0)
    (y₀l : T ⟶ Subobject.underlying.obj ((extq.complex t).fil (sfx + n + r') 0))
    (hy₀_lift : (extq.complex t).IsLift (sfx + n + r') 0 y₀l y₀)
    (hd : yl ≫ (extq.complex t).filDiff (sfx + n) 1 =
      y₀l ≫ Subobject.ofLE ((extq.complex t).fil (sfx + n + r') 0)
        ((extq.complex t).fil (sfx + n) 0)
        ((extq.complex t).fil_anti_of_le 0 (by omega))) :
    DifferentialRelation (extq.ess t) r' ⟨sfx + n, 1⟩ yq y₀ := by
  exact FilteredComplex.differentialRelation_of_lift (extq.complex t)
    (extq.bounded t) r' hr' (sfx + n) 1 hy_lift hy₀_lift hd

/-
The declarations through the end of `ESSCommutativityLemmas` below were
provisional statements of Theorem 2.12 and its corollaries.  They are not
sound with their former hypotheses: the no-crossing data lives on the input
spectral sequences, whereas the claimed relations live on `ext.ess t`, and
the required common filtered lifts are absent.  They are intentionally kept
out of the Lean environment until the square-to-lift construction is proved.

/-- **引理 B2**（non-crossing 排除竞争）：`_hf_or_p_nc`、`_hg_nc_range`、
    `_hq_nc` 联合蕴含：从 `y` 出发不存在次数严格小于 `m+l-n` 且目标过滤
    在 `[s+n+1, s+m+l]` 内的 essential 微分关系。暂 sorry。 -/
theorem essComm_auxB2
    (ddf : DifferentialDatum C ω) (ddp : DifferentialDatum C ω)
    (ddg : DifferentialDatum C ω) (ddq : DifferentialDatum C ω)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp)
    (_hg_nc_range : ∀ (s kval : ℤ), 0 < kval → kval ≤ m + l - n →
      NoCrossingRange ddg (s + n + kval))
    (_hq_nc : NoCrossing ddq) :
    ∀ (r' : ℤ), 0 ≤ r' → r' < m + l - n →
      ∀ (y₀ : T ⟶ (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
        (⟨sfx + n, 1⟩ + ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
          r')).V),
        ¬ EssentialDifferentialRelation
          ((extq.complex t).toSpectralSequence (extq.bounded t)) r' ⟨sfx + n, 1⟩
          (Eq.mpr (congrArg (fun X : C => T ⟶ X)
            (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
              ⟨sfx + n, 1⟩).V = (extq.complex t).assocGraded (sfx + n) 1 from rfl)) y)
          y₀ := by
  sorry

/-- **引理 B3**（`_hq_vanish` 排除残余次数）：若竞争关系次数恰为 `kval-1`，
    则 `_hq_vanish` 迫使目标为 `0`。暂 sorry。 -/
theorem essComm_auxB3
    (kval : ℤ) (_hk_pos : 0 < kval)
    (_hq_vanish : ∀ (y₀ : T ⟶ (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
        (⟨sfx + n, 1⟩ + ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
          (kval - 1))).V),
      DifferentialRelation ((extq.complex t).toSpectralSequence (extq.bounded t))
        (kval - 1) ⟨sfx + n, 1⟩
        (Eq.mpr (congrArg (fun X : C => T ⟶ X)
          (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
            ⟨sfx + n, 1⟩).V = (extq.complex t).assocGraded (sfx + n) 1 from rfl)) y)
        y₀ → y₀ = 0)
    (y₀ : T ⟶ (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
      (⟨sfx + n, 1⟩ + ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
        (kval - 1))).V)
    (hrel : DifferentialRelation ((extq.complex t).toSpectralSequence (extq.bounded t))
      (kval - 1) ⟨sfx + n, 1⟩
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
          ⟨sfx + n, 1⟩).V = (extq.complex t).assocGraded (sfx + n) 1 from rfl)) y)
      y₀) :
    y₀ = 0 :=
  _hq_vanish y₀ hrel

/-- **引理 C1**（组装结论关系）：`y` 在 ESS(q) 中存在页 `m+l-n` 的 Z 提升，
    使 `y` 与 `w` 满足 `DifferentialRelation` 的页上等式。
    由 `A1` 的候选 lift 经 `B1–B3` 排除所有竞争修正后得到。暂 sorry。 -/
theorem essComm_auxC1 :
    DifferentialRelation ((extq.complex t).toSpectralSequence (extq.bounded t))
      (m + l - n) ⟨sfx + n, 1⟩
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
          ⟨sfx + n, 1⟩).V = (extq.complex t).assocGraded (sfx + n) 1 from rfl)) y)
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
          (⟨sfx + n, 1⟩ + ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
            (m + l - n))).V = (extg.complex t).assocGraded (sfx + m + l) 0 from by
          have h : (⟨sfx + n, 1⟩ +
              ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
                (m + l - n) : ℤ × ℤ) = ⟨sfx + m + l, 0⟩ := by
            show (⟨sfx + n, 1⟩ + (m + l - n, -1) : ℤ × ℤ) = ⟨sfx + m + l, 0⟩
            apply Prod.ext
            · show sfx + n + (m + l - n) = sfx + m + l; ring
            · rfl
          rw [h]
          show ((extq.complex t).toSSData (extq.bounded t) (sfx + m + l) 0).V =
            (extg.complex t).assocGraded (sfx + m + l) 0
          rw [ess_g_q_assocGraded sq bnd₂ bnd₃ bnd₄ extq extg m l sfx t]
          rfl)) w) := by
  sorry

/-- 结论的 w 侧搬运：与主定理结论中的 cast 逐项相同，但写成
    「essq 的关联分次 = ESS(q) 页对象」方向，供 `Eq.mpr` 使用。 -/
lemma essComm_concl_cast :
    (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
      (⟨sfx + n, 1⟩ + ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
        (m + l - n))).V =
      (extg.complex t).assocGraded (sfx + m + l) 0 := by
  have h : (⟨sfx + n, 1⟩ +
      ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
        (m + l - n) : ℤ × ℤ) = ⟨sfx + m + l, 0⟩ := by
    show (⟨sfx + n, 1⟩ + (m + l - n, -1) : ℤ × ℤ) = ⟨sfx + m + l, 0⟩
    apply Prod.ext
    · show sfx + n + (m + l - n) = sfx + m + l; ring
    · rfl
  rw [h]
  show ((extq.complex t).toSSData (extq.bounded t) (sfx + m + l) 0).V =
    (extg.complex t).assocGraded (sfx + m + l) 0
  rw [ess_g_q_assocGraded sq bnd₂ bnd₃ bnd₄ extq extg m l sfx t]
  rfl

end ESSCommutativityLemmas

/-- **Theorem 2.12**: Commutativity of ESS differentials (full version).

    Given a commutative square in the `ConvergingSS` category and:
    1. `d_n^f(x) = y`（表述为 ESS 微分关系 `DifferentialRelation`）
    2. `d_m^p(x) = z`（微分关系）
    3. One of (1) or (2) has no crossing
    4. `d_l^g(z) = w` with no crossing hitting Fil ≥ s + n + k (for 0 < k ≤ m + l − n)
    5. `d_{k-1}^q(y) = 0` with no crossing

    Then `d_{m+l-n}^q(y) = w`（微分关系）。
    所有「`d(x) = y`」均按 `DifferentialRelation` 表述。
    **关键**：四个关系共享同一批广义元素——`x` 同时是 ESS(f) 与 ESS(p) 的源
    （两者在次数 `1` 处的关联分次定义性相同，均为 `F₁` 层），
    `y` 同时是 ESS(f) 的目标与 ESS(q) 的源（均为 `F₂` 层次数 `0`），
    `z` 同时是 ESS(p) 的目标与 ESS(g) 的源（均为 `F₃` 层次数 `0`），
    `w` 同时是 ESS(g) 的目标与 ESS(q) 的目标（均为 `F₄` 层次数 `0`）。 -/
theorem essCommutativity {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w}
    (sq : ConvergingSSSquare (C := C) (ω := ω) (ω' := ω'))
    (bnd₁ : sq.V₁.F.IsBounded) (bnd₂ : sq.V₂.F.IsBounded)
    (bnd₃ : sq.V₃.F.IsBounded) (bnd₄ : sq.V₄.F.IsBounded)
    (extf : BoundedExtensionSS sq.V₁.conv sq.V₂.conv sq.f bnd₁ bnd₂)
    (extp : BoundedExtensionSS sq.V₁.conv sq.V₃.conv sq.p bnd₁ bnd₃)
    (extq : BoundedExtensionSS sq.V₂.conv sq.V₄.conv sq.q bnd₂ bnd₄)
    (extg : BoundedExtensionSS sq.V₃.conv sq.V₄.conv sq.g bnd₃ bnd₄)
    (n m l : ℤ) (sfx : ℤ) (t : ω')
    (kx ky kz kw : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hl : 0 ≤ l)
    {T : C}
    (x : T ⟶ (extf.complex t).assocGraded sfx 1)
    (y : T ⟶ (extf.complex t).assocGraded (sfx + n) 0)
    (z : T ⟶ (extp.complex t).assocGraded (sfx + m) 0)
    (w : T ⟶ (extg.complex t).assocGraded (sfx + m + l) 0)
    -- 1. `d_n^f(x) = y`：ESS(f) 中的微分关系
    -- （`Eq.mpr` 精确搬运：对象等式均为 `rfl`，避免 `whnf` 超时）
    (_hf_rel : DifferentialRelation ((extf.complex t).toSpectralSequence (extf.bounded t))
      n ⟨sfx, 1⟩
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extf.complex t).toSpectralSequence (extf.bounded t)).ssData ⟨sfx, 1⟩).V =
          (extf.complex t).assocGraded sfx 1 from rfl)) x)
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extf.complex t).toSpectralSequence (extf.bounded t)).ssData
          (⟨sfx, 1⟩ + ((extf.complex t).toSpectralSequence (extf.bounded t)).diffDeg n)).V =
          (extf.complex t).assocGraded (sfx + n) 0 from rfl)) y))
    -- 2. `d_m^p(x) = z`：ESS(p) 中的微分关系（源与 (1) 共享同一个 `x`）
    (_hp_rel : DifferentialRelation ((extp.complex t).toSpectralSequence (extp.bounded t))
      m ⟨sfx, 1⟩
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extp.complex t).toSpectralSequence (extp.bounded t)).ssData ⟨sfx, 1⟩).V =
          (extp.complex t).assocGraded sfx 1 from rfl)) x)
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extp.complex t).toSpectralSequence (extp.bounded t)).ssData
          (⟨sfx, 1⟩ + ((extp.complex t).toSpectralSequence (extp.bounded t)).diffDeg m)).V =
          (extp.complex t).assocGraded (sfx + m) 0 from rfl)) z))
    (ddf : DifferentialDatum C ω)
    (_hddf : ddf.E = sq.V₁.E ∧ ddf.r = n ∧ ddf.k = kx)
    (ddp : DifferentialDatum C ω)
    (_hddp : ddp.E = sq.V₁.E ∧ ddp.r = m ∧ ddp.k = kx)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp)
    -- 4. `d_l^g(z) = w`：ESS(g) 中的微分关系（源与 (2) 共享同一个 `z`）
    (_hg_rel : DifferentialRelation ((extg.complex t).toSpectralSequence (extg.bounded t))
      l ⟨sfx + m, 1⟩
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extg.complex t).toSpectralSequence (extg.bounded t)).ssData
          ⟨sfx + m, 1⟩).V =
          (extg.complex t).assocGraded (sfx + m) 1 from rfl)) z)
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extg.complex t).toSpectralSequence (extg.bounded t)).ssData
          (⟨sfx + m, 1⟩ + ((extg.complex t).toSpectralSequence (extg.bounded t)).diffDeg l)).V =
          (extg.complex t).assocGraded (sfx + m + l) 0 from rfl)) w))
    (ddg : DifferentialDatum C ω)
    (_hddg : ddg.E = sq.V₃.E ∧ ddg.r = l ∧ ddg.k = kz)
    (s : ℤ) (kval : ℤ) (_hk_pos : 0 < kval) (_hk_bound : kval ≤ m + l - n)
    (_hg_nc_range : NoCrossingRange ddg (s + n + kval))
    (ddq : DifferentialDatum C ω)
    (_hddq : ddq.E = sq.V₂.E ∧ ddq.r = kval - 1 ∧
      ddq.k = ky)
    -- 5. `d_{k-1}^q(y) = 0`：ESS(q) 中从 `y`（与 (1) 共享）出发的短微分消失
    (_hq_vanish : ∀ (y₀ : T ⟶ (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
        (⟨sfx + n, 1⟩ + ((extq.complex t).toSpectralSequence (extq.bounded t)).diffDeg
          (kval - 1))).V),
      DifferentialRelation ((extq.complex t).toSpectralSequence (extq.bounded t))
        (kval - 1) ⟨sfx + n, 1⟩
        (Eq.mpr (congrArg (fun X : C => T ⟶ X)
          (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
            ⟨sfx + n, 1⟩).V =
            (extq.complex t).assocGraded (sfx + n) 1 from rfl)) y)
        y₀ → y₀ = 0)
    (_hq_nc : NoCrossing ddq) :
    -- 结论：`d_{m+l-n}^q(y) = w`：ESS(q) 中 `y` 与 `w`（与 (4) 共享）的微分关系
    DifferentialRelation ((extq.complex t).toSpectralSequence (extq.bounded t))
      (m + l - n) ⟨sfx + n, 1⟩
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (show (((extq.complex t).toSpectralSequence (extq.bounded t)).ssData
          ⟨sfx + n, 1⟩).V =
          (extq.complex t).assocGraded (sfx + n) 1 from rfl)) y)
      (Eq.mpr (congrArg (fun X : C => T ⟶ X)
        (essComm_concl_cast sq bnd₂ bnd₃ bnd₄ extq extg n m l sfx t)) w) :=
  -- 主定理本体：由引理 C1 直接给出（C1 的证明内部经 A1→B1→B2→B3 组装）。
  essComm_auxC1 sq bnd₁ bnd₂ bnd₃ bnd₄ extf extq extg n m l sfx t y w

/-- **Theorem 2.12 (value form)**: The ESS differential `d_{m+l-n}^q(y)` equals
    the composition of `d_l^g(z)` through the commutativity square, expressed
    as an isomorphism between the differential objects. -/
theorem essCommutativity_iso {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n m l : ℤ) (kx ky kz kw : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hl : 0 ≤ l)
    (_hf_rel : ESSRelation sq.extf n kx ky)
    (_hp_rel : ESSRelation sq.extp m kx kz)
    (ddf : DifferentialDatum C ω)
    (_hddf : ddf.E = E₁ ∧ ddf.r = n ∧ ddf.k = kx)
    (ddp : DifferentialDatum C ω)
    (_hddp : ddp.E = E₁ ∧ ddp.r = m ∧ ddp.k = kx)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp)
    (_hg_rel : ESSRelation sq.extg l kz kw)
    (ddg : DifferentialDatum C ω)
    (_hddg : ddg.E = E₃ ∧ ddg.r = l ∧ ddg.k = kz)
    (s : ℤ) (kval : ℤ) (_hk_pos : 0 < kval) (_hk_bound : kval ≤ m + l - n)
    (_hg_nc_range : NoCrossingRange ddg (s + n + kval))
    (ddq : DifferentialDatum C ω)
    (_hddq : ddq.E = E₂ ∧ ddq.r = kval - 1 ∧ ddq.k = ky)
    (_hq_vanish : ESSVanishes sq.extq (kval - 1) ky kw)
    (_hq_nc : NoCrossing ddq) :
    Nonempty (sq.extq.essDiff (m + l - n) ky kw ≅ sq.extg.essDiff l kz kw) := by
  sorry
/-! ### Corollary 2.15 — Simplified commutativity (no crossing everywhere) -/

/-- **Corollary 2.15**: Simplified commutativity — same as Thm 2.12 but with
    `d_l^g(z) = w` having no crossing at all (dropping the k parameter). -/
theorem essCommutativity_noCrossing {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n m l : ℤ) (kx ky kz kw : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hl : 0 ≤ l)
    (_hf_rel : ESSRelation sq.extf n kx ky)
    (_hp_rel : ESSRelation sq.extp m kx kz)
    (ddf : DifferentialDatum C ω)
    (_hddf : ddf.E = E₁ ∧ ddf.r = n ∧ ddf.k = kx)
    (ddp : DifferentialDatum C ω)
    (_hddp : ddp.E = E₁ ∧ ddp.r = m ∧ ddp.k = kx)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp)
    (_hg_rel : ESSRelation sq.extg l kz kw)
    (ddg : DifferentialDatum C ω)
    (_hddg : ddg.E = E₃ ∧ ddg.r = l ∧ ddg.k = kz)
    (_hg_nc : NoCrossing ddg) :
    ESSRelation sq.extq (m + l - n) ky kw := by
  sorry
/-- **Corollary 2.15 (iso form)**: Under no-crossing-everywhere, the differential
    objects are isomorphic. -/
theorem essCommutativity_noCrossing_iso {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n m l : ℤ) (kx ky kz kw : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hl : 0 ≤ l)
    (_hf_rel : ESSRelation sq.extf n kx ky)
    (_hp_rel : ESSRelation sq.extp m kx kz)
    (ddf : DifferentialDatum C ω)
    (_hddf : ddf.E = E₁ ∧ ddf.r = n ∧ ddf.k = kx)
    (ddp : DifferentialDatum C ω)
    (_hddp : ddp.E = E₁ ∧ ddp.r = m ∧ ddp.k = kx)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp)
    (_hg_rel : ESSRelation sq.extg l kz kw)
    (ddg : DifferentialDatum C ω)
    (_hddg : ddg.E = E₃ ∧ ddg.r = l ∧ ddg.k = kz)
    (_hg_nc : NoCrossing ddg) :
    Nonempty (sq.extq.essDiff (m + l - n) ky kw ≅ sq.extg.essDiff l kz kw) := by
  sorry
/-! ### Corollary 2.16 — Triangle case -/

/-- **Corollary 2.16 (Triangle)**: When V₃ = V₄ and g = id.
    ```
    V₁ --f--> V₂
     \         |q
      p\       v
        \-->  V₃
    ```
    If `d_n^f(x) = y` and `d_m^p(x) = z` with no crossing on one of them,
    then `d_{m-n}^q(y) = z`. -/
theorem essCommutativity_triangle {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂} {F₃ : Filtration A₃}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃}
    (cmf : ConvergenceMorphism conv₁ conv₂)
    (cmp : ConvergenceMorphism conv₁ conv₃)
    (cmq : ConvergenceMorphism conv₂ conv₃)
    (bnd₁ : F₁.IsBounded) (bnd₂ : F₂.IsBounded) (bnd₃ : F₃.IsBounded)
    (extf : BoundedExtensionSS conv₁ conv₂ cmf bnd₁ bnd₂)
    (extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃)
    (extq : BoundedExtensionSS conv₂ conv₃ cmq bnd₂ bnd₃)
    (_abutment_comm : ∀ (k' : ω'), cmf.aMap k' ≫ cmq.aMap k' = cmp.aMap k')
    (_eInfty_comm : ∀ (k : ω), cmf.eMap k ≫ cmq.eMap k = cmp.eMap k)
    (n m : ℤ) (kx ky kz : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hmn : n ≤ m)
    (_hf_rel : ESSRelation extf n kx ky)
    (_hp_rel : ESSRelation extp m kx kz)
    (ddf : DifferentialDatum C ω)
    (_hddf : ddf.E = E₁ ∧ ddf.r = n ∧ ddf.k = kx)
    (ddp : DifferentialDatum C ω)
    (_hddp : ddp.E = E₁ ∧ ddp.r = m ∧ ddp.k = kx)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp) :
    ESSRelation extq (m - n) ky kz := by
  sorry
/-- **Corollary 2.16 (iso form)**: Triangle case iso. -/
theorem essCommutativity_triangle_iso {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂} {F₃ : Filtration A₃}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃}
    (cmf : ConvergenceMorphism conv₁ conv₂)
    (cmp : ConvergenceMorphism conv₁ conv₃)
    (cmq : ConvergenceMorphism conv₂ conv₃)
    (bnd₁ : F₁.IsBounded) (bnd₂ : F₂.IsBounded) (bnd₃ : F₃.IsBounded)
    (extf : BoundedExtensionSS conv₁ conv₂ cmf bnd₁ bnd₂)
    (extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃)
    (extq : BoundedExtensionSS conv₂ conv₃ cmq bnd₂ bnd₃)
    (_abutment_comm : ∀ (k' : ω'), cmf.aMap k' ≫ cmq.aMap k' = cmp.aMap k')
    (_eInfty_comm : ∀ (k : ω), cmf.eMap k ≫ cmq.eMap k = cmp.eMap k)
    (n m : ℤ) (kx ky kz : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hmn : n ≤ m)
    (_hf_rel : ESSRelation extf n kx ky)
    (_hp_rel : ESSRelation extp m kx kz)
    (ddf : DifferentialDatum C ω)
    (_hddf : ddf.E = E₁ ∧ ddf.r = n ∧ ddf.k = kx)
    (ddp : DifferentialDatum C ω)
    (_hddp : ddp.E = E₁ ∧ ddp.r = m ∧ ddp.k = kx)
    (_hf_or_p_nc : NoCrossing ddf ∨ NoCrossing ddp) :
    Nonempty (extq.essDiff (m - n) ky kz ≅ extp.essDiff m kx kz) := by
  sorry
/-! ### Corollary 2.17 — Composition case -/

/-- **Corollary 2.17 (Composition)**: When V₁ = V₂ and f = id.
    ```
    V₁ --p--> V₃
     \         |g
      q\       v
        \-->  V₄
    ```
    If `d_m^p(x) = z` and `d_l^g(z) = w` with no crossing on `g`, then
    `d_{m+l}^q(x) = w`. -/
theorem essCommutativity_composition {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (cmp : ConvergenceMorphism conv₁ conv₃)
    (cmg : ConvergenceMorphism conv₃ conv₄)
    (cmq : ConvergenceMorphism conv₁ conv₄)
    (bnd₁ : F₁.IsBounded) (bnd₃ : F₃.IsBounded) (bnd₄ : F₄.IsBounded)
    (extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃)
    (extg : BoundedExtensionSS conv₃ conv₄ cmg bnd₃ bnd₄)
    (extq : BoundedExtensionSS conv₁ conv₄ cmq bnd₁ bnd₄)
    (_abutment_comm : ∀ (k' : ω'), cmp.aMap k' ≫ cmg.aMap k' = cmq.aMap k')
    (_eInfty_comm : ∀ (k : ω), cmp.eMap k ≫ cmg.eMap k = cmq.eMap k)
    (m l : ℤ) (kx kz kw : ω)
    (_hm : 0 ≤ m) (_hl : 0 ≤ l)
    (_hp_rel : ESSRelation extp m kx kz)
    (_hg_rel : ESSRelation extg l kz kw)
    (ddg : DifferentialDatum C ω)
    (_hddg : ddg.E = E₃ ∧ ddg.r = l ∧ ddg.k = kz)
    (_hg_nc : NoCrossing ddg) :
    ESSRelation extq (m + l) kx kw := by
  sorry
/-- **Corollary 2.17 (iso form)**: Composition case iso. -/
theorem essCommutativity_composition_iso {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (cmp : ConvergenceMorphism conv₁ conv₃)
    (cmg : ConvergenceMorphism conv₃ conv₄)
    (cmq : ConvergenceMorphism conv₁ conv₄)
    (bnd₁ : F₁.IsBounded) (bnd₃ : F₃.IsBounded) (bnd₄ : F₄.IsBounded)
    (extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃)
    (extg : BoundedExtensionSS conv₃ conv₄ cmg bnd₃ bnd₄)
    (extq : BoundedExtensionSS conv₁ conv₄ cmq bnd₁ bnd₄)
    (_abutment_comm : ∀ (k' : ω'), cmp.aMap k' ≫ cmg.aMap k' = cmq.aMap k')
    (_eInfty_comm : ∀ (k : ω), cmp.eMap k ≫ cmg.eMap k = cmq.eMap k)
    (m l : ℤ) (kx kz kw : ω)
    (_hm : 0 ≤ m) (_hl : 0 ≤ l)
    (_hp_rel : ESSRelation extp m kx kz)
    (_hg_rel : ESSRelation extg l kz kw)
    (ddg : DifferentialDatum C ω)
    (_hddg : ddg.E = E₃ ∧ ddg.r = l ∧ ddg.k = kz)
    (_hg_nc : NoCrossing ddg) :
    Nonempty (extq.essDiff (m + l) kx kw ≅ extg.essDiff l kz kw) := by
  sorry
/-! ### Corollary 2.18 — Induced map on ESS pages -/

/-- The ESS page map induced by the commutativity square: if the source E∞-pages
    have `E₀ = E_r` (degeneration at page r), then the commutativity data
    induces a well-defined map between the f-ESS and g-ESS pages. -/
theorem essCommutativity_induces_map {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (r : ℤ) (_hr : 0 ≤ r)
    (_hp_degen : E₁.DegeneratesAt r)
    (_hg_degen : E₃.DegeneratesAt r)
    (n : ℤ) (k₁ k₂ : ω) :
    Nonempty (sq.extf.essDiff n k₁ k₂ ⟶ sq.extg.essDiff n k₁ k₂) := by
  exact ⟨0⟩

/-- **Corollary 2.18 (compatibility)**: The induced page map commutes with ESS
    differentials. -/
theorem essInducedPageMap_comm {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (r : ℤ) (_hr : 0 ≤ r)
    (_hp_degen : E₁.DegeneratesAt r)
    (_hg_degen : E₃.DegeneratesAt r)
    (n : ℤ) (k₁ k₂ k₃ : ω)
    (φ₁₂ : sq.extf.essDiff n k₁ k₂ ⟶ sq.extg.essDiff n k₁ k₂)
    (φ₂₃ : sq.extf.essDiff n k₂ k₃ ⟶ sq.extg.essDiff n k₂ k₃)
    (d_f : sq.extf.essDiff n k₁ k₂ ⟶ sq.extf.essDiff n k₂ k₃)
    (d_g : sq.extg.essDiff n k₁ k₂ ⟶ sq.extg.essDiff n k₂ k₃) :
    φ₁₂ ≫ d_g = d_f ≫ φ₂₃ := by
  sorry
/-! ### Corollary 2.19 — Null composition -/

/-- **Corollary 2.19**: If `g ∘ f` is null-homotopic and `d_n^f(x) = y`,
    then `y` is a permanent cycle in the g-ESS: `d_m^g(y) = 0` for all `m ≥ 0`. -/
theorem essCommutativity_null {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n : ℤ) (kx ky : ω)
    (_hn : 0 ≤ n)
    (_hf_rel : ESSRelation sq.extf n kx ky)
    (_h_null : ∀ (k' : ω'), sq.cmf.aMap k' ≫ sq.cmq.aMap k' = 0) :
    ∀ (m : ℤ) (_hm : 0 ≤ m) (kw : ω),
    ESSVanishes sq.extq m ky kw := by
  sorry
/-! ### Supporting axioms — Commutativity functoriality -/

/-- Commutativity squares preserve boundary groups: the boundary in the q-ESS
    at page `m + l - n` is related to the boundary in the g-ESS at page `l`. -/
theorem essCommutativity_preserves_boundaries {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n m l : ℤ) (kw : ω)
    (_hn : 0 ≤ n) (_hm : 0 ≤ m) (_hl : 0 ≤ l) :
    Nonempty (sq.extq.essBoundary (m + l - n) kw ⟶ sq.extg.essBoundary l kw) := by
  exact ⟨0⟩
/-- The HomotopyCommSquare is natural in the following sense: the induced maps
    on ESS differentials respect composition of convergence morphisms. -/
theorem essCommutativity_naturality {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n : ℤ) (k₁ k₂ : ω) :
    Nonempty (sq.extf.essDiff n k₁ k₂ ⟶ sq.extq.essDiff n k₁ k₂) := by
  exact ⟨0⟩
-/

end ESSCommutativityLemmas

/-! ### Theorem 2.12 — reorganized blueprint interface

Implementation notes recorded from the comparison with
`informal/commutativity_ss.md`:

* `ext.ess t` is, by definition, the spectral sequence of the two-term
  filtered complex `ext.complex t`.  Thus the classes occurring in the
  commutativity theorem must be stated as `DifferentialRelation`s in that
  concrete `toSpectralSequence`; an abstract nonzero object is not an ESS
  differential relation.
* The two-term complex has the source in internal degree `1` and the target
  in internal degree `0`.  The four classes of Theorem 2.12 consequently
  occur at internal degrees `1, 0, 0, 0`, rather than at an arbitrary chain
  degree shifted by each differential.
* At the two actual internal degrees, the common vertex summands are
  definitionally the same: `extf/extp` at degree `1`, `extf/extq` at the
  target/source degrees `0/1`, `extp/extg` at `0/1`, and `extg/extq` at
  degree `0`.  This does **not** extend to arbitrary chain degrees.  The only
  explicit transport in the theorem statement is therefore the arithmetic
  equality `s+n+(m+l-n)=s+m+l` for the q-target.
* Proposition 2.5 and Proposition 2.10 are the indispensable bridge: they
  select a common detected representative and turn the no-crossing hypotheses
  into its uniqueness statement.  A proof of 2.12 cannot manufacture that
  bridge from unrelated `DifferentialRelation` witnesses.
-/

/-- The complete, degree-consistent input of blueprint Theorem 2.12.

The ESS is the spectral sequence of a two-term complex.  Consequently the
source summand has internal degree `1` and the target summand has internal
degree `0`: `x` occurs at `(s,1)`, `y` and `z` at their target filtrations in
degree `0`, and `w` at `(s+m+l,0)`. -/
structure ESSCommutativityInput {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (t : ω') (n m l s kval : ℤ) {T : C} [Projective T] where
  n_nonneg : 0 ≤ n
  m_nonneg : 0 ≤ m
  l_nonneg : 0 ≤ l
  kval_pos : 0 < kval
  kval_le : kval ≤ m + l - n
  x : T ⟶ (sq.extf.complex t).assocGraded s 1
  y : T ⟶ (sq.extf.complex t).assocGraded (s + n) 0
  z : T ⟶ (sq.extp.complex t).assocGraded (s + m) 0
  w : T ⟶ (sq.extg.complex t).assocGraded (s + m + l) 0
  f_rel : ESSRelationAt sq.extf t n s 1 x y
  p_rel : ESSRelationAt sq.extp t m s 1 x z
  f_datum : ESSDifferentialDatum sq.extf t n s 1
  p_datum : ESSDifferentialDatum sq.extp t m s 1
  f_or_p_noCrossing : f_datum.NoCrossing ∨ p_datum.NoCrossing
  g_rel : ESSRelationAt sq.extg t l (s + m) 1 z w
  g_datum : ESSDifferentialDatum sq.extg t l (s + m) 1
  g_noCrossingRange : NoCrossingRange g_datum.datum (s + n + kval)
  q_datum : ESSDifferentialDatum sq.extq t (kval - 1) (s + n) 1
  q_vanishes : ESSVanishesAt sq.extq t (kval - 1) (s + n) 1 y
  q_noCrossing : q_datum.NoCrossing

/-- The three nonvanishing relations in a Theorem 2.12 input admit concrete
filtered lifts simultaneously.  This supplies the filtered-complex data on
which the common-representative argument must operate. -/
noncomputable def ESSCommutativityInput.lifts
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    ESSRelationLiftData sq.extf t n s 1 h.x h.y ×
      ESSRelationLiftData sq.extp t m s 1 h.x h.z ×
        ESSRelationLiftData sq.extg t l (s + m) 1 h.z h.w :=
  ⟨ESSRelationLiftData.ofESSRelation h.n_nonneg h.f_rel,
    ESSRelationLiftData.ofESSRelation h.m_nonneg h.p_rel,
    ESSRelationLiftData.ofESSRelation h.l_nonneg h.g_rel⟩

/-- The f- and p-lifts of the common source differ only in the next
filtration.  This is the concrete starting point for the no-crossing
comparison required by Proposition 2.10. -/
theorem ESSCommutativityInput.sourceLiftDifference
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    Subobject.Factors ((sq.extf.complex t).fil (s + 1) 1)
      (((show T ⟶ Subobject.underlying.obj ((sq.extf.complex t).fil s 1) from
          h.lifts.1.sourceLift) -
        (show T ⟶ Subobject.underlying.obj ((sq.extf.complex t).fil s 1) from
          h.lifts.2.1.sourceLift)) ≫
        ((sq.extf.complex t).fil s 1).arrow) := by
  exact FilteredComplex.isLift_sub_factors (sq.extf.complex t) s 1
    h.lifts.1.source_lift h.lifts.2.1.source_lift

/-- The disjunctive no-crossing hypothesis of Theorem 2.12 yields a
relation-level no-crossing statement for one of its first two relations. -/
theorem ESSCommutativityInput.oneRelationNoCrossing
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    (¬ RelationCrossedBy (sq.extf.ess t) (fun b => b.1) n ⟨s, 1⟩ h.x h.y h.f_rel) ∨
      (¬ RelationCrossedBy (sq.extp.ess t) (fun b => b.1) m ⟨s, 1⟩ h.x h.z h.p_rel) := by
  rcases h.f_or_p_noCrossing with hf | hp
  · exact Or.inl (h.f_datum.noRelationCrossing hf h.f_rel)
  · exact Or.inr (h.p_datum.noRelationCrossing hp h.p_rel)

/-- The conclusion predicate of blueprint Theorem 2.12, using the same
degree-consistent representatives as `ESSCommutativityInput`. -/
def ESSCommutativityConclusion {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) : Prop :=
  ESSRelationAt sq.extq t (m + l - n) (s + n) 1 h.y
    (by
      have hdeg : s + n + (m + l - n) = s + m + l := by omega
      rw [hdeg]
      exact h.w)

/-- The data of blueprint Corollary 2.15.  This is deliberately separate from
`ESSCommutativityInput`: Corollary 2.15 has no auxiliary `k` and no assumed
short vanishing q-differential; instead its g-differential has no crossing at
all. -/
structure ESSCommutativityNoCrossingInput {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (t : ω') (n m l s : ℤ) {T : C} [Projective T] where
  n_nonneg : 0 ≤ n
  m_nonneg : 0 ≤ m
  l_nonneg : 0 ≤ l
  x : T ⟶ (sq.extf.complex t).assocGraded s 1
  y : T ⟶ (sq.extf.complex t).assocGraded (s + n) 0
  z : T ⟶ (sq.extp.complex t).assocGraded (s + m) 0
  w : T ⟶ (sq.extg.complex t).assocGraded (s + m + l) 0
  f_rel : ESSRelationAt sq.extf t n s 1 x y
  p_rel : ESSRelationAt sq.extp t m s 1 x z
  f_datum : ESSDifferentialDatum sq.extf t n s 1
  p_datum : ESSDifferentialDatum sq.extp t m s 1
  f_or_p_noCrossing : f_datum.NoCrossing ∨ p_datum.NoCrossing
  g_rel : ESSRelationAt sq.extg t l (s + m) 1 z w
  g_datum : ESSDifferentialDatum sq.extg t l (s + m) 1
  g_noCrossing : g_datum.NoCrossing

/-- The conclusion shared by the full and no-crossing forms of the
commutativity theorem. -/
def ESSCommutativityNoCrossingConclusion
    {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityNoCrossingInput (T := T) sq t n m l s) : Prop :=
  ESSRelationAt sq.extq t (m + l - n) (s + n) 1 h.y
    (by
      have hdeg : s + n + (m + l - n) = s + m + l := by omega
      rw [hdeg]
      exact h.w)

/-! ### Blueprint theorem signatures -/

/-- **Theorem 2.12.**  This is the full commutativity statement from the
blueprint, now expressed in the concrete extension spectral sequences. -/
theorem essCommutativity_2_12 {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s kval : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityInput (T := T) sq t n m l s kval) :
    ESSCommutativityConclusion h := by
  sorry

/-- **Corollary 2.15.**  The no-crossing form of Theorem 2.12. -/
theorem essCommutativity_2_15 {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n m l s : ℤ} {T : C} [Projective T]
    (h : ESSCommutativityNoCrossingInput (T := T) sq t n m l s) :
    ESSCommutativityNoCrossingConclusion h := by
  sorry

/-- The direct input of blueprint Corollary 2.16.  Unlike Theorem 2.12, no
auxiliary g-extension is part of the hypothesis: the lower edge is explicitly
the identity of the third converging spectral sequence. -/
structure ESSTriangleInput {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ : SpectralSequence C ω}
    {A₁ A₂ A₃ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₃}
    (t : ω') (n m s : ℤ) {T : C} [Projective T] where
  n_nonneg : 0 ≤ n
  m_nonneg : 0 ≤ m
  x : T ⟶ (sq.extf.complex t).assocGraded s 1
  y : T ⟶ (sq.extf.complex t).assocGraded (s + n) 0
  z : T ⟶ (sq.extp.complex t).assocGraded (s + m) 0
  f_rel : ESSRelationAt sq.extf t n s 1 x y
  p_rel : ESSRelationAt sq.extp t m s 1 x z
  f_datum : ESSDifferentialDatum sq.extf t n s 1
  p_datum : ESSDifferentialDatum sq.extp t m s 1
  f_or_p_noCrossing : f_datum.NoCrossing ∨ p_datum.NoCrossing
  g_abutment_id : ∀ k', sq.cmg.aMap k' = 𝟙 _
  g_eInfty_id : ∀ k', sq.cmg.eMap k' = 𝟙 _

/-- **Corollary 2.16.**  Triangle commutativity in the exact hypothesis form
of the blueprint. -/
theorem essCommutativity_2_16 {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ : SpectralSequence C ω}
    {A₁ A₂ A₃ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₃}
    {t : ω'} {n m s : ℤ} {T : C} [Projective T]
    (h : ESSTriangleInput (sq := sq) (T := T) t n m s) :
    ESSRelationAt sq.extq t (m - n) (s + n) 1 h.y
      (by
        have hdeg : s + n + (m - n) = s + m := by omega
        rw [hdeg]
        let hz : T ⟶ (sq.extq.complex t).assocGraded (s + m) 0 := h.z
        exact Eq.mpr
          (congrArg (fun q => T ⟶ (sq.extq.complex t).assocGraded q 0)
            (by omega)) hz) := by
  sorry

/-- The direct input of blueprint Corollary 2.17.  The upper edge is explicitly
the identity, so only the p- and g-extension relations occur. -/
structure ESSCompositionInput {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₃ : Filtration A₃}
    {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₃ : Convergence E₃ A₃ F₃}
    {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₁ conv₃ conv₄}
    (t : ω') (m l s : ℤ) {T : C} [Projective T] where
  m_nonneg : 0 ≤ m
  l_nonneg : 0 ≤ l
  x : T ⟶ (sq.extp.complex t).assocGraded s 1
  z : T ⟶ (sq.extp.complex t).assocGraded (s + m) 0
  w : T ⟶ (sq.extg.complex t).assocGraded (s + m + l) 0
  p_rel : ESSRelationAt sq.extp t m s 1 x z
  g_rel : ESSRelationAt sq.extg t l (s + m) 1 z w
  g_datum : ESSDifferentialDatum sq.extg t l (s + m) 1
  g_noCrossing : g_datum.NoCrossing
  f_abutment_id : ∀ k', sq.cmf.aMap k' = 𝟙 _
  f_eInfty_id : ∀ k', sq.cmf.eMap k' = 𝟙 _

/-- **Corollary 2.17.**  Composition commutativity in the exact hypothesis
form of the blueprint. -/
theorem essCommutativity_2_17 {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₃ : Filtration A₃}
    {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₃ : Convergence E₃ A₃ F₃}
    {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₁ conv₃ conv₄}
    {t : ω'} {m l s : ℤ} {T : C} [Projective T]
    (h : ESSCompositionInput (sq := sq) (T := T) t m l s) :
    ESSRelationAt sq.extq t (m + l) s 1 h.x
      (by
        have hdeg : s + (m + l) = s + m + l := by omega
        rw [hdeg]
        exact h.w) := by
  sorry

/-- Page-stability data expressing the blueprint notation `E₀ = Eᵣ` for one
extension spectral sequence.  The page isomorphisms are explicit because no
canonical equality of the quotient objects is currently available. -/
structure ESSPageStabilizes {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ : SpectralSequence C ω}
    {A₁ A₂ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {cm : ConvergenceMorphism conv₁ conv₂}
    {bnd₁ : F₁.IsBounded} {bnd₂ : F₂.IsBounded}
    (ext : BoundedExtensionSS conv₁ conv₂ cm bnd₁ bnd₂) (t : ω') (r : ℤ) where
  pageIso : ∀ i : ℤ × ℤ,
    ((ext.ess t).ssData i).page 0 ≅
      ((ext.ess t).ssData i).page (↑(r - (ext.ess t).r₀).toNat : WithTop ℕ)

/-- **Corollary 2.18.**  Under the two page-stability hypotheses, the pair of
vertical ESS differentials induces a morphism from the f-ESS to the g-ESS.
The conclusion records that the map is specifically induced by `(p,q)`. -/
noncomputable def essCommutativity_2_18 {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (t : ω') (r : ℤ)
    (_p_stable : ESSPageStabilizes sq.extp t r)
    (_g_stable : ESSPageStabilizes sq.extg t r) :
    InducedESSMap sq t :=
  ⟨extensionSquareSSMorphism sq t, rfl⟩

/-- **Corollary 2.19.**  If the composite `q ∘ f` is zero on abutments, an
f-extension target is a permanent q-cycle.  The q-ESS is the one whose source
vertex is the target of `f`; this removes the ambiguous `g` notation in the
informal wording. -/
theorem essCommutativity_2_19 {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {ω' : Type w} {E₁ E₂ E₃ E₄ : SpectralSequence C ω}
    {A₁ A₂ A₃ A₄ : ω' → C} {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    {sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄}
    {t : ω'} {n s : ℤ} {T : C} [Projective T]
    {x : T ⟶ (sq.extf.complex t).assocGraded s 1}
    {y : T ⟶ (sq.extf.complex t).assocGraded (s + n) 0}
    (hn : 0 ≤ n) (hf : ESSRelationAt sq.extf t n s 1 x y)
    (hnull : ∀ k', sq.cmf.aMap k' ≫ sq.cmq.aMap k' = 0) :
    ∀ r : ℤ, 0 ≤ r → ESSVanishesAt sq.extq t r (s + n) 1 y := by
  sorry

/-- The commutativity data is compatible with the E∞ page maps. -/
theorem essCommutativity_eInfty_compat {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n : ℤ) (k : ω) :
    sq.cmf.eMap k ≫ sq.cmq.eMap k = sq.cmp.eMap k ≫ sq.cmg.eMap k :=
  sq.eInfty_comm k
/-- 过滤数据跨方块相容：`f`、`q` 与 `p`、`g` 在过滤层上诱导的关联分次映射
    满足交换律 `gr(f) ≫ gr(q) = gr(p) ≫ gr(g)`（方块交换在 gr 层面的表现）。 -/
theorem essCommutativity_filtration_compat {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (s : ℤ) (k' : ω') :
    Filtration.inducedAssocGradedMap sq.cmf.aMap sq.cmf.filtration_compat s k' ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat s k' =
    Filtration.inducedAssocGradedMap sq.cmp.aMap sq.cmp.filtration_compat s k' ≫
      Filtration.inducedAssocGradedMap sq.cmg.aMap sq.cmg.filtration_compat s k' := by
  have hL : Filtration.inducedAssocGradedMap
      (fun k'' => sq.cmf.aMap k'' ≫ sq.cmq.aMap k'')
      (ConvergenceMorphismData.fcComp sq.cmf sq.cmq) s k' =
    Filtration.inducedAssocGradedMap sq.cmf.aMap sq.cmf.filtration_compat s k' ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat s k' :=
    Filtration.inducedAssocGradedMap_comp sq.cmf sq.cmq s k'
  have hR : Filtration.inducedAssocGradedMap
      (fun k'' => sq.cmp.aMap k'' ≫ sq.cmg.aMap k'')
      (ConvergenceMorphismData.fcComp sq.cmp sq.cmg) s k' =
    Filtration.inducedAssocGradedMap sq.cmp.aMap sq.cmp.filtration_compat s k' ≫
      Filtration.inducedAssocGradedMap sq.cmg.aMap sq.cmg.filtration_compat s k' :=
    Filtration.inducedAssocGradedMap_comp sq.cmp sq.cmg s k'
  have hcomp : (fun k'' => sq.cmf.aMap k'' ≫ sq.cmq.aMap k'') =
      fun k'' => sq.cmp.aMap k'' ≫ sq.cmg.aMap k'' :=
    funext fun k'' => sq.abutment_comm k''
  have hmain : Filtration.inducedAssocGradedMap
      (fun k'' => sq.cmf.aMap k'' ≫ sq.cmq.aMap k'')
      (ConvergenceMorphismData.fcComp sq.cmf sq.cmq) s k' =
    Filtration.inducedAssocGradedMap
      (fun k'' => sq.cmp.aMap k'' ≫ sq.cmg.aMap k'')
      (ConvergenceMorphismData.fcComp sq.cmp sq.cmg) s k' := by
    rw [Filtration.inducedAssocGradedMap_eq_inducedGradedMapOfMap
      (fun k'' => sq.cmf.aMap k'' ≫ sq.cmq.aMap k'')
      (ConvergenceMorphismData.fcComp sq.cmf sq.cmq)]
    rw [Filtration.inducedAssocGradedMap_eq_inducedGradedMapOfMap
      (fun k'' => sq.cmp.aMap k'' ≫ sq.cmg.aMap k'')
      (ConvergenceMorphismData.fcComp sq.cmp sq.cmg)]
    apply Filtration.inducedGradedMapOfMap_congr
    funext s₀ k₀
    apply (cancel_mono ((F₄.F s₀ k₀).arrow)).mp
    rw [(ConvergenceMorphismData.fcComp sq.cmf sq.cmq s₀ k₀).choose_spec,
      (ConvergenceMorphismData.fcComp sq.cmp sq.cmg s₀ k₀).choose_spec,
      congrFun hcomp k₀]
  rw [← hL, ← hR, hmain]
/-! ### Triangle and composition reductions -/

/-- 三角归约（Corollary 2.16 由全交换方块特化而来）：
    取 `V₃ = V₄`、`g = 𝟙` 时，`f ≫ q = p` 的方块交换数据，
    连同 `V₃` 上的恒等收敛态射及其有界 ESS 数据，
    可由方块数据构造——此即三角情形嵌入全方块情形的桥。 -/
theorem essTriangle_from_square {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂} {F₃ : Filtration A₃}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃}
    (cmf : ConvergenceMorphism conv₁ conv₂)
    (cmp : ConvergenceMorphism conv₁ conv₃)
    (cmq : ConvergenceMorphism conv₂ conv₃)
    (bnd₁ : F₁.IsBounded) (bnd₂ : F₂.IsBounded) (bnd₃ : F₃.IsBounded)
    (extf : BoundedExtensionSS conv₁ conv₂ cmf bnd₁ bnd₂)
    (extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃)
    (extq : BoundedExtensionSS conv₂ conv₃ cmq bnd₂ bnd₃)
    (_abutment_comm : ∀ (k' : ω'), cmf.aMap k' ≫ cmq.aMap k' = cmp.aMap k')
    (n m : ℤ) (kx ky kz : ω)
    (_hf_rel : ESSRelation extf n kx ky)
    (_hp_rel : ESSRelation extp m kx kz) :
    ∃ (idCm : ConvergenceMorphism conv₃ conv₃)
      (_idExt : BoundedExtensionSS conv₃ conv₃ idCm bnd₃ bnd₃),
    (∀ (k : ω), idCm.eMap k = 𝟙 _) ∧ (∀ (k' : ω'), idCm.aMap k' = 𝟙 _) := by
  refine ⟨{
    eMap := fun _ => 𝟙 _
    aMap := fun _ => 𝟙 _
    filtration_compat := F₃.fcId
    reindex_eq := rfl
    iso_compat := fun k => by
      simp only [Category.id_comp, Filtration.transportGraded_self, Category.comp_id,
        F₃.inducedAssocGradedMap_id (conv₃.reindex k).1 (conv₃.reindex k).2] },
    BoundedExtensionSS.mk' conv₃ conv₃ _ bnd₃ bnd₃, fun _ => rfl, fun _ => rfl⟩

/-- 复合归约（Corollary 2.17 由全交换方块特化而来）：
    取 `V₁ = V₂`、`f = 𝟙` 时，`p ≫ g = q` 的方块交换数据，
    连同 `V₁` 上的恒等收敛态射及其有界 ESS 数据，
    可由方块数据构造。 -/
theorem essComposition_from_square {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (cmp : ConvergenceMorphism conv₁ conv₃)
    (cmg : ConvergenceMorphism conv₃ conv₄)
    (cmq : ConvergenceMorphism conv₁ conv₄)
    (bnd₁ : F₁.IsBounded) (bnd₃ : F₃.IsBounded) (bnd₄ : F₄.IsBounded)
    (extp : BoundedExtensionSS conv₁ conv₃ cmp bnd₁ bnd₃)
    (extg : BoundedExtensionSS conv₃ conv₄ cmg bnd₃ bnd₄)
    (extq : BoundedExtensionSS conv₁ conv₄ cmq bnd₁ bnd₄)
    (_abutment_comm : ∀ (k' : ω'), cmp.aMap k' ≫ cmg.aMap k' = cmq.aMap k')
    (m l : ℤ) (kx kz kw : ω)
    (_hp_rel : ESSRelation extp m kx kz)
    (_hg_rel : ESSRelation extg l kz kw) :
    ∃ (idCm : ConvergenceMorphism conv₁ conv₁)
      (_idExt : BoundedExtensionSS conv₁ conv₁ idCm bnd₁ bnd₁),
    (∀ (k : ω), idCm.eMap k = 𝟙 _) ∧ (∀ (k' : ω'), idCm.aMap k' = 𝟙 _) := by
  refine ⟨{
    eMap := fun _ => 𝟙 _
    aMap := fun _ => 𝟙 _
    filtration_compat := F₁.fcId
    reindex_eq := rfl
    iso_compat := fun k => by
      simp only [Category.id_comp, Filtration.transportGraded_self, Category.comp_id,
        F₁.inducedAssocGradedMap_id (conv₁.reindex k).1 (conv₁.reindex k).2] },
    BoundedExtensionSS.mk' conv₁ conv₁ _ bnd₁ bnd₁, fun _ => rfl, fun _ => rfl⟩
/-
The following boundary/page-map declarations were similarly provisional:
their old types asked only for an arbitrary morphism (or arbitrary maps) and
therefore did not express inducedness or naturality.  They stay unavailable
until concrete maps of `ext.ess t` pages and boundaries are constructed.

/-! ### Boundary transfer -/

/-- Boundary transfer under the commutativity square: an element in the
    ESS boundary of the q-differential maps to an element in the ESS boundary
    of the g-differential under appropriate conditions. -/
theorem essCommutativity_boundary_transfer {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n : ℤ) (kw : ω) :
    Nonempty (sq.extq.essBoundary n kw ⟶ sq.extg.essBoundary n kw) := by
  exact ⟨0⟩
/-! ### ESS page functoriality under commutativity -/

/-- The ESS page at level n is functorial: the page map induced by the commutativity
    square respects composition of convergence morphisms at each ESS page. -/
theorem essCommutativity_page_functorial {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (r : ℤ) (_hr : 0 ≤ r)
    (_hp_degen : E₁.DegeneratesAt r)
    (_hg_degen : E₃.DegeneratesAt r)
    (n : ℤ) (k₁ k₂ : ω)
    (φ : sq.extf.essDiff n k₁ k₂ ⟶ sq.extg.essDiff n k₁ k₂)
    (ψ : sq.extf.essDiff (n + 1) k₁ k₂ ⟶ sq.extg.essDiff (n + 1) k₁ k₂)
    (d_f : sq.extf.essDiff n k₁ k₂ ⟶ sq.extf.essDiff (n + 1) k₁ k₂)
    (d_g : sq.extg.essDiff n k₁ k₂ ⟶ sq.extg.essDiff (n + 1) k₁ k₂) :
    φ ≫ d_g = d_f ≫ ψ := by
  sorry
-/

/-- 检测相容性的反向分量投影：把余核投影从 `reindex₂ k` 的 gr 对象
    沿指标相等 `reindex_eq` 搬到 `reindex₄ k` 的 gr 对象。
    与 `detectionGradedProj` 方向相反（conv₂→conv₄），
    端点显式写出，使 `rw`/`show` 重写时无需猜测 eqToHom 的类型。 -/
noncomputable def detectionGradedProjBack {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₂ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₂ A₄ : ω' → C} {F₂ : Filtration A₂} {F₄ : Filtration A₄}
    {conv₂ : Convergence E₂ A₂ F₂} {conv₄ : Convergence E₄ A₄ F₄}
    (cmq : ConvergenceMorphism conv₂ conv₄) (k : ω) :
    F₄.associatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ⟶
      F₄.associatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 :=
  eqToHom (by rw [cmq.reindex_eq])

/-- 检测相容性所需的分量投影：把余核投影从 `reindex₄ k` 的 gr 对象
    沿指标相等 `reindex_eq` 搬到 `reindex₂ k` 的 gr 对象。
    端点显式写出（而非隐藏于 eqToHom 的证明项中），使调用方
    `rw`/`show` 重写时无需猜测 eqToHom 的类型。 -/
noncomputable def detectionGradedProj {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₂ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₂ A₄ : ω' → C} {F₂ : Filtration A₂} {F₄ : Filtration A₄}
    {conv₂ : Convergence E₂ A₂ F₂} {conv₄ : Convergence E₄ A₄ F₄}
    (cmq : ConvergenceMorphism conv₂ conv₄) (k : ω) :
    F₄.associatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 ⟶
      F₄.associatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 :=
  eqToHom (by rw [cmq.reindex_eq])

/-- 检测相容性所需的 gr 同构转移：conv₂ 的收敛同构与 cmq 的 gr 诱导映射复合，
    等于 eMap、conv₄ 的收敛同构、指标传输的复合（`iso_compat` 的搬运形式）。
    证明：把 `detectionGradedProj` 展开为 `transportGraded`，即 `iso_compat`。 -/
theorem detectionGradedProj_compat {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₂ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₂ A₄ : ω' → C} {F₂ : Filtration A₂} {F₄ : Filtration A₄}
    {conv₂ : Convergence E₂ A₂ F₂} {conv₄ : Convergence E₄ A₄ F₄}
    (cmq : ConvergenceMorphism conv₂ conv₄) (k : ω) :
    (conv₂.iso k).hom ≫
        Filtration.inducedAssocGradedMap cmq.aMap cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2 =
      cmq.eMap k ≫ (conv₄.iso k).hom ≫ detectionGradedProj cmq k := by
  show (conv₂.iso k).hom ≫
        Filtration.inducedAssocGradedMap cmq.aMap cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2 =
      cmq.eMap k ≫ (conv₄.iso k).hom ≫
        F₄.transportGraded (congrFun cmq.reindex_eq k).symm
  exact (cmq.iso_compat k).symm

/-- 检测相容性的反向 gr 转移：conv₂ 的收敛同构与 cmq 的 gr 诱导映射复合，
    再与反向传输复合，等于 eMap 与 conv₄ 的收敛同构的复合。
    证明：把两端展开为 `transportGraded`，由 `iso_compat` 与传输消去即得。 -/
theorem detectionGradedProjBack_compat {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₂ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₂ A₄ : ω' → C} {F₂ : Filtration A₂} {F₄ : Filtration A₄}
    {conv₂ : Convergence E₂ A₂ F₂} {conv₄ : Convergence E₄ A₄ F₄}
    (cmq : ConvergenceMorphism conv₂ conv₄) (k : ω) :
    (conv₂.iso k).hom ≫ Filtration.inducedAssocGradedMap cmq.aMap cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      detectionGradedProjBack cmq k =
    cmq.eMap k ≫ (conv₄.iso k).hom := by
  rw [show (conv₂.iso k).hom ≫
      Filtration.inducedAssocGradedMap cmq.aMap cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      detectionGradedProjBack cmq k =
    ((conv₂.iso k).hom ≫
      Filtration.inducedAssocGradedMap cmq.aMap cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
      detectionGradedProjBack cmq k from (Category.assoc _ _ _).symm]
  rw [show ((conv₂.iso k).hom ≫
      Filtration.inducedAssocGradedMap cmq.aMap cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2) =
    cmq.eMap k ≫ (conv₄.iso k).hom ≫ detectionGradedProj cmq k from
    detectionGradedProj_compat cmq k]
  -- 目标此时为左结合 ((eMap≫iso₄≫proj)≫projBack)，先重组为右结合使 proj≫projBack 成子项。
  rw [show (cmq.eMap k ≫ (conv₄.iso k).hom ≫ detectionGradedProj cmq k) ≫
      detectionGradedProjBack cmq k =
    cmq.eMap k ≫ (conv₄.iso k).hom ≫
      (detectionGradedProj cmq k ≫ detectionGradedProjBack cmq k) from by
    rw [Category.assoc, Category.assoc]]
  -- 正反两个传输复合为恒等（𝟙 在 gr(conv₄) 侧，即复合的右端点）。
  rw [show detectionGradedProj cmq k ≫ detectionGradedProjBack cmq k =
      𝟙 (F₄.associatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2) from by
    show eqToHom (by rw [cmq.reindex_eq] :
        F₄.associatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 =
          F₄.associatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
        eqToHom (by rw [cmq.reindex_eq] :
          F₄.associatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 =
            F₄.associatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2) =
      𝟙 (F₄.associatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2)
    rw [eqToHom_trans]
    rw [eqToHom_refl]]
  rw [Category.comp_id]

/-- The detection set data is compatible with the commutativity square maps. -/
theorem essCommutativity_detection_compat {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    {T : C} (k : ω) (y : T ⟶ (E₂.ssData k).eInfty)
    (yrep : DetectionSet conv₂ k y) :
    ∃ (z : T ⟶ (E₄.ssData k).eInfty),
      ∃ (x : T ⟶ Subobject.underlying.obj
          (F₄.F (conv₄.reindex k).1 (conv₄.reindex k).2)),
      Detects conv₄ z x := by
  obtain ⟨x, hx⟩ := yrep
  -- 取 z = y≫eMap；x' 为 conv₂ 侧提升经「子对象传输」送到 conv₄ 的过滤对象。
  -- 传输沿 reindex_eq 的分量 congrFun，两端对象语法上分别含 conv₂/conv₄ 的
  -- 投影应用，避免 congrArg 产生的 β-红式触发 isDefEq 展开实例树。
  refine ⟨y ≫ sq.cmq.eMap k,
    (x ≫ (sq.cmq.filtration_compat (conv₂.reindex k).1 (conv₂.reindex k).2).choose) ≫
      eqToHom (congrArg₂ (fun s k' => Subobject.underlying.obj (F₄.F s k'))
        (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
        (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k))), ?_⟩
  show (y ≫ sq.cmq.eMap k) ≫ (conv₄.iso k).hom =
    ((x ≫ (sq.cmq.filtration_compat (conv₂.reindex k).1 (conv₂.reindex k).2).choose) ≫
      eqToHom (congrArg₂ (fun s k' => Subobject.underlying.obj (F₄.F s k'))
        (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
        (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k)))) ≫
      F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2
  rw [show ((x ≫ (sq.cmq.filtration_compat (conv₂.reindex k).1
        (conv₂.reindex k).2).choose) ≫ eqToHom (congrArg₂
          (fun s k' => Subobject.underlying.obj (F₄.F s k'))
          (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
          (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k)))) ≫
      F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 =
    (x ≫ (sq.cmq.filtration_compat (conv₂.reindex k).1 (conv₂.reindex k).2).choose) ≫
      (eqToHom (congrArg₂ (fun s k' => Subobject.underlying.obj (F₄.F s k'))
          (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
          (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k))) ≫
        F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2) from
    Category.assoc _ _ _]
  -- 关键引理：传输与 conv₄ 投影的复合，等于 conv₂ 投影与反向传输的复合。
  -- 由 eqToHom_heq_id_dom / eqToHom_heq_id_cod 把两段 eqToHom 各自 HEq 到恒等，
  -- 中间用 hty' ▸ HEq.rfl 衔接同一投影在两指标下的 HEq，再由同型性提升为 Eq。
  have hkey : eqToHom (congrArg₂ (fun s k' => Subobject.underlying.obj (F₄.F s k'))
        (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
        (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k))) ≫
      F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 =
    F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      detectionGradedProjBack sq.cmq k := by
    have emid : F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 ≍
        F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 := by
      generalize h₂ : conv₂.reindex k = i₂
      generalize h₄ : conv₄.reindex k = i₄
      have hidx : i₂ = i₄ := by
        simpa only [← h₂, ← h₄] using congrFun sq.cmq.reindex_eq k
      cases hidx
      rfl
    -- 左端：eqToHom 左复合消去为投影本身（eqToHom_comp_heq）。
    have e1 : eqToHom (congrArg₂ (fun s k' =>
          Subobject.underlying.obj (F₄.F s k'))
          (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
          (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k))) ≫
        F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 ≍
        F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 :=
      eqToHom_comp_heq _ _
    -- 右端：传输是 eqToHom 的打包（红式），再由 comp_eqToHom_heq 消去右端传输。
    have e2 : F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        detectionGradedProjBack sq.cmq k ≍
        F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 := by
      show F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
          eqToHom (congrArg (fun r : ℤ × ω' => F₄.associatedGraded r.1 r.2)
            (congrFun sq.cmq.reindex_eq k)) ≍
        F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2
      exact comp_eqToHom_heq _ _
    -- HEq 链：LHS ≍ π₄(conv₄) ≍ π₂(conv₂) ≍ RHS；
    -- eq_of_heq 消去 HEq 得 hEqR（RHS 方向），对称后即 hkey。
    have hEqR : F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        detectionGradedProjBack sq.cmq k =
      eqToHom (congrArg₂ (fun s k' => Subobject.underlying.obj (F₄.F s k'))
          (congrArg Prod.fst (congrFun sq.cmq.reindex_eq k))
          (congrArg Prod.snd (congrFun sq.cmq.reindex_eq k))) ≫
        F₄.toAssociatedGraded (conv₄.reindex k).1 (conv₄.reindex k).2 :=
      eq_of_heq ((e2.trans emid.symm).trans e1.symm)
    exact hEqR.symm
  rw [hkey]
  -- h1：E∞ 侧。iso₂≫grMap≫projBack = eMap≫iso₄（反向相容性定理）。
  -- rw 后两边定义上相等，rfl 无需写出。
  have h1 : y ≫ ((conv₂.iso k).hom ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      detectionGradedProjBack sq.cmq k) =
    y ≫ sq.cmq.eMap k ≫ (conv₄.iso k).hom := by
    rw [detectionGradedProjBack_compat sq.cmq k]
  -- h2：x 侧。choose 提升与 conv₄ 侧投影（conv₂ 指标处），
  -- 等于 conv₂ 投影与 grMap 复合（先经桥接 rw 展开 grMap，再 cokernel.π_desc）。
  have h2 : x ≫ ((sq.cmq.filtration_compat (conv₂.reindex k).1
        (conv₂.reindex k).2).choose ≫
      F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2) =
    x ≫ (F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2) := by
    have h2core : (sq.cmq.filtration_compat (conv₂.reindex k).1
          (conv₂.reindex k).2).choose ≫
        F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 =
      F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2 := by
      rw [Filtration.inducedAssocGradedMap_eq_inducedGradedMapOfMap]
      show (sq.cmq.filtration_compat (conv₂.reindex k).1
            (conv₂.reindex k).2).choose ≫
          cokernel.π (Subobject.ofLE
            (F₄.F ((conv₂.reindex k).1 + 1) (conv₂.reindex k).2)
            (F₄.F (conv₂.reindex k).1 (conv₂.reindex k).2) (F₄.mono _ _)) =
        cokernel.π (Subobject.ofLE
            (F₂.F ((conv₂.reindex k).1 + 1) (conv₂.reindex k).2)
            (F₂.F (conv₂.reindex k).1 (conv₂.reindex k).2) (F₂.mono _ _)) ≫
          cokernel.map
            (Subobject.ofLE (F₂.F ((conv₂.reindex k).1 + 1) (conv₂.reindex k).2)
              (F₂.F (conv₂.reindex k).1 (conv₂.reindex k).2) (F₂.mono _ _))
            (Subobject.ofLE (F₄.F ((conv₂.reindex k).1 + 1) (conv₂.reindex k).2)
              (F₄.F (conv₂.reindex k).1 (conv₂.reindex k).2) (F₄.mono _ _))
            ((sq.cmq.filtration_compat ((conv₂.reindex k).1 + 1) (conv₂.reindex k).2).choose)
            ((sq.cmq.filtration_compat (conv₂.reindex k).1 (conv₂.reindex k).2).choose)
            (Filtration.choose_compat sq.cmq.aMap sq.cmq.filtration_compat
              (conv₂.reindex k).1 (conv₂.reindex k).2)
      rw [cokernel.π_desc]
    -- h2core 无 x；目标两侧均为 x≫(…)，由 congrArg (x≫·) 提升。
    exact congrArg (fun f => x ≫ f) h2core
  -- h3：检测方程沿 grMap 提升（hx 即 `Detects conv₂ y x`；
  -- Detects 为默认透明度 def，与展开后的等式定义上相等）。
  have h3 : y ≫ (conv₂.iso k).hom ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2 =
    x ≫ F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2 := by
    simpa only [Category.assoc] using congrArg (fun f => f ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2) hx
  -- 组装：RHS 经 hkey 后为 x≫(choose≫π₂≫projBack)，h2 化为 x≫(π₂≫grMap≫projBack)，
  -- h3 折回 y≫(iso₂≫grMap≫projBack)，h1 即 y≫(eMap≫iso₄)。
  rw [show (x ≫ (sq.cmq.filtration_compat (conv₂.reindex k).1
        (conv₂.reindex k).2).choose) ≫
      (F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        detectionGradedProjBack sq.cmq k) =
    x ≫ ((sq.cmq.filtration_compat (conv₂.reindex k).1
        (conv₂.reindex k).2).choose ≫
      F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
      detectionGradedProjBack sq.cmq k from by
    rw [Category.assoc, Category.assoc]]
  -- h2 把 choose≫π₄ 换成 π₂≫grMap；此时模式 (x≫a)≫b 语法可见。
  rw [show x ≫ ((sq.cmq.filtration_compat (conv₂.reindex k).1
        (conv₂.reindex k).2).choose ≫
      F₄.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
      detectionGradedProjBack sq.cmq k =
    x ≫ ((F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
      detectionGradedProjBack sq.cmq k) from by
    rw [← Category.assoc, h2, Category.assoc]]
  -- 重组外层为右结合 x≫(π₂≫(grMap≫projBack))（Category.assoc 直接实例化，
  -- 方向：左结合 (a≫b)≫c → 右结合 a≫(b≫c)）。
  rw [show x ≫ ((F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
      detectionGradedProjBack sq.cmq k) =
    x ≫ (F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      (Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
        (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
      detectionGradedProjBack sq.cmq k)) from
    congrArg (fun f => x ≫ f)
      (Category.assoc (F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2)
        (Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2)
        (detectionGradedProjBack sq.cmq k))]
  -- h3 将检测等式沿 grMap 提升，替换右侧的 `x ≫ π₂ ≫ grMap`。
  rw [show x ≫ F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        detectionGradedProjBack sq.cmq k =
      (x ≫ F₂.toAssociatedGraded (conv₂.reindex k).1 (conv₂.reindex k).2 ≫
        Filtration.inducedAssocGradedMap sq.cmq.aMap sq.cmq.filtration_compat
          (conv₂.reindex k).1 (conv₂.reindex k).2) ≫
        detectionGradedProjBack sq.cmq k from by
      simp only [Category.assoc], ← h3]
  -- 现在两侧只差复合结合律；`h1` 正是所需等式的反向。
  simpa only [Category.assoc] using h1.symm
/-
The former page-transition declaration only asserted existence of an arbitrary
morphism, for which the zero morphism was a vacuous witness.  It is omitted
until a genuine transition map is available.

/-- Commutativity is preserved under ESS page transition: if the commutativity
    relation holds at page n, it holds at page n+1 (assuming no new crossings). -/
theorem essCommutativity_page_transition {ω : Type w} [AddCommGroup ω] [DecidableEq ω]
    {E₁ E₂ E₃ E₄ : SpectralSequence C ω} {ω' : Type w}
    {A₁ A₂ A₃ A₄ : ω' → C}
    {F₁ : Filtration A₁} {F₂ : Filtration A₂}
    {F₃ : Filtration A₃} {F₄ : Filtration A₄}
    {conv₁ : Convergence E₁ A₁ F₁} {conv₂ : Convergence E₂ A₂ F₂}
    {conv₃ : Convergence E₃ A₃ F₃} {conv₄ : Convergence E₄ A₄ F₄}
    (sq : HomotopyCommSquare conv₁ conv₂ conv₃ conv₄)
    (n : ℤ) (ky kw : ω)
    (_hq_rel_n : ESSRelation sq.extq n ky kw)
    (_hg_rel_n : ESSRelation sq.extg n ky kw) :
    Nonempty (sq.extq.essDiff n ky kw ⟶ sq.extg.essDiff n ky kw) := by
  exact ⟨0⟩
-/
end KIPBase.SpectralSequence
