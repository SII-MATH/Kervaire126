/-
  KIPBase.Synthetic.Basic
  §3.1 HF₂-synthetic spectra — Syn as a pretriangulated category, hSyn as
  homotopy category, bigrading Σ^{m,n}, natural transformation λ: Σ^{0,-1} → Id,
  X/λⁿ as cofiber, Z[λ]-module enrichment

  ROUND 3 CHANGES (cokernel → cofiber):
  - SyntheticCategory now requires Pretriangulated Syn (with HasShift ℤ, etc.)
  - Removed HasFiniteColimits (triangulated ≠ abelian; cokernels don't exist)
  - Added biShift_compat: Σ^{n,0} ≅ shiftFunctor Syn n
  - XModLambda defined via distinguished_cocone_triangle (cofiber), not cokernel
  - xModLambda_cofiberSeq is now a theorem, not an axiom
  - Added XModLambda.incl, .proj, .triangle_distinguished helpers

  DOWNSTREAM IMPACT: Files importing this module need to add instance parameters:
    [HasZeroObject Syn] [HasShift Syn ℤ]
    [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
    [Pretriangulated Syn]
  Affected: Syn/Nu.lean, Syn/Sphere.lean, Syn/Adams.lean, Syn/Rigidity.lean, Syn/Lift.lean
-/
import Mathlib
import KIPBase.StableHomotopy.TensorTriangulatedCategory

namespace KIPBase.Synthetic

open CategoryTheory CategoryTheory.Limits CategoryTheory.Pretriangulated
open KIPBase.StableHomotopy

universe u v

/-! ### Synthetic spectra category

We axiomatize the category of HF₂-synthetic spectra. The key features are:
- It has a bigraded suspension `biShift (m, n)` (functors Σ^{m,n})
- Σ^{1,0} is identified with the ℤ-shift functor (for the triangulated structure)
- There is a natural transformation λ : Σ^{0,-1} → Id
- Cofibers of λ and its powers give the "mod λ" quotients
- The category is pretriangulated (cofiber sequences from distinguished triangles) -/

/-- The category of synthetic spectra, axiomatized as a pretriangulated category
    with bigraded suspension and the λ natural transformation.

    Synthetic spectra form a triangulated category, NOT an abelian category.
    X/λ is defined as a cofiber via `distinguished_cocone_triangle`, not as a cokernel.

    Instance parameters: `Pretriangulated Syn` provides distinguished triangles.
    `biShift_compat` identifies the first-coordinate shift Σ^{n,0} with the
    triangulated ℤ-shift `shiftFunctor Syn n`. -/
class SyntheticCategory (Syn : Type u) [Category.{v} Syn] [Preadditive Syn]
    [HasZeroObject Syn] [HasShift Syn ℤ]
    [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
    [MonoidalCategory Syn]
    [Pretriangulated Syn] where
  /-- Bigraded suspension functors Σ^{m,n} -/
  biShift : ℤ × ℤ → Syn ⥤ Syn
  /-- Composition of biShift is additive: Σ^{a} ∘ Σ^{b} ≅ Σ^{a+b} -/
  biShift_comp : ∀ (a b : ℤ × ℤ), biShift a ⋙ biShift b ≅ biShift (a + b)
  /-- Σ^{0,0} is the identity functor -/
  biShift_zero : biShift (0, 0) ≅ 𝟭 Syn
  /-- Compatibility: Σ^{n,0} ≅ shiftFunctor Syn n (the triangulated ℤ-shift) -/
  biShift_compat : ∀ n : ℤ, biShift (n, 0) ≅ shiftFunctor Syn n
  /-- λ : Σ^{0,-1} → Id  — the key deformation parameter -/
  lam : biShift (0, -1) ⟶ 𝟭 Syn
  /-- KIP §3: biShift commutes with tensor: Σ^p(X ⊗ Y) ≅ Σ^p(X) ⊗ Y -/
  biShift_tensor_comm : ∀ (p : ℤ × ℤ) (X Y : Syn),
    (biShift p).obj (MonoidalCategory.tensorObj X Y) ≅
      MonoidalCategory.tensorObj ((biShift p).obj X) Y

variable {Syn : Type u} [Category.{v} Syn] [Preadditive Syn]
  [HasZeroObject Syn] [HasShift Syn ℤ]
  [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
  [MonoidalCategory Syn]
  [Pretriangulated Syn] [SyntheticCategory Syn]

/-! ### Cofiber of λ

In a triangulated category, cofibers are obtained from distinguished triangles.
For any morphism f : X → Y, there exists a distinguished triangle X →[f] Y → Z → X⟦1⟧.
The object Z is the cofiber (mapping cone) of f.

We apply this to λ_X : Σ^{0,-1}X → X to get X/λ as the cofiber.
The resulting distinguished triangle is:
  Σ^{0,-1}X →[λ_X] X →[incl] X/λ →[proj] (Σ^{0,-1}X)⟦1⟧ -/

/-- KIP §3: Synthetic spectra have functorial cofiber compatible with tensor. -/
axiom syn_functorial_cofiber :
  TensorTriangulatedCatWithFunctorialCofiber Syn

/-- The cofiber of the λ map on an object X.
    This is X/λ = cofiber(λ_X : Σ^{0,-1}X → X).
    Obtained from the distinguished triangle Σ^{0,-1}X →[λ_X] X → X/λ → (Σ^{0,-1}X)⟦1⟧. -/
noncomputable def XModLambda (X : Syn) : Syn :=
  syn_functorial_cofiber.cofib (SyntheticCategory.lam.app X)

/-- The inclusion map X → X/λ from the cofiber distinguished triangle. -/
noncomputable def XModLambda.incl (X : Syn) : X ⟶ XModLambda X :=
  syn_functorial_cofiber.cofibι (SyntheticCategory.lam.app X)

/-- The projection X/λ → (Σ^{0,-1}X)⟦1⟧ from the cofiber distinguished triangle. -/
noncomputable def XModLambda.proj (X : Syn) :
    XModLambda X ⟶ ((SyntheticCategory.biShift (0, -1)).obj X)⟦(1 : ℤ)⟧ :=
  syn_functorial_cofiber.cofibδ (SyntheticCategory.lam.app X)

/-- The cofiber triangle for λ_X is distinguished. -/
theorem XModLambda.triangle_distinguished (X : Syn) :
    Triangle.mk (SyntheticCategory.lam.app X)
      (XModLambda.incl X) (XModLambda.proj X) ∈ distTriang Syn :=
  syn_functorial_cofiber.cofib_distinguished (SyntheticCategory.lam.app X)

/-- The composite λ_X ≫ incl = 0 in the cofiber triangle. -/
theorem XModLambda.lam_comp_incl (X : Syn) :
    SyntheticCategory.lam.app X ≫ XModLambda.incl X = 0 :=
  comp_distTriang_mor_zero₁₂ _ (XModLambda.triangle_distinguished X)

/-! ### λⁿ: iterated λ morphism

KIP §3, Definition 3.3: The n-th power of λ is the composite
  Σ^{0,-n}X → Σ^{0,-(n-1)}X → ⋯ → Σ^{0,-1}X → X
constructed by induction using `biShift_comp` and `lam`. -/

/-- The n-th power of λ: a morphism Σ^{0,-n}X → X defined by induction.
    - `lambdaPow 0 X` = `biShift_zero.hom.app X` (the identity via Σ^{0,0} ≅ Id)
    - `lambdaPow (n+1) X` = biShift_comp⁻¹ ≫ Σ^{0,-n}(λ_X) ≫ lambdaPow n X -/
noncomputable def lambdaPow : (n : ℕ) → (X : Syn) →
    (SyntheticCategory.biShift (0, -(n : ℤ))).obj X ⟶ X
  | 0, X => SyntheticCategory.biShift_zero.hom.app X
  | n + 1, X => by
    have step1 : (SyntheticCategory.biShift ((0 : ℤ), -1) ⋙
        SyntheticCategory.biShift ((0 : ℤ), -(n : ℤ))).obj X ⟶ X :=
      (SyntheticCategory.biShift ((0 : ℤ), -(n : ℤ))).map (SyntheticCategory.lam.app X) ≫
        lambdaPow n X
    have step2 : (SyntheticCategory.biShift ((0, -1) + (0, -(n : ℤ)))).obj X ⟶ X :=
      (SyntheticCategory.biShift_comp (0, -1) (0, -(n : ℤ))).inv.app X ≫ step1
    have heq : ((0 : ℤ), (-1 : ℤ)) + ((0 : ℤ), -(n : ℤ)) = ((0 : ℤ), -(↑(n + 1) : ℤ)) := by
      simp
    exact heq ▸ step2

/-- The cofiber of λⁿ on X, giving X/λⁿ = cofib(lambdaPow n X).
    KIP §3, Definition 3.3. -/
noncomputable def XModLambdaN (X : Syn) (n : ℕ) : Syn :=
  syn_functorial_cofiber.cofib (lambdaPow n X)

/-- The cofiber triangle for λⁿ is distinguished. -/
theorem XModLambdaN.triangle_distinguished (X : Syn) (n : ℕ) :
    Triangle.mk (lambdaPow n X)
      (syn_functorial_cofiber.cofibι (lambdaPow n X))
      (syn_functorial_cofiber.cofibδ (lambdaPow n X)) ∈ distTriang Syn :=
  syn_functorial_cofiber.cofib_distinguished (lambdaPow n X)

/-! ### Maps between λ-power quotients -/

/-- A map compatible with the `q`-th powers of `λ`.  The upper edge is kept
explicit: the minimal synthetic interface has no theorem that constructs it
for every map, because that construction requires the omitted coherence of
weight shifts with `λ`. -/
structure LambdaPowerSquare {X Y : Syn} (f : X ⟶ Y) (q : ℕ) where
  shiftedMap : (SyntheticCategory.biShift (0, -(q : ℤ))).obj X ⟶
    (SyntheticCategory.biShift (0, -(q : ℤ))).obj Y
  comm : shiftedMap ≫ lambdaPow q Y = lambdaPow q X ≫ f

/-- A λ-power-compatible map descends canonically to the corresponding
cofibers. -/
noncomputable def LambdaPowerSquare.modLambdaMap
    {X Y : Syn} {f : X ⟶ Y} {q : ℕ} (sq : LambdaPowerSquare f q) :
    XModLambdaN X q ⟶ XModLambdaN Y q :=
  syn_functorial_cofiber.cofibMap (lambdaPow q X) (lambdaPow q Y)
    sq.shiftedMap f sq.comm

/-- The descended map agrees with `f` on the canonical cofiber inclusions. -/
theorem LambdaPowerSquare.comp_modLambdaIncl
    {X Y : Syn} {f : X ⟶ Y} {q : ℕ} (sq : LambdaPowerSquare f q) :
    f ≫ syn_functorial_cofiber.cofibι (lambdaPow q Y) =
      syn_functorial_cofiber.cofibι (lambdaPow q X) ≫ sq.modLambdaMap :=
  syn_functorial_cofiber.cofibMap_ι (lambdaPow q X) (lambdaPow q Y)
    sq.shiftedMap f sq.comm

/-- The descended map has the prescribed effect on the connecting maps. -/
theorem LambdaPowerSquare.modLambdaMap_comp_delta
    {X Y : Syn} {f : X ⟶ Y} {q : ℕ} (sq : LambdaPowerSquare f q) :
    sq.modLambdaMap ≫ syn_functorial_cofiber.cofibδ (lambdaPow q Y) =
      syn_functorial_cofiber.cofibδ (lambdaPow q X) ≫
        (shiftFunctor Syn (1 : ℤ)).map sq.shiftedMap :=
  syn_functorial_cofiber.cofibMap_δ (lambdaPow q X) (lambdaPow q Y)
    sq.shiftedMap f sq.comm

/-! ### The λ-quotient tower

For `n ≤ m`, the quotients `X/λ^m` and `X/λ^n` are related by the standard
cofiber sequence
```
Σ^{0,-n}(X/λ^(m-n)) → X/λ^m → X/λ^n → Σ^{1,0}Σ^{0,-n}(X/λ^(m-n)).
```
The first two maps are forced by functorial cofibers once the factorization of
λ-powers is made explicit.  The third map and the fact that this is a
distinguished triangle are the octahedral/TC3 content, so they are packaged
separately below rather than silently postulated by `HasFunctorialCofiber`.
-/

/-- Reassociate the source of `λ^(m-n)` on `Σ^{0,-n}X` with the source of
`λ^m` on `X`. -/
noncomputable def lambdaPowShiftIso (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    (SyntheticCategory.biShift (0, -((m - n : ℕ) : ℤ))).obj
        ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X) ≅
      (SyntheticCategory.biShift (0, -(m : ℤ))).obj X := by
  let d : ℕ := m - n
  exact
    (SyntheticCategory.biShift_comp (Syn := Syn) (0, -(n : ℤ)) (0, -(d : ℤ))).app X ≪≫
      eqToIso (by
        congr 3
        dsimp [d]
        rw [← neg_add, ← Int.natCast_add, Nat.add_sub_of_le hnm])

/-- The factor map `Σ^{0,-m}X → Σ^{0,-n}X` satisfying
`factor ≫ λ^n = λ^m`. -/
noncomputable def lambdaPowFactor (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    (SyntheticCategory.biShift (0, -(m : ℤ))).obj X ⟶
      (SyntheticCategory.biShift (0, -(n : ℤ))).obj X :=
  (lambdaPowShiftIso X n m hnm).inv ≫
    lambdaPow (m - n) ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X)

/-- Coherence of the weight shift with powers of `λ`.

`biShift_comp` only supplies individual isomorphisms of functors.  It does
not assert their associativity coherence, nor that `lam` is compatible with
those isomorphisms.  Consequently this law cannot be derived from the bare
`SyntheticCategory` fields.  It is a capability of a concrete synthetic model,
not an unconditional theorem about every choice of shift isomorphisms. -/
class HasLambdaPowerCoherence where
  factor_comp : ∀ (X : Syn) (n m : ℕ) (hnm : n ≤ m),
    lambdaPowFactor X n m hnm ≫ lambdaPow n X = lambdaPow m X

/-- Compatibility of the factor map with λ-powers, exported from the
coherence carried by the chosen synthetic model. -/
theorem lambdaPowFactor_comp [coherence : HasLambdaPowerCoherence (Syn := Syn)]
    (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    lambdaPowFactor X n m hnm ≫ lambdaPow n X = lambdaPow m X :=
  coherence.factor_comp X n m hnm

/-- The square comparing `λ^(m-n)` on `Σ^{0,-n}X` with `λ^m` on `X`. -/
theorem lambdaPowShift_square [HasLambdaPowerCoherence (Syn := Syn)]
    (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    (lambdaPowShiftIso X n m hnm).hom ≫ lambdaPow m X =
      lambdaPow (m - n) ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X) ≫
        lambdaPow n X := by
  rw [← lambdaPowFactor_comp X n m hnm]
  simp only [lambdaPowFactor, Category.assoc, Iso.hom_inv_id_assoc]

/-- The quotient reduction `ρ_{n,m} : X/λ^m → X/λ^n`. -/
noncomputable def lambdaRho [HasLambdaPowerCoherence (Syn := Syn)]
    (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    XModLambdaN X m ⟶ XModLambdaN X n :=
  syn_functorial_cofiber.cofibMap (lambdaPow m X) (lambdaPow n X)
    (lambdaPowFactor X n m hnm) (𝟙 X) (by
      simpa only [Category.comp_id] using lambdaPowFactor_comp X n m hnm)

/-- The first map in the λ-quotient triangle:
`Σ^{0,-n}(X/λ^(m-n)) → X/λ^m`. -/
noncomputable def lambdaQuotientIncl [HasLambdaPowerCoherence (Syn := Syn)]
    (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    XModLambdaN ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X) (m - n) ⟶
      XModLambdaN X m :=
  syn_functorial_cofiber.cofibMap
    (lambdaPow (m - n) ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X))
    (lambdaPow m X)
    (lambdaPowShiftIso X n m hnm).hom
    (lambdaPow n X)
    (lambdaPowShift_square X n m hnm)

/-- The octahedral data of the λ-quotient tower.  It is intentionally separate
from `HasFunctorialCofiber`: choosing cofibers and maps of cofibers does not
by itself provide the third edge of the octahedral triangle. -/
class HasLambdaQuotientTower extends HasLambdaPowerCoherence (Syn := Syn) where
  delta : ∀ (X : Syn) (n m : ℕ) (_hnm : n ≤ m),
    XModLambdaN X n ⟶
      (shiftFunctor Syn (1 : ℤ)).obj
        (XModLambdaN ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X) (m - n))
  distinguished : ∀ (X : Syn) (n m : ℕ) (hnm : n ≤ m),
    Triangle.mk (lambdaQuotientIncl X n m hnm) (lambdaRho X n m hnm)
      (delta X n m hnm) ∈ distTriang Syn
  rho_comp : ∀ (X : Syn) (n m k : ℕ) (hnm : n ≤ m) (hmk : m ≤ k),
    lambdaRho X m k hmk ≫ lambdaRho X n m hnm =
      lambdaRho X n k (hnm.trans hmk)

/-- The connecting map `δ_{n,m}` of the λ-quotient tower. -/
noncomputable def lambdaDelta [HasLambdaQuotientTower (Syn := Syn)]
    (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    XModLambdaN X n ⟶
      (shiftFunctor Syn (1 : ℤ)).obj
        (XModLambdaN ((SyntheticCategory.biShift (0, -(n : ℤ))).obj X) (m - n)) :=
  HasLambdaQuotientTower.delta X n m hnm

/-- The standard distinguished triangle relating `X/λ^m` and `X/λ^n`. -/
theorem lambdaQuotient_triangle_distinguished [tower : HasLambdaQuotientTower (Syn := Syn)]
    (X : Syn) (n m : ℕ) (hnm : n ≤ m) :
    Triangle.mk (lambdaQuotientIncl X n m hnm) (lambdaRho X n m hnm)
      (lambdaDelta X n m hnm) ∈ distTriang Syn :=
  tower.distinguished X n m hnm

/-- Functorial quotient reductions form an inverse system. -/
theorem lambdaRho_comp [tower : HasLambdaQuotientTower (Syn := Syn)]
    (X : Syn) (n m k : ℕ) (hnm : n ≤ m) (hmk : m ≤ k) :
    lambdaRho X m k hmk ≫ lambdaRho X n m hnm =
      lambdaRho X n k (hnm.trans hmk) :=
  tower.rho_comp X n m k hnm hmk

/-! ### Z[λ]-module enrichment -/

/-- KIP §3, Proposition 3.2: Syn is enriched over ℤ[λ]-modules.
    Axiomatized: requires graded Hom-set construction or MonoidalClosed infrastructure
    not currently available.
    Blueprint: `synthetic.tex`, §3 (zlambda-enrichment). -/
axiom zlambda_enrichment (Syn : Type u) [Category.{v} Syn] [Preadditive Syn]
    [HasZeroObject Syn] [HasShift Syn ℤ]
    [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
    [MonoidalCategory Syn]
    [Pretriangulated Syn]
    [SyntheticCategory Syn] : EnrichedCategory (ModuleCat (Polynomial ℤ)) Syn

end KIPBase.Synthetic
