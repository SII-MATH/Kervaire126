/-
  KIPBase.Synthetic.Mahowald
  The triangulated core of the Generalized Mahowald Trick.

  This module combines the canonical hatted triangle with the λ-quotient
  triangle through May's TC3 lifting lemma.  It deliberately stops before the
  translation to named Adams classes: that translation belongs to the
  synthetic E∞ comparison and the extension spectral-sequence layer.
-/
import KIPBase.Synthetic.Extensions

namespace KIPBase.Synthetic

open CategoryTheory CategoryTheory.Limits CategoryTheory.Pretriangulated
  MonoidalCategory KIPBase.SpectralSequence KIPBase.StableHomotopy

universe u v u' v'

variable (𝒮 : Type u) [StableHomotopy.StableHomotopyCategory.{u, v} 𝒮]
variable (Syn : Type u') [Category.{v'} Syn] [Preadditive Syn]
    [HasZeroObject Syn] [HasShift Syn ℤ]
    [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
    [MonoidalCategory Syn]
    [Pretriangulated Syn] [SyntheticCategory Syn]

/-! ### The two triangles used by the trick -/

/-- The distinguished triangle made from the three canonical hatted maps.
Keeping this as a named triangle prevents later TC3 applications from silently
replacing a hatted map by an existentially chosen edge. -/
noncomputable def hattedTriangle
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1) : Triangle Syn :=
  Triangle.mk
    (hattedMap 𝒮 Syn T.f 0)
    (hattedMap 𝒮 Syn T.g (0 - eHat 𝒮 T.f))
    (hattedMap 𝒮 Syn T.h ((0 - eHat 𝒮 T.f) - eHat 𝒮 T.g) ≫
      (hattedTargetIso 𝒮 Syn T hsum).hom)

/-- The hatted triangle is distinguished by the precise synthetic lifting
theorem, not merely by existence of some triangle on the same objects. -/
theorem hattedTriangle_distinguished
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1) :
    hattedTriangle 𝒮 Syn T hsum ∈ distTriang Syn :=
  canonical_hatted_triangle 𝒮 Syn T hsum

/-- The standard λ-quotient triangle used in the Mahowald diagram. -/
noncomputable def lambdaQuotientTriangle [HasLambdaQuotientTower (Syn := Syn)]
    (Q : Syn) (n m : ℕ) (hnm : n ≤ m) : Triangle Syn :=
  Triangle.mk (lambdaQuotientIncl Q n m hnm) (lambdaRho Q n m hnm)
    (lambdaDelta Q n m hnm)

/-- The named λ-quotient triangle is distinguished. -/
theorem lambdaQuotientTriangle_distinguished [HasLambdaQuotientTower (Syn := Syn)]
    (Q : Syn) (n m : ℕ) (hnm : n ≤ m) :
    lambdaQuotientTriangle Syn Q n m hnm ∈ distTriang Syn :=
  lambdaQuotient_triangle_distinguished Q n m hnm

/-- The λ-quotient indices in the Generalized Mahowald diagram.  The middle
object is reduced modulo `λ^(r' + m₁)` and the right object modulo
`λ^(r' - 1)`; positivity of `r'` makes the left quotient have width
`m₁ + 1`, exactly as in the paper. -/
noncomputable def generalizedMahowaldLambdaTriangle
    [HasLambdaQuotientTower (Syn := Syn)]
    (Q : Syn) (r' m₁ : ℕ) (hr' : 0 < r') : Triangle Syn :=
  lambdaQuotientTriangle Syn Q (r' - 1) (r' + m₁) (by omega)

/-- The width of the left λ-quotient in the Mahowald triangle is `m₁ + 1`. -/
theorem generalizedMahowald_lambda_width (r' m₁ : ℕ) (hr' : 0 < r') :
    (r' + m₁) - (r' - 1) = m₁ + 1 := by
  omega

/-- The first object of the λ-triangle used in the Mahowald diagram has the
paper's quotient exponent `m₁ + 1`. -/
theorem generalizedMahowaldLambdaTriangle_obj₁
    [HasLambdaQuotientTower (Syn := Syn)]
    (Q : Syn) (r' m₁ : ℕ) (hr' : 0 < r') :
    (generalizedMahowaldLambdaTriangle Syn Q r' m₁ hr').obj₁ =
      XModLambdaN
        ((SyntheticCategory.biShift (Syn := Syn) (0, -((r' - 1 : ℕ) : ℤ))).obj Q)
        (m₁ + 1) := by
  change XModLambdaN
      ((SyntheticCategory.biShift (Syn := Syn) (0, -((r' - 1 : ℕ) : ℤ))).obj Q)
      ((r' + m₁) - (r' - 1)) = _
  rw [generalizedMahowald_lambda_width r' m₁ hr']

/-- The middle object is the `λ^(r' + m₁)` quotient from the Mahowald
diagram. -/
theorem generalizedMahowaldLambdaTriangle_obj₂
    [HasLambdaQuotientTower (Syn := Syn)]
    (Q : Syn) (r' m₁ : ℕ) (hr' : 0 < r') :
    (generalizedMahowaldLambdaTriangle Syn Q r' m₁ hr').obj₂ =
      XModLambdaN Q (r' + m₁) :=
  rfl

/-- The right object is the `λ^(r' - 1)` quotient carrying the representative
`[\bar x]` in the Mahowald diagram. -/
theorem generalizedMahowaldLambdaTriangle_obj₃
    [HasLambdaQuotientTower (Syn := Syn)]
    (Q : Syn) (r' m₁ : ℕ) (hr' : 0 < r') :
    (generalizedMahowaldLambdaTriangle Syn Q r' m₁ hr').obj₃ =
      XModLambdaN Q (r' - 1) :=
  rfl

/-! ### May lift in the hatted/λ-quotient diagram -/

/-- The TC3 conclusion in exactly the two triangles used by the Generalized
Mahowald Trick.

An element of the upper-left tensor product and an element of the middle
tensor product that agree after quotient reduction admit a third element in
the opposite corner.  The two equations are the two compatibilities used in
the paper: agreement after the `ĝ`/quotient-inclusion maps, and agreement of
the two boundary images. -/
theorem hatted_lambdaQuotient_may_lift
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1)
    (Q : Syn) (n m : ℕ) (hnm : n ≤ m) {W : Syn}
    (a : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₁ ⊗
      (lambdaQuotientTriangle Syn Q n m hnm).obj₃)
    (b : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₂ ⊗
      (lambdaQuotientTriangle Syn Q n m hnm).obj₂)
    (hab : a ≫ ((hattedTriangle 𝒮 Syn T hsum).mor₁ ▷
      (lambdaQuotientTriangle Syn Q n m hnm).obj₃) =
      b ≫ ((hattedTriangle 𝒮 Syn T hsum).obj₂ ◁
        (lambdaQuotientTriangle Syn Q n m hnm).mor₂)) :
    ∃ c : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₃ ⊗
        (lambdaQuotientTriangle Syn Q n m hnm).obj₁,
      b ≫ ((hattedTriangle 𝒮 Syn T hsum).mor₂ ▷
        (lambdaQuotientTriangle Syn Q n m hnm).obj₂) =
          c ≫ ((hattedTriangle 𝒮 Syn T hsum).obj₃ ◁
            (lambdaQuotientTriangle Syn Q n m hnm).mor₁) ∧
      a ≫ smashRightBoundary Syn (hattedTriangle 𝒮 Syn T hsum)
          (lambdaQuotientTriangle Syn Q n m hnm) =
        c ≫ smashLeftBoundary Syn (hattedTriangle 𝒮 Syn T hsum)
          (lambdaQuotientTriangle Syn Q n m hnm) := by
  exact mayTC3_smash_lift Syn
    (hattedTriangle_distinguished 𝒮 Syn T hsum)
    (lambdaQuotientTriangle_distinguished Syn Q n m hnm) a b hab

/-- Selected representatives immediately before applying May's lemma.
Each selected map lands in the common target after its respective edge; the
middle-square compatibility is derived from these two equalities below. -/
structure GeneralizedMahowaldSelectedRepresentatives
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1)
    (Q : Syn) (n m : ℕ) (hnm : n ≤ m) (W : Syn) where
  a : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₁ ⊗
    (lambdaQuotientTriangle Syn Q n m hnm).obj₃
  b : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₂ ⊗
    (lambdaQuotientTriangle Syn Q n m hnm).obj₂
  commonImage : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₂ ⊗
    (lambdaQuotientTriangle Syn Q n m hnm).obj₃
  a_to_common : a ≫ ((hattedTriangle 𝒮 Syn T hsum).mor₁ ▷
      (lambdaQuotientTriangle Syn Q n m hnm).obj₃) = commonImage
  b_to_common : b ≫ ((hattedTriangle 𝒮 Syn T hsum).obj₂ ◁
      (lambdaQuotientTriangle Syn Q n m hnm).mor₂) = commonImage

/-- Input to the triangulated form of the Generalized Mahowald Trick.

The two named triangles retain the hatted maps and the precise λ-quotient
indices. `compatible` is the middle-square equality in May's `3 × 3` diagram;
it is exactly the datum produced after translating the two extension relations
in the paper to synthetic homotopy classes. -/
structure GeneralizedMahowaldCoreInput
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1)
    (Q : Syn) (n m : ℕ) (hnm : n ≤ m) (W : Syn) where
  a : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₁ ⊗
    (lambdaQuotientTriangle Syn Q n m hnm).obj₃
  b : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₂ ⊗
    (lambdaQuotientTriangle Syn Q n m hnm).obj₂
  compatible : a ≫ ((hattedTriangle 𝒮 Syn T hsum).mor₁ ▷
      (lambdaQuotientTriangle Syn Q n m hnm).obj₃) =
    b ≫ ((hattedTriangle 𝒮 Syn T hsum).obj₂ ◁
      (lambdaQuotientTriangle Syn Q n m hnm).mor₂)

/-- Assemble independently selected representatives into May's input.
Compatibility is proved because both composites are `commonImage`; it is not
an additional hypothesis. -/
def GeneralizedMahowaldSelectedRepresentatives.toCoreInput
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldSelectedRepresentatives 𝒮 Syn T hsum Q n m hnm W) :
    GeneralizedMahowaldCoreInput 𝒮 Syn T hsum Q n m hnm W where
  a := D.a
  b := D.b
  compatible := D.a_to_common.trans D.b_to_common.symm

def GeneralizedMahowaldCoreInput.Conclusion
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldCoreInput 𝒮 Syn T hsum Q n m hnm W) : Prop :=
  ∃ c : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₃ ⊗
      (lambdaQuotientTriangle Syn Q n m hnm).obj₁,
    D.b ≫ ((hattedTriangle 𝒮 Syn T hsum).mor₂ ▷
      (lambdaQuotientTriangle Syn Q n m hnm).obj₂) =
        c ≫ ((hattedTriangle 𝒮 Syn T hsum).obj₃ ◁
          (lambdaQuotientTriangle Syn Q n m hnm).mor₁) ∧
    D.a ≫ smashRightBoundary Syn (hattedTriangle 𝒮 Syn T hsum)
        (lambdaQuotientTriangle Syn Q n m hnm) =
      c ≫ smashLeftBoundary Syn (hattedTriangle 𝒮 Syn T hsum)
        (lambdaQuotientTriangle Syn Q n m hnm)

/-- A chosen diagonal representative supplied by the triangulated Mahowald
argument. Keeping it as data is convenient for the later Adams-page
interpretation, which must apply both displayed equalities to the same map. -/
structure GeneralizedMahowaldCoreWitness
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldCoreInput 𝒮 Syn T hsum Q n m hnm W) where
  c : W ⟶ (hattedTriangle 𝒮 Syn T hsum).obj₃ ⊗
    (lambdaQuotientTriangle Syn Q n m hnm).obj₁
  middle : D.b ≫ ((hattedTriangle 𝒮 Syn T hsum).mor₂ ▷
      (lambdaQuotientTriangle Syn Q n m hnm).obj₂) =
    c ≫ ((hattedTriangle 𝒮 Syn T hsum).obj₃ ◁
      (lambdaQuotientTriangle Syn Q n m hnm).mor₁)
  boundary : D.a ≫ smashRightBoundary Syn (hattedTriangle 𝒮 Syn T hsum)
      (lambdaQuotientTriangle Syn Q n m hnm) =
    c ≫ smashLeftBoundary Syn (hattedTriangle 𝒮 Syn T hsum)
      (lambdaQuotientTriangle Syn Q n m hnm)

/-- Forgetting a chosen diagonal representative recovers the propositional
conclusion of the triangulated Mahowald argument. -/
theorem GeneralizedMahowaldCoreWitness.conclusion
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    {D : GeneralizedMahowaldCoreInput 𝒮 Syn T hsum Q n m hnm W}
    (L : GeneralizedMahowaldCoreWitness (𝒮 := 𝒮) (Syn := Syn) D) : D.Conclusion :=
  ⟨L.c, L.middle, L.boundary⟩

/-- **Generalized Mahowald Trick, triangulated core.** A compatible pair of
the two extension representatives has a third representative in the opposite
corner of the hatted/λ-quotient diagram. The two displayed equations are the
equalities used in the subsequent translation to an extension on a specified
Adams page. -/
theorem generalizedMahowald_trick_core
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldCoreInput 𝒮 Syn T hsum Q n m hnm W) : D.Conclusion := by
  exact hatted_lambdaQuotient_may_lift 𝒮 Syn T hsum Q n m hnm
    D.a D.b D.compatible

/-- The selected-representative form of the Generalized Mahowald core.
The two equalities supplied by representative selection first produce the
May compatibility square and then give the diagonal representative. -/
theorem generalizedMahowald_trick_of_selectedRepresentatives
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldSelectedRepresentatives 𝒮 Syn T hsum Q n m hnm W) :
    D.toCoreInput.Conclusion :=
  generalizedMahowald_trick_core (𝒮 := 𝒮) (Syn := Syn) D.toCoreInput

/-- A chosen diagonal representative obtained from selected Mahowald
representatives.  Keeping this witness, rather than only its existential
conclusion, ensures that the middle and boundary equations used in the later
Adams-page translation refer to the same map. -/
noncomputable def generalizedMahowald_selected_witness
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldSelectedRepresentatives 𝒮 Syn T hsum Q n m hnm W) :
    GeneralizedMahowaldCoreWitness (𝒮 := 𝒮) (Syn := Syn) D.toCoreInput :=
  by
    apply Classical.choice
    rcases generalizedMahowald_trick_of_selectedRepresentatives
      (𝒮 := 𝒮) (Syn := Syn) D with ⟨c, hmiddle, hboundary⟩
    exact ⟨⟨c, hmiddle, hboundary⟩⟩

/-- The two page-level conclusions of the Generalized Mahowald Trick. -/
structure GeneralizedMahowaldPageConclusion where
  survives : Prop
  extensionModBoundary : Prop

/-- Both asserted page-level conclusions hold. -/
def GeneralizedMahowaldPageConclusion.Holds
    (P : GeneralizedMahowaldPageConclusion) : Prop :=
  P.survives ∧ P.extensionModBoundary

/-- The abstract final translation from a diagonal witness to a chosen
page-level interpretation.  Both conclusions consume the same witness. -/
structure GeneralizedMahowaldPageTranslation
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldSelectedRepresentatives 𝒮 Syn T hsum Q n m hnm W)
    (P : GeneralizedMahowaldPageConclusion) where
  ofDiagonal : GeneralizedMahowaldCoreWitness (𝒮 := 𝒮) (Syn := Syn)
    D.toCoreInput → P.Holds

/-- **Generalized Mahowald Trick, abstract page form.** -/
theorem generalizedMahowald_trick_page
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldSelectedRepresentatives 𝒮 Syn T hsum Q n m hnm W)
    (P : GeneralizedMahowaldPageConclusion)
    (R : GeneralizedMahowaldPageTranslation (𝒮 := 𝒮) (Syn := Syn) D P) :
    P.Holds :=
  R.ofDiagonal (generalizedMahowald_selected_witness (𝒮 := 𝒮) (Syn := Syn) D)

/-- Complete abstract input for the Generalized Mahowald Trick.  The
representative-selection and page-interpretation layers remain explicit, but
clients no longer need to thread their compatibility through May's lemma by
hand. -/
structure GeneralizedMahowaldInput
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1)
    (Q : Syn) (n m : ℕ) (hnm : n ≤ m) (W : Syn) where
  selected : GeneralizedMahowaldSelectedRepresentatives 𝒮 Syn T hsum Q n m hnm W
  pageConclusion : GeneralizedMahowaldPageConclusion
  pageTranslation : GeneralizedMahowaldPageTranslation
    (𝒮 := 𝒮) (Syn := Syn) selected pageConclusion

/-- **Generalized Mahowald Trick.** The complete abstract input yields both
the asserted survival statement and the extension statement modulo boundary. -/
theorem GeneralizedMahowaldInput.conclusion
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldInput 𝒮 Syn T hsum Q n m hnm W) :
    D.pageConclusion.Holds :=
  generalizedMahowald_trick_page (𝒮 := 𝒮) (Syn := Syn)
    D.selected D.pageConclusion D.pageTranslation

/-- A choice of the diagonal representative from the Generalized Mahowald
Trick. The choice is noncomputable because May's lifting property is stated
existentially. -/
noncomputable def generalizedMahowald_trick_core_witness
    [ClosedSymmetricTensorTriangulated Syn] [HasLambdaQuotientTower (Syn := Syn)]
    [HasMayTC3SmashLift Syn]
    {T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)}
    {hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1}
    {Q : Syn} {n m : ℕ} {hnm : n ≤ m} {W : Syn}
    (D : GeneralizedMahowaldCoreInput 𝒮 Syn T hsum Q n m hnm W) :
    GeneralizedMahowaldCoreWitness (𝒮 := 𝒮) (Syn := Syn) D := by
  apply Classical.choice
  rcases generalizedMahowald_trick_core (𝒮 := 𝒮) (Syn := Syn) D with
    ⟨c, hmiddle, hboundary⟩
  exact ⟨⟨c, hmiddle, hboundary⟩⟩

end KIPBase.Synthetic
