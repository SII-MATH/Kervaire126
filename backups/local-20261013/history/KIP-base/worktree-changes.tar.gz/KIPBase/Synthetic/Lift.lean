/-
  KIPBase.Synthetic.Lift
  §3.6 Synthetic lift — ν on Adams filtration k maps can be divided by λᵏ,
  Adams filtration = λ-Bockstein filtration (§3.16),
  canonical division by λ for Adams filtration 1 maps (§3.17),
  ν applied to distinguished triangles: notation §3.19, §3.20
-/
import Mathlib
import KIPBase.Synthetic.Rigidity
import KIPBase.StableHomotopy.Adams

namespace KIPBase.Synthetic

open CategoryTheory CategoryTheory.Limits CategoryTheory.Pretriangulated
  KIPBase.SpectralSequence KIPBase.StableHomotopy

universe u v u' v'

variable (𝒮 : Type u) [StableHomotopy.StableHomotopyCategory.{u, v} 𝒮]
variable (Syn : Type u') [Category.{v'} Syn] [Preadditive Syn]
    [HasZeroObject Syn] [HasShift Syn ℤ]
    [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
    [MonoidalCategory Syn]
    [Pretriangulated Syn] [SyntheticCategory Syn]

/-! ### Synthetic lift

If a map f : X → Y in the stable homotopy category has Adams filtration AF(f) = k,
then ν(f) factors through λᵏ. That is, there exists a "synthetic lift"
f̃ : Σ^{0,k}ν(X) → ν(Y) such that ν(f) = λᵏ ∘ f̃. -/

/-- KIP §3.6, Lemma 9.15 (synthetic lift): if `f` has Adams filtration
    `k`, its synthetic image factors through a map of weight `k`.

    The former interface returned a lift together with `True`, which discarded
    the factorization it was meant to express.  Keeping the factor map and its
    equality is essential: later constructions must be able to identify a
    hatted map, rather than merely know that a map of the right type exists. -/
axiom synthetic_lift {X Y : 𝒮} (f : X ⟶ Y) (k : ℤ) :
    ∃ (f_tilde : (SyntheticCategory.biShift (Syn := Syn) (0, k)).obj
          ((nu 𝒮 Syn).obj X) ⟶ (nu 𝒮 Syn).obj Y)
      (ι : (nu 𝒮 Syn).obj X ⟶
          (SyntheticCategory.biShift (Syn := Syn) (0, k)).obj ((nu 𝒮 Syn).obj X)),
      (nu 𝒮 Syn).map f = ι ≫ f_tilde

/-! ### ê and f̂ notation -/

/-- ê(f) = 0 if AF(f) = 0, and ê(f) = 1 if AF(f) > 0.
    This is the "essential" Adams filtration, which only distinguishes
    between filtration 0 and positive filtration. -/
noncomputable def eHat {X Y : 𝒮} (f : X ⟶ Y) : ℤ :=
  if AF f = 0 then 0 else 1

/-- f̂ is the canonical synthetic lift of f divided by λ^{ê(f)}.
    That is, f̂ : Σ^{0, ê(f)} ν(X) → ν(Y) with ν(f) = λ^{ê(f)} ∘ f̂. -/
noncomputable def fHat {X Y : 𝒮} (f : X ⟶ Y) :
    (SyntheticCategory.biShift (Syn := Syn) (0, eHat 𝒮 f)).obj ((nu 𝒮 Syn).obj X) ⟶
      (nu 𝒮 Syn).obj Y :=
  (synthetic_lift 𝒮 Syn f (eHat 𝒮 f)).choose

/-- The factor into the source of `fHat`.  This is retained explicitly so the
    defining equation of a chosen hatted lift is available by reduction. -/
noncomputable def fHatFactor {X Y : 𝒮} (f : X ⟶ Y) :
    (nu 𝒮 Syn).obj X ⟶
      (SyntheticCategory.biShift (Syn := Syn) (0, eHat 𝒮 f)).obj
        ((nu 𝒮 Syn).obj X) :=
  (synthetic_lift 𝒮 Syn f (eHat 𝒮 f)).choose_spec.choose

/-- KIP §3.6, Lemma 9.15 (f̂ specification): The defining property of f̂:
    ν(f) factors as ι ≫ f̂ where ι : ν(X) → Σ^{0,ê(f)}(ν(X)) is the
    λ-power morphism. Concretely, ν(f) = λ^{ê(f)} ∘ f̂. -/
theorem fHat_spec {X Y : 𝒮} (f : X ⟶ Y) :
    (nu 𝒮 Syn).map f = fHatFactor 𝒮 Syn f ≫ fHat 𝒮 Syn f :=
  (synthetic_lift 𝒮 Syn f (eHat 𝒮 f)).choose_spec.choose_spec

/-! ### Canonical maps in the hatted triangle

The Generalized Mahowald Trick needs the *particular* triangle whose edges are
the three hatted lifts with their prescribed weight shifts.  An existential
distinguished triangle is not enough: it gives no way to apply a result to the
maps `f̂`, `ĝ`, and `ĥ` already occurring in extension data.
-/

/-- The pure weight-shift functor `Σ^{0,a}`. -/
abbrev weightShift (a : ℤ) : Syn ⥤ Syn :=
  SyntheticCategory.biShift (0, a)

/-- Shift a hatted lift by weight `a`.  Its source and target are exactly
    `Σ^{0,a}νX` and `Σ^{0,a-ê(f)}νY`; the two coherence maps here are the
    only transports hidden by the customary notation for a hatted triangle. -/
noncomputable def hattedMap {X Y : 𝒮} (f : X ⟶ Y) (a : ℤ) :
    (weightShift (Syn := Syn) a).obj ((nu 𝒮 Syn).obj X) ⟶
      (weightShift (Syn := Syn) (a - eHat 𝒮 f)).obj ((nu 𝒮 Syn).obj Y) := by
  let e := eHat 𝒮 f
  let p : ℤ := a - e
  let transport :
      (weightShift (Syn := Syn) a).obj ((nu 𝒮 Syn).obj X) ⟶
        ((weightShift (Syn := Syn) e ⋙ weightShift (Syn := Syn) p).obj
          ((nu 𝒮 Syn).obj X)) :=
    eqToHom (by
      dsimp [weightShift, e, p]
      congr 3
      all_goals omega) ≫
      (SyntheticCategory.biShift_comp (Syn := Syn) (0, e) (0, p)).inv.app
        ((nu 𝒮 Syn).obj X)
  exact transport ≫ (weightShift (Syn := Syn) p).map (fHat 𝒮 Syn f)

/-- The final identification in the hatted triangle.  If the three essential
    filtrations add to one, then shifting `ν(ΣX)` by their negative sum is
    canonically `Σ^{1,0}νX`, hence the ordinary triangulated suspension. -/
noncomputable def hattedTargetIso (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1) :
    (weightShift (Syn := Syn)
      (((0 - eHat 𝒮 T.f) - eHat 𝒮 T.g) - eHat 𝒮 T.h)).obj
        ((nu 𝒮 Syn).obj ((shiftFunctor 𝒮 (1 : ℤ)).obj T.X)) ≅
      (shiftFunctor Syn (1 : ℤ)).obj
        ((weightShift (Syn := Syn) 0).obj ((nu 𝒮 Syn).obj T.X)) :=
  by
    have hweight : ((1 : ℤ), 1) +
        ((0 : ℤ), ((0 - eHat 𝒮 T.f) - eHat 𝒮 T.g) - eHat 𝒮 T.h) = ((1 : ℤ), 0) := by
      apply Prod.ext
      · rfl
      · dsimp
        omega
    exact
      (weightShift (Syn := Syn)
        (((0 - eHat 𝒮 T.f) - eHat 𝒮 T.g) - eHat 𝒮 T.h)).mapIso
          (nu_susp 𝒮 Syn T.X) ≪≫
        (SyntheticCategory.biShift_comp (Syn := Syn) (1, 1)
          (0, ((0 - eHat 𝒮 T.f) - eHat 𝒮 T.g) - eHat 𝒮 T.h)).app
            ((nu 𝒮 Syn).obj T.X) ≪≫
        eqToIso (congrArg
          (fun p => (SyntheticCategory.biShift (Syn := Syn) p).obj ((nu 𝒮 Syn).obj T.X))
          hweight) ≪≫
        (SyntheticCategory.biShift_compat (Syn := Syn) 1).app ((nu 𝒮 Syn).obj T.X) ≪≫
        (shiftFunctor Syn (1 : ℤ)).mapIso
          ((SyntheticCategory.biShift_zero (Syn := Syn)).symm.app ((nu 𝒮 Syn).obj T.X))

/-- KIP §3.20 in the exact form used by the Generalized Mahowald Trick.
    Unlike the older `fhat_triangle`, the three morphisms are not arbitrary
    witnesses: they are the canonical shifted maps constructed from `fHat`.
    This is the interface needed to smash this triangle with a λ-quotient
    triangle in the Mahowald argument. -/
axiom canonical_hatted_triangle (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1) :
    Triangle.mk
      (hattedMap 𝒮 Syn T.f 0)
      (hattedMap 𝒮 Syn T.g (0 - eHat 𝒮 T.f))
      (hattedMap 𝒮 Syn T.h ((0 - eHat 𝒮 T.f) - eHat 𝒮 T.g) ≫
        (hattedTargetIso 𝒮 Syn T hsum).hom) ∈ distTriang Syn

/-! ### Distinguished triangles in synthetic spectra -/

/-- KIP §3, Proposition 3.19: Given a cofiber sequence X → Y → Z → ΣX in 𝒮,
    ν preserves the cofiber sequence: there exists a distinguished triangle
    ν(X) →[ν(f)] ν(Y) →[ν(g)] ν(Z) →[h'] (ν(X))⟦1⟧ in Syn.
    The connecting map h' differs from ν(h) by a weight-shift correction
    (since ν takes Σ to Σ^{1,1}, not Σ^{1,0}). -/
axiom syn_distinguished_triangle
    (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)) :
    ∃ (h' : (nu 𝒮 Syn).obj T.Z ⟶ ((nu 𝒮 Syn).obj T.X)⟦(1 : ℤ)⟧),
      Triangle.mk ((nu 𝒮 Syn).map T.f) ((nu 𝒮 Syn).map T.g) h' ∈ distTriang Syn

/-- KIP §3, Proposition 3.20 (f̂ triangle): Given a cofiber sequence
    X →[f] Y →[g] Z →[h] ΣX with ê(f) + ê(g) + ê(h) = 1, there is a
    distinguished triangle of synthetic spectra involving the ν-images
    of X, Y, Z.

    Since exactly one of ê(f), ê(g), ê(h) is 1, the triangle involves
    the f̂, ĝ, ĥ lifts (with weight-shift corrections on two of the
    three morphisms). -/
axiom fhat_triangle (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮))
    (hsum : eHat 𝒮 T.f + eHat 𝒮 T.g + eHat 𝒮 T.h = 1) :
    ∃ (f' : (nu 𝒮 Syn).obj T.X ⟶ (nu 𝒮 Syn).obj T.Y)
      (g' : (nu 𝒮 Syn).obj T.Y ⟶ (nu 𝒮 Syn).obj T.Z)
      (h' : (nu 𝒮 Syn).obj T.Z ⟶ ((nu 𝒮 Syn).obj T.X)⟦(1 : ℤ)⟧),
      Triangle.mk f' g' h' ∈ distTriang Syn

/-- KIP §3, Notation 3.19 (cofiber of f̂): The distinguished triangle
    extending f̂(f) has third vertex isomorphic to Σ^{0, -ê(g)} ν(Z).
    Concretely, C(f̂) ≅ Σ^{0, -ê(g)} ν(Cf), relating the cofiber of the
    synthetic lift to the ν of the classical cofiber, up to a weight shift. -/
axiom cofiber_fhat (T : StableHomotopy.HoCofiberSequence (𝒮 := 𝒮)) :
    ∃ (g' : (nu 𝒮 Syn).obj T.Y ⟶
          (SyntheticCategory.biShift (Syn := Syn) (0, -eHat 𝒮 T.g)).obj
            ((nu 𝒮 Syn).obj T.Z))
      (h' : (SyntheticCategory.biShift (Syn := Syn) (0, -eHat 𝒮 T.g)).obj
            ((nu 𝒮 Syn).obj T.Z) ⟶
          ((SyntheticCategory.biShift (Syn := Syn) (0, eHat 𝒮 T.f)).obj
            ((nu 𝒮 Syn).obj T.X))⟦(1 : ℤ)⟧),
      Triangle.mk (fHat 𝒮 Syn T.f) g' h' ∈ distTriang Syn

/-! ### Adams filtration = λ-Bockstein filtration -/

/-- KIP §3.16 (Adams filtration = λ-Bockstein filtration): If AF(f) ≥ k,
    then ν(f) factors through Σ^{0,k} via a synthetic lift. Concretely,
    ∃ f̃ : Σ^{0,k}ν(X) → ν(Y) and ι : ν(X) → Σ^{0,k}ν(X) (the λ^k power
    map) such that ν(f) = ι ≫ f̃.

    The converse (factorization implies AF ≥ k) together with this direction
    gives AF(f) = sup { k : ν(f) factors through λᵏ }. -/
axiom af_eq_lambda_bockstein {X Y : 𝒮} (f : X ⟶ Y) (k : ℤ) :
    HasAF_ge f k →
    ∃ (f_tilde : (SyntheticCategory.biShift (Syn := Syn) (0, k)).obj
          ((nu 𝒮 Syn).obj X) ⟶ (nu 𝒮 Syn).obj Y)
      (ι : (nu 𝒮 Syn).obj X ⟶
          (SyntheticCategory.biShift (Syn := Syn) (0, k)).obj ((nu 𝒮 Syn).obj X)),
      (nu 𝒮 Syn).map f = ι ≫ f_tilde

end KIPBase.Synthetic
