/-
  KIPBase.Synthetic.Extensions
  Bridges between λ-quotients of synthetic spectra, classical Adams Z/B
  quotients, and extension spectral sequences.

  This file deliberately records the comparison data explicitly.  The generic
  `SpectralSequence` interface only has Bᵢ ≤ Zᵢ; the mixed quotient
  B_(l+1) \ Z_(q-l) occurring for νX/λ^q therefore cannot be fabricated from
  monotonicity alone.
-/
import KIPBase.Synthetic.Lift
import KIPBase.SpectralSequence.BoundedExtension

namespace KIPBase.Synthetic

open CategoryTheory CategoryTheory.Limits CategoryTheory.Pretriangulated
  KIPBase.SpectralSequence KIPBase.StableHomotopy

universe u v u' v'

/-! ### Classical mixed cycle--boundary quotients -/

/-- The quotient `Z / B` when the cycle and boundary levels need not be the
    same.  This is the categorical version of the groups `Z_a^{s,t}/B_b^{s,t}`
    used in the synthetic λ-quotient comparison. -/
noncomputable def cycleBoundaryQuotient
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z) : C :=
  cokernel (Subobject.ofLE (D.B b) (D.Z z) hBZ)

/-- A map between mixed cycle--boundary quotients, induced by compatible maps
on the cycle and boundary subobjects. -/
noncomputable def cycleBoundaryQuotientMap
    {C : Type u} [Category.{v} C] [Abelian C]
    {D E : SSData C} {z b z' b' : WithTop ℕ}
    (hDBZ : D.B b ≤ D.Z z) (hEBZ : E.B b' ≤ E.Z z')
    (onBoundaries : Subobject.underlying.obj (D.B b) ⟶
      Subobject.underlying.obj (E.B b'))
    (onCycles : Subobject.underlying.obj (D.Z z) ⟶
      Subobject.underlying.obj (E.Z z'))
    (compat : onBoundaries ≫ Subobject.ofLE (E.B b') (E.Z z') hEBZ =
      Subobject.ofLE (D.B b) (D.Z z) hDBZ ≫ onCycles) :
    cycleBoundaryQuotient D z b hDBZ ⟶ cycleBoundaryQuotient E z' b' hEBZ :=
  cokernel.map
    (Subobject.ofLE (D.B b) (D.Z z) hDBZ)
    (Subobject.ofLE (E.B b') (E.Z z') hEBZ)
    onBoundaries onCycles compat.symm

/-- The quotient map induced from compatible cycle/boundary maps commutes
with the canonical quotient projections. -/
theorem cycleBoundaryQuotientMap_π
    {C : Type u} [Category.{v} C] [Abelian C]
    {D E : SSData C} {z b z' b' : WithTop ℕ}
    (hDBZ : D.B b ≤ D.Z z) (hEBZ : E.B b' ≤ E.Z z')
    (onBoundaries : Subobject.underlying.obj (D.B b) ⟶
      Subobject.underlying.obj (E.B b'))
    (onCycles : Subobject.underlying.obj (D.Z z) ⟶
      Subobject.underlying.obj (E.Z z'))
    (compat : onBoundaries ≫ Subobject.ofLE (E.B b') (E.Z z') hEBZ =
      Subobject.ofLE (D.B b) (D.Z z) hDBZ ≫ onCycles) :
    cokernel.π (Subobject.ofLE (D.B b) (D.Z z) hDBZ) ≫
      cycleBoundaryQuotientMap hDBZ hEBZ onBoundaries onCycles compat =
    onCycles ≫ cokernel.π (Subobject.ofLE (E.B b') (E.Z z') hEBZ) := by
  unfold cycleBoundaryQuotientMap cokernel.map
  exact cokernel.π_desc _ _ _

/-- Equality of two cycle representatives after quotienting by a specified
boundary level. This is the categorical reading of the notation
`x ≡ y mod B_b` inside `Z_z / B_b`. -/
def congruentModCycleBoundary
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z)
    {T : C} (x y : T ⟶ Subobject.underlying.obj (D.Z z)) : Prop :=
  x ≫ cokernel.π (Subobject.ofLE (D.B b) (D.Z z) hBZ) =
    y ≫ cokernel.π (Subobject.ofLE (D.B b) (D.Z z) hBZ)

/-- Two cycle representatives are congruent modulo the boundary precisely
when their difference factors through that boundary in the ambient object. -/
theorem congruentModCycleBoundary_iff_difference_factors
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z)
    {T : C} (x y : T ⟶ Subobject.underlying.obj (D.Z z)) :
    congruentModCycleBoundary D z b hBZ x y ↔
      Subobject.Factors (D.B b) ((x - y) ≫ (D.Z z).arrow) := by
  let i := Subobject.ofLE (D.B b) (D.Z z) hBZ
  constructor
  · intro h
    have hzero : (x - y) ≫ cokernel.π i = 0 := by
      rw [Preadditive.sub_comp, h, sub_self]
    let lift := Abelian.monoLift i (x - y) hzero
    rw [← Subobject.mk_arrow (D.B b), Subobject.mk_factors_iff]
    refine ⟨lift, ?_⟩
    change lift ≫ (D.B b).arrow = (x - y) ≫ (D.Z z).arrow
    rw [show lift ≫ (D.B b).arrow = lift ≫ i ≫ (D.Z z).arrow by
      dsimp [i]
      rw [Subobject.ofLE_arrow], ← Abelian.monoLift_comp i (x - y) hzero,
      Category.assoc]
  · intro hfac
    rw [← Subobject.mk_arrow (D.B b), Subobject.mk_factors_iff] at hfac
    rcases hfac with ⟨u, hu⟩
    change u ≫ (D.B b).arrow = (x - y) ≫ (D.Z z).arrow at hu
    have hxi : x - y = u ≫ i := by
      apply (inferInstance : Mono (D.Z z).arrow).right_cancellation
      rw [← hu]
      dsimp [i]
      rw [Category.assoc, Subobject.ofLE_arrow]
    have hzero : (x - y) ≫ cokernel.π i = 0 := by
      rw [hxi, Category.assoc, cokernel.condition, comp_zero]
    rw [Preadditive.sub_comp, sub_eq_zero] at hzero
    exact hzero

/-- Congruence modulo a fixed boundary is reflexive. -/
theorem congruentModCycleBoundary_refl
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z)
    {T : C} (x : T ⟶ Subobject.underlying.obj (D.Z z)) :
    congruentModCycleBoundary D z b hBZ x x :=
  rfl

/-- Congruence modulo a fixed boundary is symmetric. -/
theorem congruentModCycleBoundary_symm
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z)
    {T : C} {x y : T ⟶ Subobject.underlying.obj (D.Z z)}
    (h : congruentModCycleBoundary D z b hBZ x y) :
    congruentModCycleBoundary D z b hBZ y x :=
  h.symm

/-- Congruence modulo a fixed boundary is transitive. -/
theorem congruentModCycleBoundary_trans
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z)
    {T : C} {x y w : T ⟶ Subobject.underlying.obj (D.Z z)}
    (hxy : congruentModCycleBoundary D z b hBZ x y)
    (hyw : congruentModCycleBoundary D z b hBZ y w) :
    congruentModCycleBoundary D z b hBZ x w :=
  hxy.trans hyw

/-- Boundary congruence is preserved by precomposition of generalized
elements. -/
theorem congruentModCycleBoundary_precomp
    {C : Type u} [Category.{v} C] [Abelian C]
    (D : SSData C) (z b : WithTop ℕ) (hBZ : D.B b ≤ D.Z z)
    {S T : C} (u : S ⟶ T) {x y : T ⟶ Subobject.underlying.obj (D.Z z)}
    (h : congruentModCycleBoundary D z b hBZ x y) :
    congruentModCycleBoundary D z b hBZ (u ≫ x) (u ≫ y) := by
  change (u ≫ x) ≫ cokernel.π (Subobject.ofLE (D.B b) (D.Z z) hBZ) =
    (u ≫ y) ≫ cokernel.π (Subobject.ofLE (D.B b) (D.Z z) hBZ)
  simpa only [Category.assoc] using congrArg (fun v => u ≫ v) h

/-- A map induced on mixed quotients sends congruent cycle representatives to
congruent cycle representatives. -/
theorem cycleBoundaryQuotientMap_preserves_congruent
    {C : Type u} [Category.{v} C] [Abelian C]
    {D E : SSData C} {z b z' b' : WithTop ℕ}
    (hDBZ : D.B b ≤ D.Z z) (hEBZ : E.B b' ≤ E.Z z')
    (onBoundaries : Subobject.underlying.obj (D.B b) ⟶
      Subobject.underlying.obj (E.B b'))
    (onCycles : Subobject.underlying.obj (D.Z z) ⟶
      Subobject.underlying.obj (E.Z z'))
    (compat : onBoundaries ≫ Subobject.ofLE (E.B b') (E.Z z') hEBZ =
      Subobject.ofLE (D.B b) (D.Z z) hDBZ ≫ onCycles)
    {T : C} {x y : T ⟶ Subobject.underlying.obj (D.Z z)}
    (h : congruentModCycleBoundary D z b hDBZ x y) :
    congruentModCycleBoundary E z' b' hEBZ (x ≫ onCycles) (y ≫ onCycles) := by
  change (x ≫ onCycles) ≫
      cokernel.π (Subobject.ofLE (E.B b') (E.Z z') hEBZ) =
    (y ≫ onCycles) ≫ cokernel.π (Subobject.ofLE (E.B b') (E.Z z') hEBZ)
  have hq := congrArg (fun v => v ≫
      cycleBoundaryQuotientMap hDBZ hEBZ onBoundaries onCycles compat) h
  simpa only [Category.assoc, cycleBoundaryQuotientMap_π hDBZ hEBZ
    onBoundaries onCycles compat] using hq

variable (𝒮 : Type u) [StableHomotopy.StableHomotopyCategory.{u, v} 𝒮]

/-- The classical quotient `Z_(q-l)^{s,t}(X) / B_(l+1)^{s,t}(X)`.
    The containment is an explicit argument because it is additional
    spectral-sequence information, not a consequence of the bare SSData
    monotonicity axioms. -/
noncomputable def adamsCycleBoundaryQuotient (X : 𝒮) (s t : ℤ)
    (q l : ℕ)
    (hBZ : ((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).B (↑(l + 1)) ≤
      ((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).Z (↑(q - l))) :
    ModuleCat.{v} IntModuleRing :=
  cycleBoundaryQuotient ((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t))
    (↑(q - l)) (↑(l + 1)) hBZ

/-- The additive homomorphism underlying a mixed-quotient map in the
classical Adams setting. Unlike the general construction, this specialization
can expose an `AddMonoidHom` because the ambient category is `ModuleCat ℤ`. -/
noncomputable def adamsCycleBoundaryQuotientMapAddHom
    {D E : SSData (ModuleCat.{v} IntModuleRing)} {z b z' b' : WithTop ℕ}
    (hDBZ : D.B b ≤ D.Z z) (hEBZ : E.B b' ≤ E.Z z')
    (onBoundaries : Subobject.underlying.obj (D.B b) ⟶
      Subobject.underlying.obj (E.B b'))
    (onCycles : Subobject.underlying.obj (D.Z z) ⟶
      Subobject.underlying.obj (E.Z z'))
    (compat : onBoundaries ≫ Subobject.ofLE (E.B b') (E.Z z') hEBZ =
      Subobject.ofLE (D.B b) (D.Z z) hDBZ ≫ onCycles) :
    cycleBoundaryQuotient (C := ModuleCat.{v} IntModuleRing) D z b hDBZ →+
      cycleBoundaryQuotient (C := ModuleCat.{v} IntModuleRing) E z' b' hEBZ :=
  (cycleBoundaryQuotientMap hDBZ hEBZ onBoundaries onCycles compat).hom.toAddMonoidHom

/-! ### E∞ comparison for a λ-quotient -/

variable (Syn : Type u') [Category.{v'} Syn] [Preadditive Syn]
    [HasZeroObject Syn] [HasShift Syn ℤ]
    [∀ n : ℤ, Functor.Additive (shiftFunctor Syn n)]
    [MonoidalCategory Syn]
    [Pretriangulated Syn] [SyntheticCategory Syn]

/-- Comparison data for Proposition 3.13 / Corollary A.11 in the form needed
    for extensions on a classical page.  At weight `t-l`, the synthetic
    `E∞` group of `νX/λ^q` is the classical mixed quotient
    `Z_(q-l)/B_(l+1)`.

    We use an additive equivalence rather than a categorical isomorphism,
    since the present synthetic Adams construction takes values in
    `AddCommGrpCat` while the classical Adams construction is packaged in
    `ModuleCat ℤ`. -/
class SyntheticModLambdaEInftyBridge (X : 𝒮) where
  boundary_le_cycle : ∀ (q l : ℕ) (_hq : 0 < q) (_hl : l < q) (s t : ℤ),
    ((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).B (↑(l + 1)) ≤
      ((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).Z (↑(q - l))
  einfty_addEquiv : ∀ (q l : ℕ) (_hq : 0 < q) (_hl : l < q) (s t : ℤ),
    ((SynAdamsSS Syn (XModLambdaN ((nu 𝒮 Syn).obj X) q)).ssData
      (s, t, t - l)).eInfty ≃+
      (adamsCycleBoundaryQuotient 𝒮 X s t q l
        (boundary_le_cycle q l _hq _hl s t))

/-- The comparison equivalence, exported as a theorem-sized accessor. -/
noncomputable def syntheticModLambda_einfty_addEquiv
    (X : 𝒮) [bridge : SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    (q l : ℕ) (hq : 0 < q) (hl : l < q) (s t : ℤ) :
    ((SynAdamsSS Syn (XModLambdaN ((nu 𝒮 Syn).obj X) q)).ssData
      (s, t, t - l)).eInfty ≃+
      (adamsCycleBoundaryQuotient 𝒮 X s t q l
        (bridge.boundary_le_cycle q l hq hl s t)) :=
  bridge.einfty_addEquiv q l hq hl s t

/-! ### Reduced hatted extension spectral sequences -/

/-- The source of the mod-`λ^q` reduction of a hatted map. -/
noncomputable def hattedModLambdaSource {X Y : 𝒮} (f : X ⟶ Y) (q : ℕ) : Syn :=
  XModLambdaN ((weightShift (Syn := Syn) (eHat 𝒮 f)).obj ((nu 𝒮 Syn).obj X)) q

/-- The target of the mod-`λ^q` reduction of a hatted map. -/
noncomputable def hattedModLambdaTarget {X Y : 𝒮} (_f : X ⟶ Y) (q : ℕ) : Syn :=
  XModLambdaN ((nu 𝒮 Syn).obj Y) q

/-- The λ-power square which makes a hatted lift descend to a map modulo
`λ^q`.  This is the exact datum that was previously hidden by an arbitrary
`reducedMap` field. -/
structure HattedModLambdaReduction {X Y : 𝒮} (f : X ⟶ Y) (q : ℕ) where
  powerSquare : LambdaPowerSquare (fHat 𝒮 Syn f) q

/-- The canonical reduction of a hatted map modulo `λ^q`. -/
noncomputable def HattedModLambdaReduction.map {X Y : 𝒮} {f : X ⟶ Y} {q : ℕ}
    (R : HattedModLambdaReduction 𝒮 Syn f q) :
    hattedModLambdaSource 𝒮 Syn f q ⟶ hattedModLambdaTarget 𝒮 Syn f q :=
  R.powerSquare.modLambdaMap

/-- All data needed to interpret a reduced hatted map as an extension spectral
sequence.  This packages the reduced map, convergence choices for its two
synthetic Adams spectral sequences, their filtration-compatible map, and
the boundedness needed by `BoundedExtensionSS`.

    The quotient map is no longer arbitrary: `reduction` supplies its
    λ-power square and `HattedModLambdaReduction.map` constructs it via
    functorial cofibers.  Producing `powerSquare` from the synthetic model is
    still the λ-linearity/naturality obligation. -/
structure ReducedHattedExtensionESS {X Y : 𝒮} (f : X ⟶ Y) (q : ℕ) where
  reduction : HattedModLambdaReduction 𝒮 Syn f q
  sourceA : (ℤ × ℤ) → AddCommGrpCat.{0}
  sourceF : Filtration sourceA
  targetA : (ℤ × ℤ) → AddCommGrpCat.{0}
  targetF : Filtration targetA
  sourceConv : Convergence (SynAdamsSS Syn (hattedModLambdaSource 𝒮 Syn f q))
    sourceA sourceF
  targetConv : Convergence (SynAdamsSS Syn (hattedModLambdaTarget 𝒮 Syn f q))
    targetA targetF
  convergenceMap : ConvergenceMorphism sourceConv targetConv
  /-- The map on synthetic `E∞`-terms is induced by the actual reduced
  hatted map, rather than being unrelated convergence data. -/
  einftyMap_eq : ∀ k,
    convergenceMap.eMap k =
      (synAdamsSS_functorial Syn reduction.map).eInftyMap k
  sourceBounded : sourceF.IsBounded
  targetBounded : targetF.IsBounded

/-- The map underlying a reduced hatted extension spectral sequence.  This
accessor preserves the convenient `M.reducedMap` spelling while ensuring that
the map is always the functorial-cofiber construction from `M.reduction`. -/
noncomputable def ReducedHattedExtensionESS.reducedMap
    {X Y : 𝒮} {f : X ⟶ Y} {q : ℕ}
    (M : ReducedHattedExtensionESS 𝒮 Syn f q) :
    hattedModLambdaSource 𝒮 Syn f q ⟶ hattedModLambdaTarget 𝒮 Syn f q :=
  M.reduction.map

/-- The reduced hatted map agrees with `f̂` after the canonical inclusion
into the λ-quotient. This is the top square used to transport a synthetic
representative to the reduced extension spectral sequence. -/
theorem ReducedHattedExtensionESS.fHat_comp_quotientIncl
    {X Y : 𝒮} {f : X ⟶ Y} {q : ℕ}
    (M : ReducedHattedExtensionESS 𝒮 Syn f q) :
    fHat 𝒮 Syn f ≫
        syn_functorial_cofiber.cofibι (lambdaPow q ((nu 𝒮 Syn).obj Y)) =
      syn_functorial_cofiber.cofibι
          (lambdaPow q ((weightShift (Syn := Syn) (eHat 𝒮 f)).obj
            ((nu 𝒮 Syn).obj X))) ≫ M.reducedMap :=
  M.reduction.powerSquare.comp_modLambdaIncl

/-- The reduced hatted map also commutes with the λ-quotient connecting maps.
This is the boundary-square compatibility needed for the second equality in
the triangulated Mahowald conclusion. -/
theorem ReducedHattedExtensionESS.quotientMap_comp_delta
    {X Y : 𝒮} {f : X ⟶ Y} {q : ℕ}
    (M : ReducedHattedExtensionESS 𝒮 Syn f q) :
    M.reducedMap ≫ syn_functorial_cofiber.cofibδ
        (lambdaPow q ((nu 𝒮 Syn).obj Y)) =
      syn_functorial_cofiber.cofibδ
          (lambdaPow q ((weightShift (Syn := Syn) (eHat 𝒮 f)).obj
            ((nu 𝒮 Syn).obj X))) ≫
        (shiftFunctor Syn (1 : ℤ)).map M.reduction.powerSquare.shiftedMap :=
  M.reduction.powerSquare.modLambdaMap_comp_delta

/-- The ESS attached to a mod-`λ^q` hatted map. -/
noncomputable def ReducedHattedExtensionESS.ess
    {X Y : 𝒮} {f : X ⟶ Y} {q : ℕ}
    (M : ReducedHattedExtensionESS 𝒮 Syn f q) :
    BoundedExtensionSS M.sourceConv M.targetConv M.convergenceMap
      M.sourceBounded M.targetBounded :=
  BoundedExtensionSS.mk' M.sourceConv M.targetConv M.convergenceMap
    M.sourceBounded M.targetBounded

/-- Naturality of the mod-`λ^q` `E∞` comparison for a reduced hatted map.

The two objects in `SyntheticModLambdaEInftyBridge` are not enough for the
Mahowald argument: its extension relation is transported along a map.  This
structure records the corresponding classical map on mixed `Z/B` quotients
and the required commuting square on the precise tridegree used in the
comparison. -/
structure ReducedHattedEInftyComparison {X Y : 𝒮} (f : X ⟶ Y) (q l : ℕ)
    (hq : 0 < q) (hl : l < q)
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    (M : ReducedHattedExtensionESS 𝒮 Syn f q) where
  /-- Comparison at the shifted source of `f̂`.  The shift by `ê(f)` means
  this is not definitionally the unshifted bridge for `νX/λ^q`. -/
  sourceAddEquiv : ∀ (s t : ℤ),
    ((SynAdamsSS Syn (hattedModLambdaSource 𝒮 Syn f q)).ssData
      (s, t, t - l)).eInfty ≃+
      (adamsCycleBoundaryQuotient 𝒮 X s t q l
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
          q l hq hl s t))
  classicalMap : ∀ (s t : ℤ),
    (adamsCycleBoundaryQuotient 𝒮 X s t q l
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
        q l hq hl s t)) →+
      (adamsCycleBoundaryQuotient 𝒮 Y s t q l
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
          q l hq hl s t))
  commutes : ∀ (s t : ℤ)
    (z : ((SynAdamsSS Syn (hattedModLambdaSource 𝒮 Syn f q)).ssData
      (s, t, t - l)).eInfty),
    (syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t)
        ((M.convergenceMap.eMap (s, t, t - l)) z) =
      (classicalMap s t)
        ((sourceAddEquiv s t) z)

/-- Stronger comparison data asserting that the classical map is induced by
maps on the precise mixed cycle and boundary subobjects. The weaker
`ReducedHattedEInftyComparison` only records its action on quotient groups;
this refinement is the datum required to transport representative-level
congruences through the Mahowald argument. -/
structure InducedReducedHattedEInftyComparison
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    (K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M) where
  onBoundaries : ∀ (s t : ℤ),
    Subobject.underlying.obj
        (((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).B (↑(l + 1))) ⟶
      Subobject.underlying.obj
        (((StableHomotopy.AdamsSS 𝒮 Y).ssData (s, t)).B (↑(l + 1)))
  onCycles : ∀ (s t : ℤ),
    Subobject.underlying.obj
        (((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).Z (↑(q - l))) ⟶
      Subobject.underlying.obj
        (((StableHomotopy.AdamsSS 𝒮 Y).ssData (s, t)).Z (↑(q - l)))
  compat : ∀ (s t : ℤ),
    onBoundaries s t ≫ Subobject.ofLE
        (((StableHomotopy.AdamsSS 𝒮 Y).ssData (s, t)).B (↑(l + 1)))
        (((StableHomotopy.AdamsSS 𝒮 Y).ssData (s, t)).Z (↑(q - l)))
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
          q l hq hl s t) =
      Subobject.ofLE
          (((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).B (↑(l + 1)))
          (((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).Z (↑(q - l)))
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
            q l hq hl s t) ≫ onCycles s t
  classicalMap_eq_induced : ∀ (s t : ℤ), K.classicalMap s t =
    adamsCycleBoundaryQuotientMapAddHom
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
        q l hq hl s t)
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
        q l hq hl s t)
      (onBoundaries s t) (onCycles s t) (compat s t)

/-- Accessor for the inducedness equation of a refined reduced hatted
comparison. -/
theorem InducedReducedHattedEInftyComparison.classicalMap_eq
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ) :
    K.classicalMap s t = adamsCycleBoundaryQuotientMapAddHom
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
        q l hq hl s t)
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
        q l hq hl s t)
      (I.onBoundaries s t) (I.onCycles s t) (I.compat s t) :=
  I.classicalMap_eq_induced s t

/-- The cycle map carried by a refined hatted comparison preserves the
classical equality relation modulo the specified boundary. -/
theorem InducedReducedHattedEInftyComparison.preserves_congruent
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ) {T : ModuleCat.{v} IntModuleRing}
    {x y : T ⟶ Subobject.underlying.obj
      (((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)).Z (↑(q - l)))}
    (h : congruentModCycleBoundary
      ((StableHomotopy.AdamsSS 𝒮 X).ssData (s, t)) (↑(q - l)) (↑(l + 1))
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
        q l hq hl s t) x y) :
    congruentModCycleBoundary
      ((StableHomotopy.AdamsSS 𝒮 Y).ssData (s, t)) (↑(q - l)) (↑(l + 1))
      ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
        q l hq hl s t)
      (x ≫ I.onCycles s t) (y ≫ I.onCycles s t) :=
  cycleBoundaryQuotientMap_preserves_congruent
    ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
      q l hq hl s t)
    ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
      q l hq hl s t)
    (I.onBoundaries s t) (I.onCycles s t) (I.compat s t) h

/-- The synthetic `E∞` comparison intertwines the reduced hatted map with
the mixed-quotient map induced by the refined classical comparison. -/
theorem InducedReducedHattedEInftyComparison.einfty_commutes
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ)
    (z : ((SynAdamsSS Syn (hattedModLambdaSource 𝒮 Syn f q)).ssData
      (s, t, t - l)).eInfty) :
    (syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t)
        ((M.convergenceMap.eMap (s, t, t - l)) z) =
      adamsCycleBoundaryQuotientMapAddHom
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
          q l hq hl s t)
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
          q l hq hl s t)
        (I.onBoundaries s t) (I.onCycles s t) (I.compat s t)
        ((K.sourceAddEquiv s t) z) := by
  rw [K.commutes s t z,
    InducedReducedHattedEInftyComparison.classicalMap_eq
      (𝒮 := 𝒮) (Syn := Syn) I s t]
  rfl

/-- A specified target on the synthetic `E∞` page is the image of a source
class under the reduced hatted map exactly when its classical mixed
cycle--boundary class is the image under the induced map.  This is the form
needed when a Mahowald representative is required to hit a *particular*
class, rather than merely to exist after applying the map. -/
theorem InducedReducedHattedEInftyComparison.einftyMap_eq_iff
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ)
    (z : ((SynAdamsSS Syn (hattedModLambdaSource 𝒮 Syn f q)).ssData
      (s, t, t - l)).eInfty)
    (w : ((SynAdamsSS Syn (XModLambdaN ((nu 𝒮 Syn).obj Y) q)).ssData
      (s, t, t - l)).eInfty) :
    (M.convergenceMap.eMap (s, t, t - l)) z = w ↔
      adamsCycleBoundaryQuotientMapAddHom
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
          q l hq hl s t)
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
          q l hq hl s t)
        (I.onBoundaries s t) (I.onCycles s t) (I.compat s t)
        ((K.sourceAddEquiv s t) z) =
      (syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t) w := by
  constructor
  · intro h
    rw [← h]
    exact InducedReducedHattedEInftyComparison.einfty_commutes
      (𝒮 := 𝒮) (Syn := Syn) I s t z |>.symm
  · intro h
    apply (syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t).injective
    rw [InducedReducedHattedEInftyComparison.einfty_commutes
      (𝒮 := 𝒮) (Syn := Syn) I s t z]
    exact h

/-- At a fixed tridegree, the reduced hatted map is surjective on synthetic
`E∞` classes exactly when its induced map is surjective on the classical
mixed cycle--boundary quotient.  Thus a classical choice of a preimage can
be lifted back through the comparison equivalences to a synthetic
representative. -/
theorem InducedReducedHattedEInftyComparison.einftyMap_surjective_iff
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ) :
    Function.Surjective (M.convergenceMap.eMap (s, t, t - l)) ↔
      Function.Surjective
        (adamsCycleBoundaryQuotientMapAddHom
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
            q l hq hl s t)
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
            q l hq hl s t)
          (I.onBoundaries s t) (I.onCycles s t) (I.compat s t)) := by
  constructor
  · intro h w
    rcases h ((syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t).symm w) with
      ⟨z, hz⟩
    refine ⟨(K.sourceAddEquiv s t) z, ?_⟩
    have hcomm := InducedReducedHattedEInftyComparison.einfty_commutes
      (𝒮 := 𝒮) (Syn := Syn) I s t z
    rw [hz] at hcomm
    simpa using hcomm.symm
  · intro h w
    rcases h ((syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t) w) with
      ⟨x, hx⟩
    refine ⟨(K.sourceAddEquiv s t).symm x, ?_⟩
    apply (InducedReducedHattedEInftyComparison.einftyMap_eq_iff
      (𝒮 := 𝒮) (Syn := Syn) I s t ((K.sourceAddEquiv s t).symm x) w).mpr
    simpa using hx

/-- At a fixed tridegree, injectivity of the reduced hatted map on synthetic
`E∞` classes is equivalent to injectivity of the induced classical mixed
quotient map. -/
theorem InducedReducedHattedEInftyComparison.einftyMap_injective_iff
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ) :
    Function.Injective (M.convergenceMap.eMap (s, t, t - l)) ↔
      Function.Injective
        (adamsCycleBoundaryQuotientMapAddHom
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
            q l hq hl s t)
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
            q l hq hl s t)
          (I.onBoundaries s t) (I.onCycles s t) (I.compat s t)) := by
  constructor
  · intro h x y hxy
    apply (K.sourceAddEquiv s t).symm.injective
    apply h
    apply (syntheticModLambda_einfty_addEquiv 𝒮 Syn Y q l hq hl s t).injective
    rw [InducedReducedHattedEInftyComparison.einfty_commutes
      (𝒮 := 𝒮) (Syn := Syn) I s t ((K.sourceAddEquiv s t).symm x),
      InducedReducedHattedEInftyComparison.einfty_commutes
        (𝒮 := 𝒮) (Syn := Syn) I s t ((K.sourceAddEquiv s t).symm y)]
    simpa using hxy
  · intro h z z' hzz'
    apply (K.sourceAddEquiv s t).injective
    apply h
    rw [← InducedReducedHattedEInftyComparison.einfty_commutes
      (𝒮 := 𝒮) (Syn := Syn) I s t z,
      ← InducedReducedHattedEInftyComparison.einfty_commutes
        (𝒮 := 𝒮) (Syn := Syn) I s t z', hzz']

/-- The comparison preserves and reflects bijectivity of the reduced hatted
map at every tridegree. -/
theorem InducedReducedHattedEInftyComparison.einftyMap_bijective_iff
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ) :
    Function.Bijective (M.convergenceMap.eMap (s, t, t - l)) ↔
      Function.Bijective
        (adamsCycleBoundaryQuotientMapAddHom
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
            q l hq hl s t)
          ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
            q l hq hl s t)
          (I.onBoundaries s t) (I.onCycles s t) (I.compat s t)) := by
  constructor
  · rintro ⟨hinj, hsurj⟩
    exact ⟨(InducedReducedHattedEInftyComparison.einftyMap_injective_iff
        (𝒮 := 𝒮) (Syn := Syn) I s t).mp hinj,
      (InducedReducedHattedEInftyComparison.einftyMap_surjective_iff
        (𝒮 := 𝒮) (Syn := Syn) I s t).mp hsurj⟩
  · rintro ⟨hinj, hsurj⟩
    exact ⟨(InducedReducedHattedEInftyComparison.einftyMap_injective_iff
        (𝒮 := 𝒮) (Syn := Syn) I s t).mpr hinj,
      (InducedReducedHattedEInftyComparison.einftyMap_surjective_iff
        (𝒮 := 𝒮) (Syn := Syn) I s t).mpr hsurj⟩

/-- When the induced classical mixed-quotient map is bijective, the reduced
hatted map has an explicit additive inverse on the corresponding synthetic
`E∞` groups. -/
noncomputable def InducedReducedHattedEInftyComparison.einftyMapAddEquiv
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ)
    (h : Function.Bijective
      (adamsCycleBoundaryQuotientMapAddHom
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
          q l hq hl s t)
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
          q l hq hl s t)
        (I.onBoundaries s t) (I.onCycles s t) (I.compat s t))) :
    ((SynAdamsSS Syn (hattedModLambdaSource 𝒮 Syn f q)).ssData
      (s, t, t - l)).eInfty ≃+
      ((SynAdamsSS Syn (XModLambdaN ((nu 𝒮 Syn).obj Y) q)).ssData
        (s, t, t - l)).eInfty :=
  AddEquiv.ofBijective (M.convergenceMap.eMap (s, t, t - l)).hom
    ((InducedReducedHattedEInftyComparison.einftyMap_bijective_iff
      (𝒮 := 𝒮) (Syn := Syn) I s t).mpr h)

/-- The inverse supplied by `einftyMapAddEquiv` is a specified synthetic
preimage of every target `E∞` class. -/
theorem InducedReducedHattedEInftyComparison.einftyMap_apply_symm
    {X Y : 𝒮} {f : X ⟶ Y} {q l : ℕ} {hq : 0 < q} {hl : l < q}
    [SyntheticModLambdaEInftyBridge 𝒮 Syn X]
    [SyntheticModLambdaEInftyBridge 𝒮 Syn Y]
    {M : ReducedHattedExtensionESS 𝒮 Syn f q}
    {K : ReducedHattedEInftyComparison 𝒮 Syn f q l hq hl M}
    (I : InducedReducedHattedEInftyComparison (𝒮 := 𝒮) (Syn := Syn) K)
    (s t : ℤ)
    (h : Function.Bijective
      (adamsCycleBoundaryQuotientMapAddHom
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn X).boundary_le_cycle
          q l hq hl s t)
        ((inferInstance : SyntheticModLambdaEInftyBridge 𝒮 Syn Y).boundary_le_cycle
          q l hq hl s t)
        (I.onBoundaries s t) (I.onCycles s t) (I.compat s t)))
    (w : ((SynAdamsSS Syn (XModLambdaN ((nu 𝒮 Syn).obj Y) q)).ssData
      (s, t, t - l)).eInfty) :
    (M.convergenceMap.eMap (s, t, t - l))
      ((InducedReducedHattedEInftyComparison.einftyMapAddEquiv
        (𝒮 := 𝒮) (Syn := Syn) I s t h).symm w) = w := by
  let e := InducedReducedHattedEInftyComparison.einftyMapAddEquiv
    (𝒮 := 𝒮) (Syn := Syn) I s t h
  change e (e.symm w) = w
  exact e.apply_symm_apply w

/-- A concrete page-level extension relation for a reduced hatted map.

The extension spectral sequence has bidegree `(filtration, complex-degree)`;
the synthetic Adams stem and weight are the separate parameter `t`.  Keeping
all five indices explicit avoids the former ill-typed shortcut through the
abstract `BoundedExtensionSS.essDiff` accessor, whose input bidegrees belong
to the *underlying* spectral sequences rather than to their ESS. -/
abbrev HasClassicalPageExtension
    {X Y : 𝒮} {f : X ⟶ Y} {q : ℕ}
    (M : ReducedHattedExtensionESS 𝒮 Syn f q)
    (t : ℤ × ℤ) (r s k : ℤ) {T : AddCommGrpCat}
    (x : T ⟶ (M.ess.complex t).assocGraded s k)
    (y : T ⟶ (M.ess.complex t).assocGraded (s + r) (k - 1)) : Prop :=
  ESSRelationAt M.ess t r s k x y

end KIPBase.Synthetic
